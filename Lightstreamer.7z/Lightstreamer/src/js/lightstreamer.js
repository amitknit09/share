/*
 * LIGHTSTREAMER - www.lightstreamer.com
 * Lightstreamer Web Client
 * Version 7.2.0 build 1777
 * Copyright (c) Lightstreamer Srl. All Rights Reserved.
 * Contains: LightstreamerClient, Subscription, ConnectionSharing, DynaGrid
 *   StaticGrid, FlashBridge, Chart, SimpleChartListener
 *   StatusWidget, SimpleLoggerProvider, AlertAppender, BufferAppender
 *   ConsoleAppender, DOMAppender, FunctionAppender, RemoteAppender
 *   LogMessages
 * AMD
 */
(function() {
    define("IllegalStateException", [], function() {
        function d(d) {
            this.name = "IllegalStateException";
            this.message = d
        }
        d.prototype = {
            toString: function() {
                return ["[", this.name, this.message, "]"].join("|")
            }
        };
        return d
    });
    define("Environment", ["IllegalStateException"], function(d) {
        var f = "undefined" !== typeof window && "undefined" !== typeof navigator && "undefined" !== typeof document,
            b = "undefined" !== typeof importScripts,
            a = "object" == typeof process && (/node(\.exe)?$/.test(process.execPath) || process.node && process.v8 || process.versions && process.versions.node && process.versions.v8);
        if (f && !document.getElementById) throw new d("Not supported browser");
        var c = {
            isBrowserDocument: function() {
                return f
            },
            isBrowser: function() {
                return !a && (f || b)
            },
            isNodeJS: function() {
                return !f && a
            },
            isWebWorker: function() {
                return !f && !a && b
            },
            hy: function() {
                return !f && !a && !b
            },
            browserDocumentOrDie: function() {
                if (!this.isBrowserDocument()) throw new d("Trying to load a browser-only module on non-browser environment");
            }
        };
        c.isBrowserDocument = c.isBrowserDocument;
        c.isBrowser = c.isBrowser;
        c.isNodeJS = c.isNodeJS;
        c.isWebWorker = c.isWebWorker;
        c.browserDocumentOrDie = c.browserDocumentOrDie;
        return c
    });
    define("Helpers", ["Environment"], function(d) {
        var f = /^\s*([\s\S]*?)\s*$/,
            b = RegExp(",", "g"),
            a = RegExp("\\.", "g"),
            c = {
                getTimeStamp: function() {
                    return (new Date).getTime()
                },
                randomG: function(a) {
                    return Math.round(Math.random() * (a || 1E3))
                },
                trim: function(a) {
                    return a.replace(f, "$1")
                },
                getNumber: function(c, e) {
                    if (c) {
                        if (!c.replace) return c;
                        e ? (c = c.replace(a, ""), c = c.replace(b, ".")) : c = c.replace(b, "");
                        return new Number(c)
                    }
                    return 0
                },
                isArray: function(a) {
                    return a && a.join && "function" == typeof a.join
                },
                addEvent: function(a, b,
                    c) {
                    if (!d.isBrowserDocument()) return !1;
                    "undefined" != typeof a.addEventListener ? a.addEventListener(b, c, !1) : "undefined" != typeof a.attachEvent && a.attachEvent("on" + b, c);
                    return !0
                },
                removeEvent: function(a, b, c) {
                    if (!d.isBrowserDocument()) return !1;
                    "undefined" != typeof a.removeEventListener ? a.removeEventListener(b, c, !1) : "undefined" != typeof a.detachEvent && a.detachEvent("on" + b, c);
                    return !0
                }
            };
        c.getTimeStamp = c.getTimeStamp;
        c.randomG = c.randomG;
        c.trim = c.trim;
        c.getNumber = c.getNumber;
        c.isArray = c.isArray;
        c.addEvent = c.addEvent;
        c.removeEvent = c.removeEvent;
        return c
    });
    define("BrowserDetection", ["Environment"], function(d) {
        function f(a) {
            var b = e;
            return function() {
                null === b && (b = -1 < p.indexOf(a));
                return b
            }
        }

        function b(a) {
            var b = e;
            return function() {
                if (null === b) {
                    b = !0;
                    for (var c = 0; c < a.length; c++) b = b && a[c]()
                }
                return b
            }
        }

        function a(a, b) {
            var c = e,
                g = e;
            return function(e, d) {
                null === c && (g = (c = a()) ? b() : null);
                return c ? e && g ? !0 === d ? g <= e : !1 === d ? g >= e : g == e : !0 : !1
            }
        }

        function c(a) {
            var b = e;
            return function() {
                if (null === b) {
                    var c = a.exec(p);
                    if (c && 2 <= c.length) return c[1]
                }
                return null
            }
        }

        function g(a) {
            return function() {
                return !a()
            }
        }
        var e = d.isBrowser() ? null : !1,
            p = d.isBrowser() ? navigator.userAgent.toLowerCase() : null,
            k = e;
        d = {
            isProbablyRekonq: f("rekonq"),
            isProbablyAWebkit: f("webkit"),
            isProbablyPlaystation: f("playstation 3"),
            isProbablyChrome: a(f("chrome/"), c(RegExp("chrome/([0-9]+)", "g"))),
            isProbablyAKhtml: function() {
                null === k && (k = document.childNodes && !document.all && !navigator.WC && !navigator.EC);
                return k
            },
            isProbablyKonqueror: a(f("konqueror"), c(RegExp("konqueror/([0-9.]+)", "g"))),
            isProbablyIE: function(b, g) {
                return a(f("msie"), c(RegExp("msie\\s([0-9]+)[.;]",
                    "g")))(b, g) || a(f("rv:11.0"), function() {
                    return "11"
                })(b, g) ? !0 : !1
            },
            wr: f("edge"),
            isProbablyFX: a(f("firefox"), c(/firefox\/(\d+\.?\d*)/)),
            isProbablyOldOpera: a(function() {
                return "undefined" != typeof opera
            }, function() {
                if (opera.version) {
                    var a = opera.version(),
                        a = a.replace(RegExp("[^0-9.]+", "g"), "");
                    return parseInt(a)
                }
                return 7
            })
        };
        d.isProbablyAndroidBrowser = b([f("android"), d.isProbablyAWebkit, g(d.isProbablyChrome)]);
        d.isProbablyOperaMobile = b([d.isProbablyOldOpera, f("opera mobi")]);
        d.isProbablyApple = a(b([f("safari"),
            function(a) {
                var b = e;
                return function() {
                    if (null === b) {
                        b = !1;
                        for (var c = 0; c < a.length; c++) b = b || a[c]()
                    }
                    return b
                }
            }([f("ipad"), f("iphone"), f("ipod"), b([g(d.isProbablyAndroidBrowser), g(d.isProbablyChrome), g(d.isProbablyRekonq)])])
        ]), c(/version\/(\d+\.?\d*)/));
        d.isProbablyRekonq = d.isProbablyRekonq;
        d.isProbablyChrome = d.isProbablyChrome;
        d.isProbablyAWebkit = d.isProbablyAWebkit;
        d.isProbablyPlaystation = d.isProbablyPlaystation;
        d.isProbablyAndroidBrowser = d.isProbablyAndroidBrowser;
        d.isProbablyOperaMobile = d.isProbablyOperaMobile;
        d.isProbablyApple = d.isProbablyApple;
        d.isProbablyAKhtml = d.isProbablyAKhtml;
        d.isProbablyKonqueror = d.isProbablyKonqueror;
        d.isProbablyIE = d.isProbablyIE;
        d.isProbablyEdge = d.wr;
        d.isProbablyFX = d.isProbablyFX;
        d.isProbablyOldOpera = d.isProbablyOldOpera;
        return d
    });
    define("List", [], function() {
        function d() {
            this.data = []
        }
        d.prototype = {
            add: function(d) {
                this.data.push(d)
            },
            remove: function(d) {
                d = this.find(d);
                if (0 > d) return !1;
                this.data.splice(d, 1);
                return !0
            },
            contains: function(d) {
                return 0 <= this.find(d)
            },
            find: function(d) {
                for (var b = 0; b < this.data.length; b++)
                    if (this.data[b] === d) return b;
                return -1
            },
            forEach: function(d) {
                for (var b = 0; b < this.data.length; b++) d(this.data[b])
            },
            asArray: function() {
                return [].concat(this.data)
            },
            clean: function() {
                this.data = []
            }
        };
        d.prototype.add = d.prototype.add;
        d.prototype.remove = d.prototype.remove;
        d.prototype.forEach = d.prototype.forEach;
        d.prototype.asArray = d.prototype.asArray;
        d.prototype.clean = d.prototype.clean;
        return d
    });
    define("EnvironmentStatus", ["Helpers", "BrowserDetection", "Environment", "List"], function(d, f, b, a) {
        function c(a, b, c, e, d) {
            return function() {
                a[b] || (a[c] = !0, e.forEach(function(a) {
                    try {
                        if (a[d]) a[d]();
                        else a()
                    } catch (b) {}
                }), "preunloading" != b && e.clean(), a[b] = !0, a[c] = !1)
            }
        }

        function g(a, b) {
            setTimeout(function() {
                if (a[b]) a[b]();
                else a()
            }, 0)
        }

        function e(a, b, c, e) {
            setTimeout(function() {
                c ? e ? a.apply(c, e) : a.apply(c) : e ? a.apply(null, e) : a()
            }, b)
        }

        function p() {
            m = !0
        }
        var k = new a,
            h = new a,
            l = new a,
            m = !1,
            t = {
                yh: "onloadDone",
                qs: "onloadInprogress",
                gi: "unloaded",
                Co: "unloading",
                As: "preunloading"
            };
        a = {};
        for (var n in t) a[t[n]] = n;
        n = {
            yh: !1,
            qs: !1,
            gi: !1,
            Co: !1,
            As: !1,
            isLoaded: function() {
                return this.yh
            },
            isUnloaded: function() {
                return this.gi
            },
            isUnloading: function() {
                return this.Co
            },
            addOnloadHandler: function(a) {
                this.jy() ? h.add(a) : g(a, "onloadEvent")
            },
            addUnloadHandler: function(a) {
                this.ky() ? k.add(a) : g(a, "unloadEvent")
            },
            addBeforeUnloadHandler: function(a) {
                l.add(a);
                this.As && g(a, "preUnloadEvent")
            },
            removeOnloadHandler: function(a) {
                h.remove(a)
            },
            removeUnloadHandler: function(a) {
                k.remove(a)
            },
            removeBeforeUnloadHandler: function(a) {
                l.remove(a)
            },
            jy: function() {
                return !(this.yh || this.qs)
            },
            ky: function() {
                return !(this.gi || this.Co)
            },
            Su: function() {
                d.addEvent(window, "unload", this.nv);
                d.addEvent(window, "beforeunload", this.Uu);
                if (document && "undefined" != typeof document.readyState) {
                    if ("COMPLETE" == document.readyState.toUpperCase()) {
                        this.Bi();
                        return
                    }
                    e(this.aq, 1E3, this)
                } else if (this.ur()) {
                    this.Bi();
                    return
                }
                if (!d.addEvent(window, "load", this.fk)) this.Bi();
                else if (f.isProbablyOldOpera()) {
                    var a = !1;
                    f.isProbablyOldOpera(9,
                        !1) && (a = !0, d.addEvent(document, "DOMContentLoaded", p));
                    e(this.$p, 1E3, this, [a])
                }
            },
            Bi: function() {
                e(this.fk, 0)
            },
            aq: function() {
                this.yh || ("COMPLETE" == document.readyState.toUpperCase() ? this.fk() : e(this.aq, 1E3, this))
            },
            $p: function(a) {
                this.yh || (m || !a && this.ur() ? this.fk() : e(this.$p, 1E3, this, [a]))
            },
            ur: function() {
                return "undefined" != typeof document.getElementsByTagName && "undefined" != typeof document.getElementById && (null != document.getElementsByTagName("body")[0] || null != document.body)
            }
        };
        n.fk = c(n, a.onloadDone, a.onloadInprogress,
            h, "onloadEvent");
        n.nv = c(n, a.unloaded, a.unloading, k, "unloadEvent");
        n.Uu = c(n, a.preunloading, a.preunloading, l, "preUnloadEvent");
        b.isBrowserDocument() ? n.Su() : n.Bi();
        n.addOnloadHandler = n.addOnloadHandler;
        n.addUnloadHandler = n.addUnloadHandler;
        n.addBeforeUnloadHandler = n.addBeforeUnloadHandler;
        n.removeOnloadHandler = n.removeOnloadHandler;
        n.removeUnloadHandler = n.removeUnloadHandler;
        n.removeBeforeUnloadHandler = n.removeBeforeUnloadHandler;
        n.isLoaded = n.isLoaded;
        n.isUnloaded = n.isUnloaded;
        n.isUnloading = n.isUnloading;
        return n
    });
    define("Promise", [], function() {
        "undefined" == typeof Promise && function() {
            function d(a, e) {
                I[y] = a;
                I[y + 1] = e;
                y += 2;
                2 === y && (x ? x(p) : M())
            }

            function f(a) {
                return "function" === typeof a
            }

            function b() {
                return function() {
                    process.nextTick(p)
                }
            }

            function a() {
                return function() {
                    F(p)
                }
            }

            function c() {
                var a = 0,
                    e = new G(p),
                    c = document.createTextNode("");
                e.observe(c, {
                    characterData: !0
                });
                return function() {
                    c.data = a = ++a % 2
                }
            }

            function g() {
                var a = new MessageChannel;
                a.port1.onmessage = p;
                return function() {
                    a.port2.postMessage(0)
                }
            }

            function e() {
                return function() {
                    setTimeout(p,
                        1)
                }
            }

            function p() {
                for (var a = 0; a < y; a += 2)(0, I[a])(I[a + 1]), I[a] = void 0, I[a + 1] = void 0;
                y = 0
            }

            function k() {
                try {
                    var c = require("vertx");
                    F = c.SC || c.RC;
                    return a()
                } catch (b) {
                    return e()
                }
            }

            function h() {}

            function l(a, e, c, b) {
                try {
                    a.call(e, c, b)
                } catch (g) {
                    return g
                }
            }

            function m(a, e, c) {
                d(function(a) {
                    var b = !1,
                        g = l(c, e, function(c) {
                            b || (b = !0, e !== c ? n(a, c) : u(a, c))
                        }, function(e) {
                            b || (b = !0, q(a, e))
                        });
                    !b && g && (b = !0, q(a, g))
                }, a)
            }

            function t(a, e) {
                1 === e.Ha ? u(a, e.Sa) : 2 === e.Ha ? q(a, e.Sa) : v(e, void 0, function(e) {
                    n(a, e)
                }, function(e) {
                    q(a, e)
                })
            }

            function n(a,
                e) {
                if (a === e) q(a, new TypeError("You cannot resolve a promise with itself"));
                else if ("function" === typeof e || "object" === typeof e && null !== e)
                    if (e.constructor === a.constructor) t(a, e);
                    else {
                        var c;
                        try {
                            c = e.then
                        } catch (b) {
                            K.error = b, c = K
                        }
                        c === K ? q(a, K.error) : void 0 === c ? u(a, e) : f(c) ? m(a, e, c) : u(a, e)
                    }
                else u(a, e)
            }

            function r(a) {
                a.cl && a.cl(a.Sa);
                z(a)
            }

            function u(a, e) {
                void 0 === a.Ha && (a.Sa = e, a.Ha = 1, 0 !== a.wi.length && d(z, a))
            }

            function q(a, e) {
                void 0 === a.Ha && (a.Ha = 2, a.Sa = e, d(r, a))
            }

            function v(a, e, c, b) {
                var g = a.wi,
                    h = g.length;
                a.cl =
                    null;
                g[h] = e;
                g[h + 1] = c;
                g[h + 2] = b;
                0 === h && a.Ha && d(z, a)
            }

            function z(a) {
                var e = a.wi,
                    c = a.Ha;
                if (0 !== e.length) {
                    for (var b, g, h = a.Sa, k = 0; k < e.length; k += 3) b = e[k], g = e[k + c], b ? B(c, b, g, h) : g(h);
                    a.wi.length = 0
                }
            }

            function C() {
                this.error = null
            }

            function B(a, e, c, b) {
                var g = f(c),
                    h, k, l, t;
                if (g) {
                    try {
                        h = c(b)
                    } catch (p) {
                        N.error = p, h = N
                    }
                    h === N ? (t = !0, k = h.error, h = null) : l = !0;
                    if (e === h) {
                        q(e, new TypeError("A promises callback cannot return that same promise."));
                        return
                    }
                } else h = b, l = !0;
                void 0 === e.Ha && (g && l ? n(e, h) : t ? q(e, k) : 1 === a ? u(e, h) : 2 === a && q(e, h))
            }

            function w(a, e) {
                try {
                    e(function(e) {
                        n(a, e)
                    }, function(e) {
                        q(a, e)
                    })
                } catch (c) {
                    q(a, c)
                }
            }

            function H(a, e) {
                this.pu = a;
                this.dg = new a(h);
                this.xu(e) ? (this.ou = e, this.ui = this.length = e.length, this.nu(), 0 === this.length ? u(this.dg, this.Sa) : (this.length = this.length || 0, this.lu(), 0 === this.ui && u(this.dg, this.Sa))) : q(this.dg, this.yu())
            }

            function D(a) {
                this.od = J++;
                this.Sa = this.Ha = void 0;
                this.wi = [];
                if (h !== a) {
                    if (!f(a)) throw new TypeError("You must pass a resolver function as the first argument to the promise constructor");
                    if (!(this instanceof D)) throw new TypeError("Failed to construct 'Promise': Please use the 'new' operator, this object constructor cannot be called as a function.");
                    w(this, a)
                }
            }
            var L = Array.isArray ? Array.isArray : function(a) {
                    return "[object Array]" === Object.prototype.toString.call(a)
                },
                y = 0,
                F, x, A = "undefined" !== typeof window ? window : void 0,
                E = A || {},
                G = E.MutationObserver || E.WebKitMutationObserver,
                E = "undefined" !== typeof Uint8ClampedArray && "undefined" !== typeof importScripts && "undefined" !== typeof MessageChannel,
                I = Array(1E3),
                M;
            M = "undefined" !==
                typeof process && "[object process]" === {}.toString.call(process) ? b() : G ? c() : E ? g() : void 0 === A && "function" === typeof require ? k() : e();
            var K = new C,
                N = new C;
            H.prototype.xu = function(a) {
                return L(a)
            };
            H.prototype.yu = function() {
                return Error("Array Methods must be provided an Array")
            };
            H.prototype.nu = function() {
                this.Sa = Array(this.length)
            };
            H.prototype.lu = function() {
                for (var a = this.length, e = this.dg, c = this.ou, b = 0; void 0 === e.Ha && b < a; b++) this.ku(c[b], b)
            };
            H.prototype.ku = function(a, e) {
                var c = this.pu;
                "object" === typeof a && null !==
                    a ? a.constructor === c && void 0 !== a.Ha ? (a.cl = null, this.dl(a.Ha, e, a.Sa)) : this.zu(c.resolve(a), e) : (this.ui--, this.Sa[e] = a)
            };
            H.prototype.dl = function(a, e, c) {
                var b = this.dg;
                void 0 === b.Ha && (this.ui--, 2 === a ? q(b, c) : this.Sa[e] = c);
                0 === this.ui && u(b, this.Sa)
            };
            H.prototype.zu = function(a, e) {
                var c = this;
                v(a, void 0, function(a) {
                    c.dl(1, e, a)
                }, function(a) {
                    c.dl(2, e, a)
                })
            };
            var J = 0;
            D.all = function(a) {
                return (new H(this, a)).dg
            };
            D.race = function(a) {
                function e(a) {
                    n(b, a)
                }

                function c(a) {
                    q(b, a)
                }
                var b = new this(h);
                if (!L(a)) return q(b, new TypeError("You must pass an array to race.")),
                    b;
                for (var g = a.length, k = 0; void 0 === b.Ha && k < g; k++) v(this.resolve(a[k]), void 0, e, c);
                return b
            };
            D.resolve = function(a) {
                if (a && "object" === typeof a && a.constructor === this) return a;
                var e = new this(h);
                n(e, a);
                return e
            };
            D.reject = function(a) {
                var e = new this(h);
                q(e, a);
                return e
            };
            D.DC = function(a) {
                x = a
            };
            D.CC = function(a) {
                d = a
            };
            D.AC = d;
            D.prototype = {
                constructor: D,
                then: function(a, e) {
                    var c = this.Ha;
                    if (1 === c && !a || 2 === c && !e) return this;
                    var b = new this.constructor(h),
                        g = this.Sa;
                    if (c) {
                        var k = arguments[c - 1];
                        d(function() {
                            B(c, b, k, g)
                        })
                    } else v(this,
                        b, a, e);
                    return b
                },
                "catch": function(a) {
                    return this.then(null, a)
                }
            };
            (function() {
                var a;
                if ("undefined" !== typeof global) a = global;
                else if ("undefined" !== typeof self) a = self;
                else try {
                    a = Function("return this")()
                } catch (e) {
                    throw Error("polyfill failed because global object is unavailable in this environment");
                }
                var c = a.Promise;
                if (!c || "[object Promise]" !== Object.prototype.toString.call(c.resolve()) || c.HC) D.all = D.all, D.race = D.race, D.reject = D.reject, D.resolve = D.resolve, D.prototype.constructor = D.prototype.constructor,
                    D.prototype.then = D.prototype.then, a.Promise = D
            })()
        }.call(this);
        return Promise
    });
    define("Global", ["EnvironmentStatus", "Environment", "Promise"], function(d, f) {
        var b = {
            Mt: d,
            toString: function() {
                return "[Lightstreamer " + this.library + " client version " + this.version + " build " + this.build + "]"
            },
            qa: function(a, c, b, e) {
                a = (e || "_") + a;
                this[a] || (this[a] = {});
                this[a][c] = b;
                return "Lightstreamer." + a + "." + c
            },
            sj: function(a, c, b) {
                a = (b || "_") + a;
                return this[a] && this[a][c]
            },
            Uq: function(a, c, b) {
                a = (b || "_") + a;
                return this[a] ? this[a][c] : null
            },
            Ii: function(a, c, b) {
                a = (b || "_") + a;
                if (this[a] && this[a][c]) {
                    delete this[a][c];
                    for (var e in this[a]) return;
                    delete this[a]
                }
            },
            hv: function(a, c) {
                var b = (c || "_") + a;
                this[b] && delete this[b]
            },
            Ej: {},
            Hu: function(a, c) {
                var b = this.Ej;
                b[a] || (b[a] = []);
                b[a].push(c)
            },
            oA: function(a, c) {
                var b = this.Ej[a];
                if (b) {
                    for (var e = 0; e < b.length; e++) b[e] == c && b.splice(e, 1);
                    0 == b.length && delete b[a]
                }
            },
            sx: function(a) {
                return this.Ej[a] && (a = this.Ej[a]) && 0 < a.length ? a[0] : null
            }
        };
        f.isBrowserDocument() && (window.OpenAjax && OpenAjax.hub && OpenAjax.hub.registerLibrary("Lightstreamer", "http://www.lightstreamer.com/", b.version),
            window.Lightstreamer = b);
        b.library = "javascript";
        b.version = "7.2.0";
        b.build = "1777";
        return b
    });
    define("Executor", ["Helpers", "EnvironmentStatus", "Environment"], function(d, f, b) {
        function a() {}

        function c(a, b) {
            return a.time === b.time ? a.wn - b.wn : a.time - b.time
        }

        function g() {
            v = !1;
            p()
        }

        function e() {
            if (n) clearInterval(n);
            else if (b.isBrowserDocument() && "undefined" != typeof postMessage) {
                q = function() {
                    window.postMessage("Lightstreamer.run", u)
                };
                var c = function(a) {
                    ("Lightstreamer.run" == a.data && "*" == u || a.origin == u) && g()
                };
                d.addEvent(window, "message", c);
                v || (v = !0, q());
                0 == v && (d.removeEvent(window, "message", c), q = a)
            } else b.isNodeJS() &&
                "undefined" != typeof process && process.nextTick && (q = function() {
                    process.nextTick(g)
                });
            n = setInterval(p, 50)
        }

        function p() {
            if (f.gi) clearInterval(n);
            else {
                var a = l;
                l = d.getTimeStamp();
                l < a && (l = a);
                if (0 < h.length)
                    for (k && (h.sort(c), k = !1); 0 < h.length && h[0].time <= l && !f.gi;) a = h.shift(), a.nf && (z.executeTask(a), a.step && t.push(a));
                for (0 >= h.length && (r = 0); 0 < t.length;) a = t.shift(), a.step && (a.wn = r++, z.addPackedTimedTask(a, a.step, !0));
                l >= m && (m = l + 108E5, h = [].concat(h))
            }
        }
        var k = !1,
            h = [],
            l = d.getTimeStamp(),
            m = l + 108E5,
            t = [],
            n = null,
            r =
            0,
            u = !b.isBrowserDocument() || "http:" != document.location.protocol && "https:" != document.location.protocol ? "*" : document.location.protocol + "//" + document.location.hostname + (document.location.port ? ":" + document.location.port : ""),
            q = a,
            v = !1,
            z = {
                toString: function() {
                    return ["[", "Executor", 50, h.length, "]"].join("|")
                },
                getQueueLength: function() {
                    return h.length
                },
                packTask: function(a, b, c) {
                    return {
                        nf: a,
                        context: b || null,
                        Yb: c || null,
                        wn: r++
                    }
                },
                addPackedTimedTask: function(a, b, c) {
                    a.step = c ? b : null;
                    a.time = l + parseInt(b);
                    if (isNaN(a.time)) try {
                        throw Error();
                    } catch (e) {
                        throw a = "Executor error for time: " + b, e.stack && (a += " " + e.stack), a;
                    }
                    h.push(a);
                    k = !0
                },
                addRepetitiveTask: function(a, b, c, e) {
                    return this.addTimedTask(a, b, c, e, !0)
                },
                stopRepetitiveTask: function(a) {
                    a && (a.nf = null, a.step = null)
                },
                addTimedTask: function(a, b, c, e, d) {
                    a = this.packTask(a, c, e);
                    this.addPackedTimedTask(a, b, d);
                    0 != b || v || (v = !0, q());
                    return a
                },
                modifyTaskParam: function(a, b, c) {
                    a.Yb[b] = c
                },
                modifyAllTaskParams: function(a, b) {
                    a.Yb = b
                },
                delayTask: function(a, b) {
                    a.time += b;
                    k = !0
                },
                executeTask: function(a, b) {
                    try {
                        var c =
                            b || a.Yb;
                        a.context ? c ? a.nf.apply(a.context, c) : a.nf.apply(a.context) : c ? a.nf.apply(null, c) : a.nf()
                    } catch (e) {}
                }
            };
        b.isWebWorker() ? setTimeout(e, 1) : e();
        z.getQueueLength = z.getQueueLength;
        z.packTask = z.packTask;
        z.addPackedTimedTask = z.addPackedTimedTask;
        z.addRepetitiveTask = z.addRepetitiveTask;
        z.stopRepetitiveTask = z.stopRepetitiveTask;
        z.addTimedTask = z.addTimedTask;
        z.modifyTaskParam = z.modifyTaskParam;
        z.modifyAllTaskParams = z.modifyAllTaskParams;
        z.delayTask = z.delayTask;
        z.executeTask = z.executeTask;
        return z
    });
    define("LoggerProxy", ["Helpers"], function(d) {
        function f(a) {
            this.ao(a)
        }

        function b() {
            return !1
        }
        var a = {
            error: b,
            warn: b,
            info: b,
            debug: b,
            fatal: b,
            isDebugEnabled: b,
            isInfoEnabled: b,
            isWarnEnabled: b,
            isErrorEnabled: b,
            isFatalEnabled: b
        };
        f.prototype = {
            ao: function(b) {
                this.Qa = b || a
            },
            logFatal: function(a) {
                this.cy() && (a += this.re(arguments, 1), this.fatal(a))
            },
            fatal: function(a, b) {
                this.Qa.fatal(a, b)
            },
            cy: function() {
                return !this.Qa.isFatalEnabled || this.Qa.isFatalEnabled()
            },
            logError: function(a) {
                this.tr() && (a += this.re(arguments,
                    1), this.error(a))
            },
            logErrorExc: function(a, b) {
                this.tr() && (b += this.re(arguments, 2), this.error(b, a))
            },
            error: function(a, b) {
                this.Qa.error(a, b)
            },
            tr: function() {
                return !this.Qa.isErrorEnabled || this.Qa.isErrorEnabled()
            },
            logWarn: function(a) {
                this.wy() && (a += this.re(arguments, 1), this.warn(a))
            },
            warn: function(a, b) {
                this.Qa.warn(a, b)
            },
            wy: function() {
                return !this.Qa.isWarnEnabled || this.Qa.isWarnEnabled()
            },
            logInfo: function(a) {
                this.isInfoLogEnabled() && (a += this.re(arguments, 1), this.info(a))
            },
            info: function(a, b) {
                this.Qa.info(a,
                    b)
            },
            isInfoLogEnabled: function() {
                return !this.Qa.isInfoEnabled || this.Qa.isInfoEnabled()
            },
            logDebug: function(a) {
                this.isDebugLogEnabled() && (a += this.re(arguments, 1), this.debug(a))
            },
            debug: function(a, b) {
                this.Qa.debug(a, b)
            },
            isDebugLogEnabled: function() {
                return !this.Qa.isDebugEnabled || this.Qa.isDebugEnabled()
            },
            re: function(a, b) {
                for (var e = " {", f = b ? b : 0; f < a.length; f++) try {
                    var k = a[f];
                    null === k ? e += "NULL" : 0 > k.length ? e += "*" : null != k.charAt ? e += k : k.message ? (e += k.message, k.stack && (e += "\n" + k.stack + "\n")) : k[0] == k ? e += k : d.isArray(k) ?
                        (e += "(", e += this.re(k), e += ")") : e += k;
                    e += " "
                } catch (h) {
                    e += "missing-parameter "
                }
                return e + "}"
            }
        };
        f.prototype.debug = f.prototype.debug;
        f.prototype.isDebugLogEnabled = f.prototype.isDebugLogEnabled;
        f.prototype.logDebug = f.prototype.logDebug;
        f.prototype.info = f.prototype.info;
        f.prototype.isInfoLogEnabled = f.prototype.isInfoLogEnabled;
        f.prototype.logInfo = f.prototype.logInfo;
        f.prototype.warn = f.prototype.warn;
        f.prototype.isWarnEnabled = f.prototype.isWarnEnabled;
        f.prototype.logWarn = f.prototype.logWarn;
        f.prototype.error =
            f.prototype.error;
        f.prototype.isErrorEnabled = f.prototype.isErrorEnabled;
        f.prototype.logError = f.prototype.logError;
        f.prototype.logErrorExc = f.prototype.logErrorExc;
        f.prototype.fatal = f.prototype.fatal;
        f.prototype.isFatalEnabled = f.prototype.isFatalEnabled;
        f.prototype.logFatal = f.prototype.logFatal;
        return f
    });
    define("IllegalArgumentException", [], function() {
        function d(d) {
            this.name = "IllegalArgumentException";
            this.message = d
        }
        d.prototype = {
            toString: function() {
                return ["[", this.name, this.message, "]"].join("|")
            }
        };
        return d
    });
    define("LoggerManager", ["LoggerProxy", "IllegalArgumentException"], function(d, f) {
        var b = {},
            a = null,
            c = {
                setLoggerProvider: function(c) {
                    if (c && !c.getLogger) throw new f("The given object is not a LoggerProvider");
                    a = c;
                    for (var d in b) a ? b[d].ao(a.getLogger(d)) : b[d].ao(null)
                },
                getLoggerProxy: function(c) {
                    b[c] || (b[c] = a ? new d(a.getLogger(c)) : new d);
                    return b[c]
                },
                resolve: function(a) {
                    return a
                }
            };
        c.setLoggerProvider = c.setLoggerProvider;
        c.getLoggerProxy = c.getLoggerProxy;
        c.resolve = c.resolve;
        return c
    });
    define("lscAe", ["Environment"], function(d) {
        return {
            Te: 1E3,
            Yo: 200,
            cu: 1E4,
            St: 1,
            ni: 0,
            vC: 2,
            Oo: 3,
            Xo: 4,
            No: 5,
            fc: "N",
            Ot: 200,
            Wo: "MAIN",
            oi: "wbridge",
            li: "fbridge",
            $t: 1,
            Zt: 2,
            Qk: "1777",
            vg: !d.isBrowserDocument() || "http:" != document.location.protocol && "https:" != document.location.protocol ? "file:" : document.location.protocol,
            cb: "lightstreamer.stream",
            Se: "lightstreamer.protocol",
            gc: "lightstreamer.session",
            Zo: "lightstreamer.requests",
            ap: "lightstreamer.subscriptions",
            Wt: "lightstreamer.messages",
            Ok: "lightstreamer.actions",
            Eb: "lightstreamer.sharing",
            uC: "lightstreamer.crosstab",
            Uo: "lightstreamer.flash",
            yC: "lightstreamer.stats",
            Yd: "Lightstreamer_",
            Uk: "lightstreamer",
            Fc: "UNORDERED_MESSAGES",
            Ue: {
                length: -1,
                toString: function() {
                    return "[UNCHANGED]"
                }
            },
            CONNECTING: "CONNECTING",
            Ra: "CONNECTED:",
            xg: "STREAM-SENSING",
            Bg: "WS-STREAMING",
            Xd: "HTTP-STREAMING",
            yg: "STALLED",
            Zd: "WS-POLLING",
            ec: "HTTP-POLLING",
            Db: "DISCONNECTED",
            Ag: "DISCONNECTED:WILL-RETRY",
            zg: "DISCONNECTED:TRYING-RECOVERY",
            pi: "WS",
            Qe: "HTTP",
            Wk: "RAW",
            Sk: "DISTINCT",
            ug: "COMMAND",
            Vk: "MERGE",
            mi: "MASTER"
        }
    });
    define("lscAj", ["Environment", "lscAe", "Helpers"], function(d, f, b) {
        var a = RegExp("\\.", "g"),
            c = RegExp("-", "g"),
            g = {
                vr: function() {
                    return d.isBrowser() ? !1 === navigator.onLine : !1
                },
                Ip: function() {
                    try {
                        return "undefined" != typeof localStorage && null !== localStorage && localStorage.getItem && localStorage.setItem ? (localStorage.setItem("__canUseLocalStorage_test__", "true"), localStorage.removeItem("__canUseLocalStorage_test__"), !0) : !1
                    } catch (a) {
                        return !1
                    }
                },
                sc: function() {
                    try {
                        return document.domain
                    } catch (a) {
                        return ""
                    }
                },
                rj: function() {
                    if (!d.isBrowserDocument()) return !0;
                    try {
                        return -1 < document.location.host.indexOf("[") ? !0 : g.sc() == document.location.hostname
                    } catch (a) {
                        return !1
                    }
                },
                oc: function(a) {
                    if ("undefined" != typeof a) {
                        if (!0 === a || !1 === a) return !0 === a;
                        if (null != a) {
                            if ("number" == typeof a || a instanceof Number) return Number(a);
                            if (b.isArray(a)) {
                                for (var c = [], g = 0; g < a.length; g++) c[g] = this.oc(a[g]);
                                return c
                            }
                            if ("string" == typeof a || a instanceof String) return String(a);
                            if (-1 === a.length) return f.Ue;
                            if (isNaN(a) && "number" == typeof a) return NaN;
                            c = {};
                            for (g in a) c[this.oc(g)] = this.oc(a[g]);
                            return c
                        }
                    }
                    return null
                },
                ra: function(a, c) {
                    a = a || {};
                    if (c)
                        for (var b in c) a[b] = c[b];
                    return a
                },
                mk: function(e) {
                    return e.replace(a, "_").replace(c, "__")
                },
                getReverse: function(a) {
                    var c = {},
                        b;
                    for (b in a) c[a[b]] = b;
                    return c
                },
                Ai: function(a) {
                    if (a && !a.pop) {
                        for (var c = [], b = 0; b < a.length; b++) c.push(a[b]);
                        return c
                    }
                    return a
                },
                Xz: function(a) {
                    if (!a) return [];
                    for (var c = {
                            Lx: 0,
                            next: function() {
                                return a.charAt(this.Lx++)
                            }
                        }, b = /^\s*Expires/i, h = [], g = c.next(); g;) {
                        for (var d = "", t = ""; g && ";" != g && "," != g;) t += g, g = c.next();
                        t = t.trim();
                        d += t;
                        ";" ==
                        g && (d += "; ", g = c.next());
                        for (; g && "," != g;) {
                            for (t = ""; g && ";" != g && "," != g;) t += g, g = c.next();
                            if (t.match(b))
                                for (console.assert("," == g), t += g, g = c.next(); g && ";" != g && "," != g;) t += g, g = c.next();
                            t = t.trim();
                            d += t;
                            ";" == g && (d += "; ", g = c.next())
                        }
                        h.push(d);
                        g = c.next()
                    }
                    return h
                }
            };
        return g
    });
    define("Inheritance", ["IllegalStateException"], function(d) {
        function f(a, b, d) {
            if (b) return d ? b.apply(a, d) : b.apply(a)
        }
        var b = {
            Tt: function(a, c, g, e) {
                for (var f in c.prototype)
                    if (!a.prototype[f]) a.prototype[f] = c.prototype[f];
                    else if (e) {
                    var k;
                    a: {
                        k = c.prototype;
                        var h = void 0;
                        for (h in k)
                            if (k[f] == k[h] && f != h) {
                                k = h;
                                break a
                            } k = null
                    }
                    if (k) {
                        if (a.prototype[k] && a.prototype[k] !== a.prototype[f] && c.prototype[k] !== c.prototype[k]) throw new d("Can't solve alias collision, try to minify the classes again (" + k + ", " + f + ")");
                        a.prototype[k] =
                            a.prototype[f]
                    }
                }
                g || (a.prototype._super_ = c, a.prototype._callSuperConstructor = b._callSuperConstructor, a.prototype._callSuperMethod = b._callSuperMethod);
                return a
            },
            _callSuperMethod: function(a, b, d) {
                return f(this, a.prototype._super_.prototype[b], d)
            },
            _callSuperConstructor: function(a, b) {
                f(this, a.prototype._super_, b)
            }
        };
        return b.Tt
    });
    define("Setter", ["IllegalArgumentException"], function(d) {
        function f() {}
        f.prototype.checkPositiveNumber = function(b, a, c) {
            var g = new Number(b);
            if (isNaN(g)) throw new d("The given value is not valid. Use a number");
            if (!c && g != Math.round(g)) throw new d("The given value is not valid. Use an integer");
            if (a) {
                if (0 > b) throw new d("The given value is not valid. Use a positive number or 0");
            } else if (0 >= b) throw new d("The given value is not valid. Use a positive number");
            return g
        };
        f.prototype.checkBool = function(b,
            a) {
            if (!0 === b || !1 === b || a && !b) return !0 === b;
            throw new d("The given value is not valid. Use true or false");
        };
        return f
    });
    define("lscA", ["LoggerManager", "lscAj", "Inheritance", "Setter", "lscAe"], function(d, f, b, a, c) {
        function g(a) {
            this.V = "lscA";
            this.parent = null;
            this.Cp = !1;
            a && this.uv(a)
        }
        d.getLoggerProxy(c.Ok);
        d.getLoggerProxy(c.Eb);
        g.prototype = {
            oj: function(a) {
                return this.rg[a]
            },
            X: function(a, c) {
                var b = this.oj(a),
                    g = this[b];
                this[b] = f.oc(c);
                this.parent && this.Cp && this.af(a);
                g != this[b] && this.Tr(a)
            },
            H: function(a, c) {
                var b = this.oj(a);
                c != this[b] && (this[b] = c, this.af(a), this.Tr(a))
            },
            lg: function(a, c) {
                this.parent = a;
                this.Cp = c
            },
            af: function(a) {
                var c =
                    this.oj(a);
                return this.parent && this.parent.af && !this.parent.af(this.V, a, f.oc(this[c])) ? !1 : !0
            },
            Tr: function(a) {
                var c = this.oj(a);
                !this.parent || !this.parent.Vr || this.Rr && this.Rr[c] || this.parent.Vr(a, this)
            },
            uv: function(a) {
                var c = this.rg,
                    b;
                for (b in c) this.X(b, a[c[b]])
            },
            qm: function(a) {
                for (var c in this.rg) a(c, this[this.rg[c]])
            }
        };
        b(g, a, !1, !0);
        return g
    });
    define("lscC", ["lscA", "Inheritance", "lscAj"], function(d, f, b) {
        function a(b) {
            this.Qg = !1;
            this.sd = 0;
            this.Rr = c;
            this.rg = g;
            this._callSuperConstructor(a, arguments);
            this.V = "lscC"
        }
        var c = {},
            g = {
                Qg: "connectionRequested",
                sd: "clientsCount"
            },
            g = b.getReverse(g);
        a.prototype = {};
        f(a, d);
        return a
    });
    define("RetryDelayCounter", ["LoggerManager", "lscAe"], function(d, f) {
        function b(a) {
            this.Nm(a)
        }
        var a = d.getLoggerProxy(f.gc);
        b.prototype = {
            Qs: function(c) {
                this.Nm(c);
                a.isDebugLogEnabled() && a.debug("Reset currentRetryDelay: " + this.Oc)
            },
            pr: function() {
                9 <= this.On && this.Oc < this.Hj && (this.Oc *= 2, this.Oc > this.Hj && (this.Oc = this.Hj), a.isDebugLogEnabled() && a.debug("Increase currentRetryDelay: " + this.Oc));
                this.On++
            },
            Nm: function(a) {
                this.Sy = this.Oc = a;
                this.Hj = Math.max(6E4, a);
                this.On = 0
            }
        };
        return b
    });
    define("ConnectTimeoutCounter", ["LoggerManager", "lscAe"], function(d, f) {
        function b(a) {
            this.Mm(a)
        }
        var a = d.getLoggerProxy(f.gc);
        b.prototype = {
            Os: function(c) {
                this.Mm(c);
                a.isDebugLogEnabled() && a.debug("Reset currentConnectTimeout: " + this.pc)
            },
            Km: function() {
                9 <= this.Rl && this.pc < this.Gj && (this.pc *= 2, this.pc > this.Gj && (this.pc = this.Gj), a.isDebugLogEnabled() && a.debug("Increase currentConnectTimeout: " + this.pc));
                this.Rl++
            },
            Mm: function(a) {
                this.Ry = this.pc = a;
                this.Gj = Math.max(6E4, a);
                this.Rl = 0
            }
        };
        return b
    });
    define("lscE", "IllegalArgumentException lscAe lscA Inheritance Global Environment lscAj RetryDelayCounter ConnectTimeoutCounter".split(" "), function(d, f, b, a, c, g, e, p, k) {
        function h() {
            this.Ul = 4E6;
            this.vj = 19E3;
            this.De = this.Wb = this.Ef = 0;
            this.Hd = 3E3;
            this.Bk = 2E3;
            this.hg = 4E3;
            this.Nm(this.hg);
            this.Mm(this.hg);
            this.cj = 100;
            this.fo = !1;
            this.fj = null;
            this.cq = this.Wn = !1;
            this.ig = 0;
            this.dm = !1;
            this.ho = 5E3;
            this.nh = this.Ak = null;
            this.uj = !1;
            this.Qh = 15E3;
            this.Li = this.Io = !0;
            this.dj = 2E3;
            this.ro = 4E3;
            this.rg =
                m;
            this._callSuperConstructor(h, arguments);
            this.V = "lscE"
        }
        var l = {};
        l[f.Xd] = !0;
        l[f.Zd] = !0;
        l[f.ec] = !0;
        l[f.Bg] = !0;
        l[f.pi] = !0;
        l[f.Qe] = !0;
        var m = {
                Ul: "contentLength",
                vj: "idleTimeout",
                Ef: "keepaliveInterval",
                Wb: "maxBandwidth",
                De: "pollingInterval",
                Hd: "reconnectTimeout",
                Bk: "stalledTimeout",
                hg: "retryDelay",
                cj: "firstRetryMaxDelay",
                fo: "slowingEnabled",
                fj: "forcedTransport",
                Wn: "serverInstanceAddressIgnored",
                cq: "cookieHandlingRequired",
                ig: "reverseHeartbeatInterval",
                dm: "earlyWSOpenEnabled",
                Qh: "sessionRecoveryTimeout",
                ho: "spinFixTimeout",
                Ak: "spinFixEnabled",
                Io: "xDomainStreamingEnabled",
                Li: "corsXHREnabled",
                dj: "forceBindTimeout",
                ro: "switchCheckTimeout",
                nh: "httpExtraHeaders",
                uj: "httpExtraHeadersOnSessionCreationOnly",
                Oc: "currentRetryDelay",
                Sy: "minRetryDelay",
                Hj: "maxRetryDelay",
                On: "retryAttempt",
                pc: "currentConnectTimeout",
                Ry: "minConnectTimeout",
                Gj: "maxConnectTimeout",
                Rl: "connectAttempt"
            },
            m = e.getReverse(m);
        h.prototype = {
            PA: function(a) {
                this.H("contentLength", this.checkPositiveNumber(a))
            },
            Dw: function() {
                return this.Ul
            },
            lt: function(a) {
                this.H("idleTimeout", this.checkPositiveNumber(a, !0))
            },
            Xq: function() {
                return this.vj
            },
            nt: function(a) {
                this.H("keepaliveInterval", this.checkPositiveNumber(a, !0))
            },
            Yq: function() {
                return this.Ef
            },
            bB: function(a) {
                a = "unlimited" == (new String(a)).toLowerCase() ? 0 : this.checkPositiveNumber(a, !1, !0);
                this.H("maxBandwidth", a)
            },
            Ww: function() {
                return 0 >= this.Wb ? "unlimited" : this.Wb
            },
            ot: function(a) {
                this.H("pollingInterval", this.checkPositiveNumber(a, !0))
            },
            dr: function() {
                return this.De
            },
            hB: function(a) {
                this.H("reconnectTimeout",
                    this.checkPositiveNumber(a))
            },
            gx: function() {
                return this.Hd
            },
            tB: function(a) {
                this.H("stalledTimeout", this.checkPositiveNumber(a))
            },
            wx: function() {
                return this.Bk
            },
            NA: function() {},
            Aw: function() {
                return String(this.Em())
            },
            SA: function() {},
            xd: function() {
                return this.pc
            },
            pt: function(a) {
                a = this.checkPositiveNumber(a);
                this.H("retryDelay", a);
                this.Qs(a);
                this.Os(a)
            },
            Em: function() {
                return this.hg
            },
            VA: function(a) {
                this.H("firstRetryMaxDelay", this.checkPositiveNumber(a))
            },
            Mw: function() {
                return this.cj
            },
            pB: function(a) {
                this.H("slowingEnabled",
                    this.checkBool(a))
            },
            oy: function() {
                return this.fo
            },
            XA: function(a) {
                if (null !== a && !l[a]) throw new d("The given value is not valid. Use one of: HTTP-STREAMING, HTTP-POLLING, WS-STREAMING, WS-POLLING, WS, HTTP or null");
                this.H("forcedTransport", a)
            },
            Rw: function() {
                return this.fj
            },
            lB: function(a) {
                this.H("serverInstanceAddressIgnored", this.checkBool(a))
            },
            ny: function() {
                return this.Wn
            },
            QA: function(a) {
                if (a && !g.isBrowser() && !g.isNodeJS()) throw new d("cookieHandlingRequired is only supported on Browsers");
                this.H("cookieHandlingRequired",
                    this.checkBool(a))
            },
            Tb: function() {
                return this.cq
            },
            UA: function(a) {
                this.H("earlyWSOpenEnabled", this.checkBool(a))
            },
            by: function() {
                return this.dm
            },
            qt: function(a) {
                this.H("reverseHeartbeatInterval", this.checkPositiveNumber(a, !0))
            },
            fr: function() {
                return this.ig
            },
            YA: function(a) {
                if (a) {
                    var c = "",
                        b;
                    for (b in a) c += b + "\n" + a[b] + "\n";
                    this.H("httpExtraHeaders", c)
                } else this.H("httpExtraHeaders", null)
            },
            Wq: function() {
                if (!this.nh) return this.nh;
                for (var a = {}, c = this.nh.split("\n"), b = 0; b < c.length - 1; b += 2) a[c[b]] = c[b + 1];
                return a
            },
            ZA: function(a) {
                this.H("httpExtraHeadersOnSessionCreationOnly", this.checkBool(a))
            },
            ey: function() {
                return this.uj
            },
            oB: function(a) {
                this.H("sessionRecoveryTimeout", this.checkPositiveNumber(a, !0))
            },
            rx: function() {
                return this.Qh
            },
            mh: function(a) {
                return this.nh ? a ? !0 : !this.uj : !1
            },
            ah: function(a) {
                return !a && this.uj ? null : this.Wq()
            },
            xB: function(a) {
                this.H("xDomainStreamingEnabled", this.checkBool(a))
            },
            xy: function() {
                return this.Io
            },
            RA: function(a) {
                this.H("corsXHREnabled", this.checkBool(a))
            },
            $x: function() {
                return this.Li
            },
            WA: function(a) {
                this.H("forceBindTimeout", this.checkPositiveNumber(a))
            },
            Pw: function() {
                return this.dj
            },
            uB: function(a) {
                this.H("switchCheckTimeout", this.checkPositiveNumber(a))
            },
            yx: function() {
                return this.ro
            },
            sB: function(a) {
                this.H("spinFixTimeout", this.checkPositiveNumber(a))
            },
            vx: function() {
                return this.ho
            },
            rB: function(a) {
                this.H("spinFixTimeout", null === this.BC ? null : this.checkBool(a))
            },
            ux: function() {
                return this.Ak
            }
        };
        h.prototype.setContentLength = h.prototype.PA;
        h.prototype.getContentLength = h.prototype.Dw;
        h.prototype.setIdleTimeout = h.prototype.lt;
        h.prototype.getIdleTimeout = h.prototype.Xq;
        h.prototype.setKeepaliveInterval = h.prototype.nt;
        h.prototype.getKeepaliveInterval = h.prototype.Yq;
        h.prototype.setMaxBandwidth = h.prototype.bB;
        h.prototype.getMaxBandwidth = h.prototype.Ww;
        h.prototype.setPollingInterval = h.prototype.ot;
        h.prototype.getPollingInterval = h.prototype.dr;
        h.prototype.setReconnectTimeout = h.prototype.hB;
        h.prototype.getReconnectTimeout = h.prototype.gx;
        h.prototype.setStalledTimeout = h.prototype.tB;
        h.prototype.getStalledTimeout =
            h.prototype.wx;
        h.prototype.setConnectTimeout = h.prototype.NA;
        h.prototype.getConnectTimeout = h.prototype.Aw;
        h.prototype.setCurrentConnectTimeout = h.prototype.SA;
        h.prototype.getCurrentConnectTimeout = h.prototype.xd;
        h.prototype.setRetryDelay = h.prototype.pt;
        h.prototype.getRetryDelay = h.prototype.Em;
        h.prototype.setFirstRetryMaxDelay = h.prototype.VA;
        h.prototype.getFirstRetryMaxDelay = h.prototype.Mw;
        h.prototype.setSlowingEnabled = h.prototype.pB;
        h.prototype.isSlowingEnabled = h.prototype.oy;
        h.prototype.setForcedTransport =
            h.prototype.XA;
        h.prototype.getForcedTransport = h.prototype.Rw;
        h.prototype.setServerInstanceAddressIgnored = h.prototype.lB;
        h.prototype.isServerInstanceAddressIgnored = h.prototype.ny;
        h.prototype.setCookieHandlingRequired = h.prototype.QA;
        h.prototype.isCookieHandlingRequired = h.prototype.Tb;
        h.prototype.setEarlyWSOpenEnabled = h.prototype.UA;
        h.prototype.isEarlyWSOpenEnabled = h.prototype.by;
        h.prototype.setReverseHeartbeatInterval = h.prototype.qt;
        h.prototype.getReverseHeartbeatInterval = h.prototype.fr;
        h.prototype.setHttpExtraHeaders =
            h.prototype.YA;
        h.prototype.getHttpExtraHeaders = h.prototype.Wq;
        h.prototype.setHttpExtraHeadersOnSessionCreationOnly = h.prototype.ZA;
        h.prototype.isHttpExtraHeadersOnSessionCreationOnly = h.prototype.ey;
        h.prototype.setSessionRecoveryTimeout = h.prototype.oB;
        h.prototype.getSessionRecoveryTimeout = h.prototype.rx;
        h.prototype.setXDomainStreamingEnabled = h.prototype.xB;
        h.prototype.isXDomainStreamingEnabled = h.prototype.xy;
        h.prototype.setCorsXHREnabled = h.prototype.RA;
        h.prototype.isCorsXHREnabled = h.prototype.$x;
        h.prototype.setForceBindTimeout =
            h.prototype.WA;
        h.prototype.getForceBindTimeout = h.prototype.Pw;
        h.prototype.setSwitchCheckTimeout = h.prototype.uB;
        h.prototype.getSwitchCheckTimeout = h.prototype.yx;
        h.prototype.setSpinFixTimeout = h.prototype.sB;
        h.prototype.getSpinFixTimeout = h.prototype.vx;
        h.prototype.setSpinFixEnabled = h.prototype.rB;
        h.prototype.getSpinFixEnabled = h.prototype.ux;
        h.prototype.setRetryTimeout = h.prototype.pt;
        h.prototype.getRetryTimeout = h.prototype.Em;
        h.prototype.setIdleMillis = h.prototype.lt;
        h.prototype.getIdleMillis = h.prototype.Xq;
        h.prototype.setKeepaliveMillis = h.prototype.nt;
        h.prototype.getKeepaliveMillis = h.prototype.Yq;
        h.prototype.setPollingMillis = h.prototype.ot;
        h.prototype.getPollingMillis = h.prototype.dr;
        h.prototype.setReverseHeartbeatMillis = h.prototype.qt;
        h.prototype.getReverseHeartbeatMillis = h.prototype.fr;
        a(h, b);
        a(h, p, !0);
        a(h, k, !0);
        return h
    });
    define("lscAf", [], function() {
        return {
            MC: function() {
                var d = 3,
                    f, b = 6,
                    a = "",
                    c;
                c = "document".toString();
                var g = 0;
                f = c.length;
                for (var e = 0; e < f; e++) g += c.charCodeAt(e);
                c = parseInt(g);
                if (0 < c)
                    for (g = 0; 184 >= b + d - g; g += 3) f = g, f = parseInt("2844232422362353182342452312352492633183053182412392513042362492412532492362342352342462472452423042312312313182482393182292342362492382392362383182422532332342512492422422492342402770".substring(g, d - 1)) - parseInt("2844232422362353182342452312352492633183053182412392513042362492412532492362342352342462472452423042312312313182482393182292342362492382392362383182422532332342512492422422492342402770".substring(f,
                        f + 2)) + 350 - parseInt("2844232422362353182342452312352492633183053182412392513042362492412532492362342352342462472452423042312312313182482393182292342362492382392362383182422532332342512492422422492342402770".substring(b, b + d - g)), a = unescape("%" + f.toString(16)) + a, d += 3, b += 3, c += f;
                return a
            }
        }
    });
    define("ASSERT", ["LoggerManager"], function(d) {
        var f = d.getLoggerProxy("weswit.test"),
            b = 0,
            a = {},
            c = {
                VOID: a,
                getFailures: function() {
                    return b
                },
                compareArrays: function(a, b, c) {
                    if (a.length != b.length) return this.Lb(), f.logError(d.resolve(450), a, b), !1;
                    if (c)
                        for (k = 0; k < a.length; k++) {
                            if (a[k] != b[k]) return f.logError(d.resolve(453), a[k], b[k]), this.Lb(), !1
                        } else {
                            c = {};
                            for (var k = 0; k < a.length; k++) c[a[k]] = 1;
                            for (k = 0; k < b.length; k++)
                                if (c[b[k]]) c[b[k]]++;
                                else return f.logError(d.resolve(451), b[k]), this.Lb(), !1;
                            for (k in c)
                                if (1 ==
                                    c[k]) return f.logError(d.resolve(452), c[k]), this.Lb(), !1
                        }
                    return !0
                },
                verifySuccess: function(a, b, c, d, f) {
                    return this.verify(a, b, c, d, !1, f)
                },
                verifyException: function(a, b, c) {
                    return this.verify(a, b, c, null, !0)
                },
                verifyNotNull: function(a) {
                    return null === a ? (this.Lb(), f.logError(d.resolve(454), a), !1) : !0
                },
                verifyValue: function(a, b, c) {
                    var k = !1;
                    !0 === c ? k = a === b : c ? k = c(a, b) : isNaN(a) ? k = a == b : (c = a && a.charAt ? a.charAt(0) : null, k = b && b.charAt ? b.charAt(0) : null, k = "." == c || " " == c || "0" == c || "." == k || " " == k || "0" == k ? String(a) == String(b) :
                        a == b);
                    return k ? !0 : (this.Lb(), f.logError(d.resolve(455), a, b), !1)
                },
                verifyDiffValue: function(a, b, c) {
                    return (c ? a === b : a == b) ? (this.Lb(), f.logError(d.resolve(456), a, b), !1) : !0
                },
                verifyOk: function(a) {
                    return a ? !0 : (this.Lb(), f.logError(d.resolve(457)), !1)
                },
                verifyNotOk: function(a) {
                    return a ? (this.Lb(), f.logError(d.resolve(458)), !1) : !0
                },
                fail: function() {
                    f.logError(d.resolve(459));
                    this.Lb();
                    return !1
                },
                Lb: function() {
                    b++
                },
                verify: function(b, c, p, k, h, l) {
                    var m = !1,
                        t = null,
                        n = null;
                    try {
                        t = p !== a ? b[c].apply(b, p) : b[c]()
                    } catch (r) {
                        m = !0, n = r
                    }
                    b = h ? "succes" : "failure";
                    return h != m ? (this.Lb(), f.logError(d.resolve(460), b, "for", c, p, k, n), !1) : h || k === a ? !0 : this.verifyValue(t, k, l)
                }
            };
        c.getFailures = c.getFailures;
        c.fail = c.fail;
        c.verifyNotOk = c.verifyNotOk;
        c.verifyOk = c.verifyOk;
        c.verifyDiffValue = c.verifyDiffValue;
        c.verifyNotNull = c.verifyNotNull;
        c.verifyValue = c.verifyValue;
        c.verifyException = c.verifyException;
        c.verifySuccess = c.verifySuccess;
        c.compareArrays = c.compareArrays;
        return c
    });
    define("lscq", "LoggerManager lscAj lscAf Environment ASSERT lscAe".split(" "), function(d, f, b, a, c, g) {
        var e = d.getLoggerProxy(g.Se),
            p = "LS_cid\x3dpcYgxn8m8 feOojyA1T681f3g2.pz479mDv\x26",
            k = /^[a-z][a-z0-9-]+$/,
            h = /^((?:[a-z][a-z.0-9-]+).(?:[a-z][a-z-]+))(?![\w.])/,
            l = /^((?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?).){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))(?![d])/,
            m = /^[a-f0-9:]+$/;
        return {
            kC: function(a) {
                a = a.toLowerCase();
                var c = 0 == a.indexOf("http://") ? 7 : 0 == a.indexOf("https://") ? 8 : -1;
                if (-1 ==
                    c) return "The given server address has not a valid scheme";
                var b = a.lastIndexOf(":"),
                    b = b > c ? b : a.length,
                    e = this.xq(a, a.indexOf("://"));
                if (null != e && isNaN(e.substring(1))) return "The given server address has not a valid port";
                e = a.indexOf("/", c);
                e = e < b ? e : b;
                if ("[" == a.charAt(c)) {
                    if (a = a.substring(c + 1, a.lastIndexOf("]")), !m.test(a)) return "The given server address is not a valid IPv6"
                } else if (a = a.substring(c, e), -1 < a.indexOf(".")) {
                    if (!h.test(a) && !l.test(a)) return "The given server address is not a valid URL"
                } else if (!k.test(a)) return "The given server address is not a valid machine name";
                return !0
            },
            xq: function(a, c) {
                var b = a.indexOf(":", c + 1);
                if (-1 >= b) return null;
                if (-1 < a.indexOf("]")) {
                    b = a.indexOf("]:");
                    if (-1 >= b) return null;
                    b += 1
                } else if (b != a.lastIndexOf(":")) return null;
                var e = a.indexOf("/", c + 3);
                return -1 < e ? a.substring(b, e) : a.substring(b)
            },
            ov: function(a, c) {
                var b = this.xq(a, a.indexOf("://"));
                if (b) {
                    var e = c.indexOf("/");
                    c = -1 >= e ? c + b : c.substring(0, e) + b + c.substring(e)
                }
                c = 0 == a.toLowerCase().indexOf("https://") ? "https://" + c : "http://" + c;
                "/" != c.substr(c.length - 1) && (c += "/");
                return c
            },
            ex: function(b, g,
                h, k, l, v, m, C, B, w, H) {
                H = H && a.isBrowserDocument() && !f.rj() ? "LS_domain\x3d" + f.sc() + "\x26" : "";
                b = "LS_phase\x3d" + b + "\x26" + H + (C ? "LS_cause\x3d" + C + "\x26" : "");
                l || v ? (b += "LS_polling\x3dtrue\x26", C = w = 0, v && (w = Number(h.De), null == B || isNaN(B) || (w += B), C = h.vj), isNaN(w) || (b += "LS_polling_millis\x3d" + w + "\x26"), isNaN(C) || (b += "LS_idle_millis\x3d" + C + "\x26")) : (0 < h.Ef && (b += "LS_keepalive_millis\x3d" + h.Ef + "\x26"), 0 < h.ig && (b += "LS_inactivity_millis\x3d" + h.ig + "\x26"), w && (b += "LS_content_length\x3d" + h.Ul + "\x26"));
                if (l) return g = "", 0 <
                    h.Wb && (g += "LS_requested_max_bandwidth\x3d" + h.Wb + "\x26"), null != k.yi && (g += "LS_adapter_set\x3d" + encodeURIComponent(k.yi) + "\x26"), null != k.Jk && (g += "LS_user\x3d" + encodeURIComponent(k.Jk) + "\x26"), h = "LS_op2\x3dcreate\x26" + b + p + g, m && (h += "LS_old_session\x3d" + m + "\x26"), e.logDebug(d.resolve(6), h), null != k.password && (h += "LS_password\x3d" + encodeURIComponent(k.password) + "\x26"), h;
                c.verifyOk(g) || e.logError(d.resolve(4));
                k = "LS_session\x3d" + g + "\x26" + b;
                e.logDebug(d.resolve(5), k);
                return k
            },
            hx: function(c, b, g, h, k, l, p) {
                l =
                    l && a.isBrowserDocument() && !f.rj() ? "LS_domain\x3d" + f.sc() + "\x26" : "";
                c = "LS_phase\x3d" + c + "\x26" + l + (h ? "LS_cause\x3d" + h + "\x26" : "") + "LS_polling\x3dtrue\x26";
                h = 0;
                null == k || isNaN(k) || (h += k);
                c += "LS_polling_millis\x3d" + h + "\x26";
                c += "LS_idle_millis\x3d0\x26";
                0 < g.Wb && (c += "LS_requested_max_bandwidth\x3d" + g.Wb + "\x26");
                c += "LS_session\x3d" + b + "\x26";
                c += "LS_recovery_from\x3d" + p + "\x26";
                e.logDebug(d.resolve(7), c);
                return c
            },
            Jw: function(a, c) {
                var b = {
                    LS_op: "destroy",
                    LS_session: a
                };
                c && (b.LS_cause = c);
                e.logDebug(d.resolve(8));
                return b
            },
            Qw: function(a, c) {
                var b = {
                    LS_op: "force_rebind"
                };
                a && (b.LS_cause = a);
                null == c || isNaN(c) || (b.LS_polling_millis = c);
                e.logDebug(d.resolve(9));
                return b
            },
            Vw: function(a, c, b) {
                c.LS_build = b;
                c.LS_phase = a;
                return c
            },
            Bw: function(a) {
                return {
                    LS_op: "constrain",
                    LS_requested_max_bandwidth: 0 < a.Wb ? a.Wb : 0
                }
            },
            er: function(a, c, b) {
                a = c || ".js" == b || "" == b ? (a ? this.vm() + "create_session" : "bind_session") + b : (a ? this.vm() : "") + "STREAMING_IN_PROGRESS";
                e.logDebug(d.resolve(10), a);
                return a
            },
            ix: function(a) {
                return "bind_session" + a
            },
            vm: function() {
                return ""
            },
            UC: function(a) {
                p = a
            }
        }
    });
    define("lscD", "IllegalArgumentException lscA Inheritance Environment Global lscq lscAj".split(" "), function(d, f, b, a, c, g, e) {
        function p() {
            this.Oh = h;
            this.sessionId = this.ft = this.et = this.password = this.Jk = this.yi = null;
            this.rg = k;
            this._callSuperConstructor(p, arguments);
            this.V = "lscD"
        }
        var k = {
                Oh: "serverAddress",
                yi: "adapterSet",
                Jk: "user",
                password: "password",
                et: "serverInstanceAddress",
                ft: "serverSocketName",
                sessionId: "sessionId"
            },
            k = e.getReverse(k),
            h = !a.isBrowser() || "http:" !=
            location.protocol && "https:" != location.protocol ? null : location.protocol + "//" + location.hostname + (location.port ? ":" + location.port : "") + "/";
        p.prototype = {
            rt: function(a) {
                if (null === a) a = h;
                else {
                    "/" != a.substr(a.length - 1) && (a += "/");
                    var c = g.kC(a);
                    if (!0 !== c) throw new d(c);
                }
                this.H("serverAddress", a)
            },
            gr: function() {
                return this.Oh
            },
            gt: function(a) {
                this.H("adapterSet", a)
            },
            qw: function() {
                return this.yi
            },
            wB: function(a) {
                this.H("user", a)
            },
            Dx: function() {
                return this.Jk
            },
            dB: function(a) {
                this.H("password", a)
            },
            px: function() {
                return this.et
            },
            qx: function() {
                return this.ft
            },
            Qb: function() {
                return this.sessionId
            }
        };
        p.prototype.setServerAddress = p.prototype.rt;
        p.prototype.getServerAddress = p.prototype.gr;
        p.prototype.setAdapterSet = p.prototype.gt;
        p.prototype.getAdapterSet = p.prototype.qw;
        p.prototype.setUser = p.prototype.wB;
        p.prototype.getUser = p.prototype.Dx;
        p.prototype.setPassword = p.prototype.dB;
        p.prototype.getServerInstanceAddress = p.prototype.px;
        p.prototype.getServerSocketName = p.prototype.qx;
        p.prototype.getSessionId = p.prototype.Qb;
        b(p, f);
        return p
    });
    define("lscAi", [], function() {
        function d(d) {
            this.yn = [];
            this.bound = this.Hk = !1;
            this.value = null;
            this.aj = !1;
            var b = this;
            d(function() {
                return b.Gz.apply(b, arguments)
            }, function() {
                return b.ns.apply(b, arguments)
            })
        }
        d.resolve = function(f) {
            return new d(function(b) {
                b(f)
            })
        };
        d.reject = function(f) {
            return new d(function(b, a) {
                a(f)
            })
        };
        d.prototype = {
            then: function(d, b) {
                this.Hk ? this.Xs(d, b) : this.yn.push({
                    zz: d,
                    xz: b
                });
                return this
            },
            Gz: function(d) {
                if (this.Hk || this.bound) return null;
                if (d && d.then && d.constructor === this.constructor) {
                    this.bound = !0;
                    var b = this;
                    d.then(function(a) {
                        b.zo(a, !0);
                        return b.value
                    }, function(a) {
                        b.ns(a, !1)
                    });
                    return d
                }
                this.zo(d, !0);
                return this
            },
            zo: function(d, b) {
                this.value = d;
                for (this.aj = !b; 0 < this.yn.length;) {
                    var a = this.yn.shift();
                    this.Xs(a.zz, a.xz)
                }
                this.Hk = !0;
                this.bound = !1
            },
            ns: function(d) {
                if (this.Hk || this.bound) return null;
                this.zo(d, !1);
                return this
            },
            Xs: function(d, b) {
                try {
                    this.aj ? b && b.apply(null, [this.value]) : d.apply(null, [this.value])
                } catch (a) {
                    this.aj || (this.aj = !0, this.value = a)
                }
            }
        };
        return d
    });
    define("lscY", ["Promise", "lscAj", "lscAi"], function(d, f) {
        return {
            Sg: function(b, a) {
                return a.Go ? a.jl ? function() {
                    try {
                        var a = this.target[b].apply(this.target, [this.$a].concat(f.Ai(arguments)));
                        return d.resolve(a)
                    } catch (g) {
                        return d.reject(g)
                    }
                } : function() {
                    try {
                        var a = this.target[b].apply(this.target, arguments);
                        return d.resolve(a)
                    } catch (g) {
                        return d.reject(g)
                    }
                } : a.jl ? function() {
                    try {
                        this.target[b].apply(this.target, [this.$a].concat(f.Ai(arguments)))
                    } catch (a) {}
                } : function() {
                    try {
                        this.target[b].apply(this.target,
                            arguments)
                    } catch (a) {}
                }
            }
        }
    });
    define("lscP", [], function() {
        function d(d, b, a) {
            this.Go = d;
            this.jl = b;
            this.Ts = a || !1
        }
        d.tt = new d(!1, !1);
        d.VC = new d(!0, !1);
        d.ut = new d(!0, !1, 2E3);
        d.c = new d(!1, !0);
        d.HA = new d(!0, !0);
        d.TC = new d(!0, !0, 4E3);
        return d
    });
    define("lscAP", ["lscY", "lscP", "LoggerManager", "lscAe"], function(d, f, b, a) {
        function c(a) {
            this.client = a;
            this.zb = !1;
            this.$a = -1;
            this.Ca = null;
            this.rq = "local"
        }
        var g = f.tt,
            e = f.c;
        f = {
            Zr: g,
            Dp: e,
            Ep: e,
            ws: f.ut,
            Me: f.HA,
            Qd: e,
            ld: e,
            eh: e,
            Gq: g,
            Up: g
        };
        var p = b.getLoggerProxy(a.Eb);
        c.methods = f;
        c.prototype = {
            gB: function(a) {
                this.target = a
            },
            jt: function(a) {
                p.logInfo(b.resolve(11) + this.rq + " engine created: " + a);
                this.Ca = a
            },
            ne: function() {
                return this.Ca
            },
            G: function() {
                this.client = null
            },
            nB: function(a) {
                this.$a =
                    a
            },
            wh: function(a, c, b) {
                ("lscD" == a ? this.client.Fb : "lscE" == a ? this.client.sb : this.client.ka).X(c, b)
            },
            ze: function(a) {
                this.zb && this.pk(a)
            },
            pk: function(a) {
                this.$a = a;
                this.zb = !1;
                this.client.pk()
            },
            cd: function(a) {
                this.$a = a;
                this.zb = !0;
                this.client.GA()
            },
            Sf: function(a, c) {
                p.logInfo(b.resolve(12) + this.Ca + " is dead");
                this.client && (this.pk(-1), this.client.Sv(a, c))
            },
            Bl: function() {
                var a = this;
                this.ws().then(function() {}, function() {
                    a.client && a.Sf()
                })
            },
            bs: function() {
                this.Bl();
                Executor.addTimedTask(this.Bl,
                    1E3, this)
            },
            Uf: function(a, c) {
                this.client.FA(a, c)
            },
            onStatusChange: function(a) {
                this.client.nl(a)
            },
            onSubscription: function(a, c, b, e, g) {
                this.client.u.QB(a, c, b, e, g)
            },
            Wf: function(a, c, b) {
                this.client.u.Uv(a, c, b)
            },
            onUnsubscription: function(a) {
                this.client.u.fC(a)
            },
            onEndOfSnapshot: function(a, c) {
                this.client.u.we(a, c)
            },
            xh: function(a, c) {
                this.client.u.gC(a, c)
            },
            onLostUpdates: function(a, c, b) {
                this.client.u.xe(a, c, b)
            },
            onClearSnapshot: function(a, c) {
                this.client.u.ve(a, c)
            },
            ye: function(a) {
                this.client.J.My(a)
            },
            gs: function(a,
                c, b) {
                this.client.J.Ly(a, c, b)
            },
            Tf: function(a, c, b) {
                this.client.J.Ny(a, c, b)
            },
            fs: function(a) {
                this.client.J.Ky(a)
            },
            hs: function(a) {
                this.client.J.Py(a)
            },
            ping: function() {
                if (null === this.client) throw "net";
                return !0
            },
            xc: function() {
                this.client.xc()
            }
        };
        for (var k in f) c.prototype[k] = d.Sg(k, f[k]);
        return c
    });
    define("lscAH", ["Environment", "lscAj"], function(d, f) {
        function b(a, c, b, e, d, k) {
            this.eB(a);
            this.Je(c);
            this.setData(b);
            this.uk(e);
            this.Rh(d);
            this.Th(k)
        }
        b.fu = "GET";
        b.ri = "POST";
        b.prototype = {
            toString: function() {
                return ["[", this.Gb, this.Cg, this.rb, this.We, "]"].join("|")
            },
            eB: function(a) {
                for (; a && "/" == a.substring(a.length - 1);) a = a.substring(0, a.length - 1);
                this.Gb = a
            },
            Je: function(a) {
                for (; a && "/" == a.substring(0, 1);) a = a.substring(1);
                this.Cg = a
            },
            uk: function(a) {
                this.We = a || b.ri
            },
            Rh: function(a) {
                this.bq = a || !1
            },
            Th: function(a) {
                this.lm =
                    a || null
            },
            setData: function(a) {
                this.rb = a
            },
            Xi: function(a) {
                this.rb ? this.rv(a) || (this.rb += a) : this.setData(a)
            },
            rv: function(a) {
                return this.rb && -1 < this.rb.indexOf(a)
            },
            getFile: function() {
                return this.Cg
            },
            zd: function() {
                return this.Cg ? this.Gb + "/" + this.Cg : this.Gb
            },
            getData: function() {
                return this.rb
            },
            Cx: function() {
                return this.rb ? this.zd() + "?" + this.rb : this.zd()
            },
            clone: function() {
                return new b(this.Gb, this.Cg, this.rb, this.We, this.bq, this.lm)
            },
            yr: function() {
                return !(0 == this.Gb.indexOf("http://") || 0 == this.Gb.indexOf("https://") ||
                    0 == this.Gb.indexOf("file:///"))
            },
            my: function(a, c) {
                if (!d.isBrowser()) return !1;
                if (this.yr()) return d.isWebWorker() ? location.hostname == a : f.sc() == a;
                if (c) {
                    if (!this.Ar(c)) return !1;
                    if ("file:" == c) return "" == a
                }
                a = a.replace(".", ".");
                return (new RegExp("^https?://(?:[a-z][a-z0-9-]+.)*" + a + "(?:/|$|:)", "i")).test(this.Gb)
            },
            Ar: function(a) {
                return d.isBrowser() && a.indexOf(":") == a.length - 1 ? this.yr() ? location.protocol == a : 0 == this.Gb.indexOf(a) : !1
            },
            ua: function() {
                if (!d.isBrowser()) return !0;
                var a = d.isWebWorker() ? location.hostname :
                    f.sc();
                return !this.my(a, location.protocol)
            },
            ta: function() {
                return d.isBrowser() ? !this.Ar(location.protocol) : !0
            }
        };
        b.Bu = new b("about:blank");
        return b
    });
    define("lscG", [], function() {
        function d(d, b, a, c, g) {
            this.request = d;
            this.jA = b;
            this.Fs = c;
            this.Fg = a;
            this.Ge = g
        }
        d.hi = 1;
        d.Xk = 2;
        d.Rk = 3;
        d.nd = 4;
        d.md = 5;
        d.Vd = 6;
        d.Tk = 7;
        d.Wd = 8;
        d.Po = 9;
        d.prototype = {
            toString: function() {
                return ["[|ControlRequest", this.Fs, this.Fg, this.Ge, this.request, "]"].join("|")
            },
            jj: function() {
                return this.jA
            },
            getKey: function() {
                return this.Fs
            }
        };
        return d
    });
    define("lscc", ["lscAH", "lscG", "lscAj"], function(d, f) {
        function b() {}
        b.prototype = {
            toString: function() {
                return "[Encoder]"
            },
            Qx: function(a, c, b) {
                var e = new d;
                a = a.pf();
                e.Je((a == f.nd ? "msg" : a == f.md ? "send_log" : a == f.Wd ? "heartbeat" : "control") + this.rf());
                e.uk(d.ri);
                e.Rh(c);
                e.Th(b);
                return e
            },
            encode: function(a, c, b) {
                for (b = b ? "" : "\r\n"; 0 < a.getLength();) {
                    var e = a.dh(),
                        d = e.jj(),
                        k = e.Fg;
                    if (d && d.verifySuccess()) d.uh(), a.shift();
                    else return a = e.request, k == f.nd ? b + this.im(a, d, c) : k == f.Vd ? b + this.Ri(a, d, c) : k == f.Wd ?
                        b + this.gm(a, d, c) : k == f.md ? b + this.hm(a, d, c) : b + this.fm(a, d, c)
                }
                return null
            },
            expand: function(a, c) {
                var b = "";
                if (a)
                    for (var e in a) e !== c && (b += e + "\x3d" + a[e] + "\x26");
                return b
            },
            hf: function(a, c) {
                var b = this.expand(a);
                return b += this.expand(c)
            },
            Si: function(a, c, b) {
                var e = this.expand(a, b),
                    e = e + this.expand(c, b);
                a[b] ? e += b + "\x3d" + a[b] : c && (e += b + "\x3d" + c[b]);
                return "LS_unq\x3d" + e.length + "\x26" + e
            },
            Ho: function(a) {
                return a
            },
            rf: function() {
                return ".js"
            },
            xm: function() {
                return 0
            },
            Am: function() {
                return 2
            },
            fm: function(a, b, g, e) {
                return this.hf(a,
                    e, g)
            },
            Ri: function(a, b, g, e) {
                return this.hf(a, e, g)
            },
            gm: function(a, b, g, e) {
                return this.hf(a, e, g)
            },
            hm: function(a, b, g, e) {
                return this.hf(a, e, g)
            },
            im: function(a, b, g, e) {
                return this.Si(a, e, "LS_message", g)
            }
        };
        return b
    });
    define("lscd", ["lscc", "Inheritance", "lscAj"], function(d, f, b) {
        function a() {}
        var c = 1,
            g = {
                im: "encodeMessageRequest",
                fm: "encodeControlRequest",
                Ri: "encodeDestroyRequest",
                gm: "encodeHeartbeatRequest",
                hm: "encodeLogRequest"
            },
            g = b.getReverse(g);
        a.prototype = {
            im: function(c, d, k, h) {
                h = b.ra(h, {
                    LS_session: k
                });
                return this._callSuperMethod(a, g.encodeMessageRequest, [c, d, k, h])
            },
            fm: function(e, d, k, h) {
                h = b.ra(h, {
                    LS_session: k
                });
                h = b.ra(h, {
                    LS_unique: c++
                });
                return this._callSuperMethod(a, g.encodeControlRequest, [e, d, k,
                    h
                ])
            },
            Ri: function(e, d, k, h) {
                h = b.ra(h, {
                    LS_unique: c++
                });
                return this._callSuperMethod(a, g.encodeDestroyRequest, [e, d, k, h])
            },
            gm: function(e, d, k, h) {
                k && (h = b.ra(h, {
                    LS_session: k
                }));
                h = b.ra(h, {
                    LS_unique: c++
                });
                return this._callSuperMethod(a, g.encodeHeartbeatRequest, [e, d, k, h])
            },
            hm: function(e, d, k, h) {
                k && (h = b.ra(h, {
                    LS_session: k
                }));
                h = b.ra(h, {
                    LS_unique: c++
                });
                return this._callSuperMethod(a, g.encodeLogRequest, [e, d, k, h])
            },
            expand: function(a, b) {
                var c = "";
                if (a)
                    for (var g in a) c = g !== b ? c + (g + "\x3d" + a[g] + "\x26") : c + (g + "\x3d" + encodeURIComponent(a[g]) +
                        "\x26");
                return c
            },
            Si: function(a, b, c) {
                a = this.expand(a, c);
                return a += this.expand(b, c)
            }
        };
        f(a, d);
        return a
    });
    define("req", ["Environment"], function(d) {
        var f = d.isNodeJS() ? require : null;
        return function(b) {
            return f(b)
        }
    });
    define("lscAI", ["lscd", "lscAj", "req"], function(d, f, b) {
        function a() {
            for (var b in {
                    pa: !0
                }) this.ti = b;
            this.V = a
        }

        function c() {
            return !1
        }

        function g() {
            return !0
        }
        var e = new d;
        a.Qo = "LS_container\x3dlsc\x26";
        a.jc = function(a, b) {
            for (var e in b) a[e] = !0 === b[e] ? g : !1 === b[e] ? c : b[e]
        };
        a.jc(a, {
            sa: !1,
            ua: !1,
            ta: !1,
            hc: !1,
            ic: !1,
            Bf: !1,
            lc: !1
        });
        a.prototype = {
            ea: function() {},
            qk: function(b, c, e, g, d, f) {
                this.V.ic() ? b.Xi("LS_eng\x3d" + f + "\x26") : b.Xi(a.Qo);
                return this.pa(b, c, e, g, d)
            },
            pa: function() {
                return !1
            },
            yd: function() {
                return e
            }
        };
        a.Vq = function(a) {
            var c = [],
                e = b("xmlhttprequest-cookie");
            if (e)
                if (null == a) e.CookieJar.save().split("\r\n").forEach(function(a) {
                    "" != a && c.push(a)
                });
                else {
                    a = b("url").parse(a);
                    for (var e = e.CookieJar.findFuzzy(a.hostname, a.pathname), g = 0; g < e.length; g++) e[g].secure && "https:" !== a.protocol || e[g].httponly && null === a.protocol.match(/^https?:$/i) || c.push(e[g])
                } return c
        };
        a.qp = function(a) {
            var c = b("xmlhttprequest-cookie");
            if (c) {
                var e = "";
                a.forEach(function(a) {
                    e += "\r\n" + a
                });
                0 < e.length && (a = c.CookieJar.save(), c.CookieJar.load(a +
                    e))
            }
        };
        return a
    });
    define("Assertions", ["ASSERT", "LoggerManager"], function(d, f) {
        var b = f.getLoggerProxy("assertions");
        return {
            assert: function(a, b) {
                a || this.fail(b)
            },
            FC: function(a, b, g) {
                a !== b && this.fail(g + ": Expected " + a + " but found " + b)
            },
            OC: function(a, b, g) {
                this.assert(!a || b, g)
            },
            fail: function(a) {
                d.fail();
                null != a && b.logError(a)
            },
            verifyOk: function(a, c) {
                d.verifyOk(a) || null != c && b.logError(c)
            },
            verifyNotOk: function(a, c) {
                d.verifyNotOk(a) || null != c && b.logError(c)
            },
            verifyValue: function(a, c, g) {
                d.verifyValue(a, c, null) || null != g && b.logError(g)
            },
            verifyDiffValue: function(a, c, g) {
                d.verifyDiffValue(a, c, null) || null != g && b.logError(g)
            }
        }
    });
    define("lscAO", ["Executor", "List", "Assertions"], function(d, f, b) {
        function a(a) {
            this.Gf = -1;
            this.Ch = {};
            this.$j = {};
            this.Dh = {};
            this.Zj = 0;
            this.S = a;
            this.Gh = new f
        }
        a.prototype = {
            ai: function(a) {
                this.S = a
            },
            Yw: function(a, b) {
                this.Gf++;
                this.Ch[this.Gf] = b;
                this.$j[this.Gf] = a;
                this.Dh[this.Gf] = !1;
                this.Zj++;
                return this.Gf
            },
            vb: function(a) {
                return this.Ch[a]
            },
            jh: function(a) {
                return this.$j[a]
            },
            nC: function(a) {
                return this.Dh[a]
            },
            iv: function() {
                this.kv();
                var a = [],
                    g;
                for (g in this.Ch) a.push(g);
                a.sort(function(a, b) {
                    return a -
                        b
                });
                for (g = 0; g < a.length; g++) this.Jy(a[g]);
                b.verifyValue(this.Zj, 0, "Unexpected pending messages");
                this.Gf = -1;
                this.Ch = {};
                this.$j = {};
                this.Dh = {};
                this.Zj = 0
            },
            clean: function(a) {
                delete this.Ch[a];
                delete this.$j[a];
                delete this.Dh[a];
                this.Zj--
            },
            Py: function(a) {
                this.vb(a) && (this.Dh[a] = !0)
            },
            Tv: function(a, b, e, d) {
                this.Gh.add({
                    Lr: a,
                    nk: b,
                    listener: e,
                    timeout: d
                })
            },
            kv: function() {
                var a = this;
                this.Gh.forEach(function(b) {
                    a.fireEvent("onAbort", b.listener, [b.Lr, !1])
                });
                this.Gh.clean()
            },
            Hx: function() {
                var a = this;
                this.Gh.forEach(function(b) {
                    a.eh(b.Lr,
                        b.nk, b.listener, b.timeout)
                });
                this.Gh.clean()
            },
            eh: function(a, b, e, d) {
                var k = null;
                e && (k = this.Yw(a, e));
                this.S.eh(a, b, k, d)
            },
            fireEvent: function(a, b, e) {
                b && b[a] && d.addTimedTask(b[a], 0, b, e)
            },
            Ky: function(a) {
                this.fireEvent("onProcessed", this.vb(a), [this.jh(a)]);
                this.clean(a)
            },
            Ny: function(a) {
                this.fireEvent("onError", this.vb(a), [this.jh(a)]);
                this.clean(a)
            },
            Ly: function(a, b, e) {
                this.fireEvent("onDeny", this.vb(a), [this.jh(a), b, e]);
                this.clean(a)
            },
            My: function(a) {
                this.fireEvent("onDiscarded", this.vb(a), [this.jh(a)]);
                this.clean(a)
            },
            Jy: function(a) {
                this.fireEvent("onAbort", this.vb(a), [this.jh(a), this.nC(a)]);
                this.clean(a)
            }
        };
        return a
    });
    define("lscAd", ["lscAe"], function(d) {
        return function(f, b) {
            var a = b ? f : [];
            a.Mc = [];
            b || (a[0] = parseInt(f[0]), a[1] = parseInt(f[1]));
            for (var c = 2, g = f.length; c < g; c++) f[c] ? -1 == f[c].length ? a[c] = d.Ue : (b || (a[c] = f[c].toString()), a.Mc.push(c - 1)) : (b || (a[c] = "" === f[c] ? "" : null), a.Mc.push(c - 1));
            return a
        }
    });
    define("lscAc", ["Executor", "LoggerManager", "Assertions", "lscAe", "lscAd"], function(d, f, b, a, c) {
        function g(a) {
            this.Xy = 0;
            this.pb = {};
            this.Ne = {};
            this.pw = 1;
            this.lb = {};
            this.Ac = {};
            this.gb = null;
            this.b = a;
            this.a = 0
        }
        var e = f.getLoggerProxy(a.ap);
        g.prototype = {
            toString: function() {
                return "[SubscriptionsHandler]"
            },
            ai: function(a) {
                this.gb = a
            },
            pp: function(a) {
                var b = ++this.Xy;
                e.logInfo(f.resolve(13), a);
                a.kz(b, ++this.pw, this);
                this.pb[b] = a;
                this.ss(a)
            },
            Hs: function(a) {
                if (this.gb && this.gb.zb) {
                    var b = a.jd;
                    (a.Br() || a.Af()) && b && (this.gb.Qd(b), delete this.Ne[b])
                }
                e.logInfo(f.resolve(14), a);
                b = a.od;
                a.Fz();
                delete this.pb[b];
                return a
            },
            ld: function(a, c) {
                if (this.gb && this.gb.zb && a.Bd()) {
                    b.verifyOk(a.Bd(), "Inactive subscription");
                    var g = a.od;
                    if (this.lb[g]) {
                        e.logDebug(f.resolve(15), a);
                        var d = this;
                        this.Ti(g, function(b) {
                            e.logDebug(f.resolve(16), a);
                            d.gb.ld(b, c)
                        })
                    } else e.logDebug(f.resolve(17), a), this.gb.ld(a.jd, c)
                }
            },
            ss: function(a) {
                if (this.gb && this.gb.zb && a.iy()) {
                    var c = a.od;
                    e.logDebug(f.resolve(18));
                    var g = this.gb.Me(a.kx());
                    this.lb[c] ? e.logDebug(f.resolve(19) + c) : (b.verifyNotOk(this.lb[c], "Promise unexpected (1)"), b.verifyNotOk(this.Ac[c], "Promise unexpected (2)"));
                    this.lb[c] = g;
                    this.Ac[c] = 0;
                    a.Mz();
                    e.logDebug(f.resolve(20), a);
                    var d = this;
                    this.Ti(c, function(b) {
                        e.logDebug(f.resolve(21), a);
                        d.pb[c] ? (a.Pz(b), d.Ne[b] = c) : d.gb && d.gb.Qd(b)
                    })
                }
            },
            Ti: function(a, c) {
                b.verifyOk(this.lb[a], "Promise not found (1)");
                0 !== this.Ac[a] && b.verifyOk(this.Ac[a], "Promise not found (2)");
                var g = this.lb[a];
                this.Ac[a]++;
                var d = this,
                    m = this.a;
                g.then(function(t) {
                    d.lb[a] !=
                        g ? e.logDebug(f.resolve(22) + a) : (b.verifyOk(d.lb[a], "Promise not found (3)"), b.verifyOk(d.Ac[a], "Promise not found (4)"), 1 < d.Ac[a] ? d.Ac[a]-- : (delete d.lb[a], delete d.Ac[a]), null != t && m == d.a && c(t))
                }, function() {
                    d.lb[a] != g ? e.logDebug(f.resolve(23) + a) : (delete d.lb[a], delete d.Ac[a])
                })
            },
            Ix: function() {
                e.logDebug(f.resolve(24));
                for (var a in this.pb) this.ss(this.pb[a])
            },
            $z: function(a) {
                b.verifyNotOk(a.gy(), "Table removed");
                e.logDebug(f.resolve(25), a);
                delete this.Ne[a.jd];
                a.Bz();
                a.wt && delete this.pb[a.od]
            },
            Zz: function() {
                e.logDebug(f.resolve(26));
                for (var a in this.pb) this.$z(this.pb[a]);
                this.Ne = {};
                this.a++
            },
            ee: function(a, c) {
                var g = this.Ne[a];
                if (g) {
                    var d = this.pb[g];
                    if (this.lb[g]) {
                        e.logDebug(f.resolve(27), d);
                        var m = this;
                        this.Ti(g, function(d) {
                            e.logDebug(f.resolve(28), l);
                            b.verifyValue(d, a, "Wrong table number");
                            if (m.Ne[a] == g) {
                                var l = m.pb[g];
                                l && c.apply(l)
                            }
                        })
                    } else d && c.apply(d)
                } else {
                    d = function(b) {
                        m.Ti(b, function(g) {
                            g == a && (e.logDebug(f.resolve(31), a), m.Ne[a] == b && (g = m.pb[b]) && c.apply(g))
                        })
                    };
                    e.logDebug(f.resolve(30), a);
                    var m = this,
                        t = 0,
                        n;
                    for (n in this.lb) {
                        var r =
                            this.pb[n];
                        r && (r.jd ? b.verifyDiffValue(r.jd, a, "Unexpected table number") : (d(n), t++))
                    }
                    e.logDebug(f.resolve(32), t)
                }
            },
            gC: function(a, b) {
                this.ee(a[0], function() {
                    this.update(c(a, !0), b, !1)
                })
            },
            xe: function(a, b, c) {
                this.ee(a, function() {
                    this.Fy(b, c)
                })
            },
            we: function(a, b) {
                this.ee(a, function() {
                    this.Rv(b)
                })
            },
            ve: function(a, b) {
                this.ee(a, function() {
                    this.lv(b)
                })
            },
            Uv: function(a, b, c) {
                this.ee(a, function() {
                    this.EA(b, c)
                })
            },
            QB: function(a, b, c, e, g) {
                this.ee(a, function() {
                    this.Kz(b, c, e, g)
                })
            },
            fC: function(a) {
                this.ee(a, function() {})
            }
        };
        return g
    });
    define("EventDispatcher", ["Executor", "List", "Inheritance"], function(d, f, b) {
        function a() {
            this._callSuperConstructor(a)
        }

        function c() {
            this.initDispatcher()
        }
        c.prototype = {
            initDispatcher: function() {
                this.ci = new a;
                this.xt = !1
            },
            addListener: function(a) {
                a && !this.ci.contains(a) && (a = {
                    g: a,
                    Jr: !0
                }, this.ci.add(a), this.$l("onListenStart", [this], a, !0))
            },
            removeListener: function(a) {
                a && (a = this.ci.remove(a)) && this.$l("onListenEnd", [this], a, !0)
            },
            getListeners: function() {
                return this.ci.asArray()
            },
            useSynchEvents: function(a) {
                this.xt = !0 === a
            },
            $l: function(a, b, c, f) {
                this.xt ? this.lq(a, b, c, !0) : d.addTimedTask(this.lq, 0, this, [a, b, c, f])
            },
            lq: function(a, b, c, d) {
                if (c && c.g[a] && (d || c.Jr)) try {
                    b ? c.g[a].apply(c.g, b) : c.g[a].apply(c.g)
                } catch (f) {}
            },
            dispatchEvent: function(a, b) {
                var c = this;
                this.ci.forEach(function(d) {
                    c.$l(a, b, d, !1)
                })
            }
        };
        c.prototype.initDispatcher = c.prototype.initDispatcher;
        c.prototype.addListener = c.prototype.addListener;
        c.prototype.removeListener = c.prototype.removeListener;
        c.prototype.getListeners = c.prototype.getListeners;
        c.prototype.useSynchEvents =
            c.prototype.useSynchEvents;
        c.prototype.dispatchEvent = c.prototype.dispatchEvent;
        a.prototype = {
            remove: function(a) {
                a = this.find(a);
                if (0 > a) return !1;
                var b = this.data[a];
                b.Jr = !1;
                this.data.splice(a, 1);
                return b
            },
            find: function(a) {
                for (var b = 0; b < this.data.length; b++)
                    if (this.data[b].g == a) return b;
                return -1
            },
            asArray: function() {
                var a = [];
                this.forEach(function(b) {
                    a.push(b.g)
                });
                return a
            }
        };
        b(a, f);
        return c
    });
    define("lsco", ["Global", "LoggerManager", "EnvironmentStatus", "ASSERT", "lscAe"], function(d, f, b, a, c) {
        function g(a, b) {
            this.WB = b;
            this.Yv(a)
        }
        var e = f.getLoggerProxy(c.Se),
            p = !1;
        g.CB = function(a) {
            p = a
        };
        g.prototype = {
            fe: function(a) {
                e.logDebug(f.resolve(39), a);
                this.f = a;
                this.f.Qb() != this.Xl && (this.Ka = null)
            },
            Yv: function(a) {
                var b = this;
                d.qa(a, "LS_e", function(a, c, e, g, d, k, f, v) {
                    b.ks(a, c, e, g, d, k, f, v)
                });
                d.qa(a, "LS_t", function() {});
                d.qa(a, "LS_u", function(a, c, e) {
                    b.xh(a, c, e)
                });
                d.qa(a, "LS_v", function(a, c) {
                    b.xh(a,
                        c, !0)
                });
                d.qa(a, "LS_o", function(a, c) {
                    b.xe(a, c)
                });
                d.qa(a, "LS_n", function(a, c) {
                    b.we(a, c)
                });
                d.qa(a, "LS_s", function(a, c) {
                    c.length ? b.ve(a, c) : b.ks(6, a, c)
                });
                d.qa(a, "LS_l", function(a, c, e, g) {
                    b.ia(a, c, e, g)
                });
                d.qa(a, "LS_w", function(a, c, e, g, d, k, f) {
                    b.nz(a, c, e, g, d, k, f)
                });
                d.qa(a, "setTimeout", function(a, b) {
                    setTimeout(a, b)
                });
                d.qa(a, "alert", function(a) {
                    "undefined" != typeof alert ? alert(a) : "undefined" != typeof console && console.log(a)
                })
            },
            zc: function(a, c, g, d) {
                var t = !p && !b.isUnloaded() && null != this.f;
                t && a && (t &= this.f.Nc(a));
                t && c && (t &= this.WB.Nc(c));
                t && !d && (t = g ? t & this.f.sy() : t & this.f.xr());
                e.isDebugLogEnabled() && e.logDebug(f.resolve(40), t);
                return t
            },
            cg: function() {
                this.f.Qb() != this.Xl && (this.Ka = null);
                var b = this.f.Jb;
                e.logDebug(f.resolve(41), b);
                if (null != this.Ka) {
                    a.verifyOk(this.Ka <= b) || e.logError(f.resolve(33), this.Ka);
                    this.Ka++;
                    if (this.Ka <= b) return e.logDebug(f.resolve(42), this.Ka), !1;
                    this.f.$r();
                    b = this.f.Jb;
                    a.verifyValue(this.Ka, b) || e.logError(f.resolve(34), this.Ka);
                    return !0
                }
                this.f.$r();
                return !0
            },
            ks: function(a, b, c, e,
                g, d, f, p) {
                if (this.zc(b, null, 1 == a, 3 == a || 4 == a))
                    if (1 == a) this.f.yz(c, e, d, g, f, p);
                    else if (2 == a) this.f.uz(c);
                else if (3 == a) this.f.Vj("syncerror");
                else if (4 == a) {
                    a = 30;
                    if (null != c) {
                        a = c;
                        if (41 == a) {
                            this.f.pz();
                            return
                        }
                        if (48 == a) {
                            this.f.Vj("expired");
                            return
                        }
                        if (0 < a && 30 > a || 39 < a) a = 39
                    }
                    this.ia(a, b, null, "The session has been forcibly closed by the Server")
                } else 5 == a ? this.f.Hz(c) : 6 == a ? this.f.Nz(c) : 7 == a ? this.Cz(c) : this.f.vh("Unsupported Server version")
            },
            Cz: function(b) {
                this.f.Qb() != this.Xl && (this.Ka = null);
                var c = this.f.Jb;
                null ==
                    this.Ka ? (this.Ka = b, this.Xl = this.f.Qb(), this.Ka > c && (a.fail(), e.logError(f.resolve(35), b, c), this.f.vh("Received event prog higher than expected: " + b))) : this.Ka != b ? (a.fail(), e.logError(f.resolve(36), b, this.Ka), this.f.vh("Received event prog different than expected: " + b)) : b != c && (a.fail(), e.logError(f.resolve(37), b, c), this.f.vh("Received event prog different than actual: " + b))
            },
            xh: function(a, b, c) {
                2 > b.length ? this.zc(a) && this.f.tz() : this.zc(null, a) && this.cg() && this.f.tn(b, c || !1)
            },
            we: function(a, b) {
                this.zc(null,
                    a) && this.cg() && this.f.we(b)
            },
            ve: function(a, b) {
                this.zc(null, a) && this.cg() && this.f.ve(b)
            },
            xe: function(a, b) {
                this.zc(null, a) && this.cg() && this.f.xe(b)
            },
            vz: function(b, c, g, d) {
                if (this.zc() && this.cg())
                    if (a.verifyValue(g.substring(0, 3), "MSG") || e.logError(f.resolve(38), g), g = g.substr(3), 39 == b)
                        for (b = parseInt(d), c = parseInt(c), b = c - b + 1; b <= c; b++) this.f.ye(g, b);
                    else 38 == b ? this.f.ye(g, c) : 0 >= b ? this.f.ln(g, b, d, c) : this.f.Tf(g, b, d, c)
            },
            ia: function(a, b, c, e) {
                null != c && isNaN(c) ? this.vz(a, b, c, e) : null != c ? this.zc(null, b) && this.f.sn(c,
                    a, e) : this.zc(b, null, null, !0) && (4 == a ? this.f.Vj("recovery.error") : this.f.Uf(a, e))
            },
            nz: function(a, b, c, g, d, p, r) {
                if (this.zc(null, 4 == a || 5 == a || 9 == a ? null : b) && this.cg())
                    if (4 == a) this.f.kn(c, b);
                    else if (5 == a) this.f.nn(c, b);
                else if (8 == a) this.f.onUnsubscription(c);
                else if (6 == a) this.f.onSubscription(c, g, d, p + 1, r + 1);
                else 9 == a ? this.f.Xf(c, b) : e.logDebug(f.resolve(43), a)
            }
        };
        return g
    });
    define("lscN", ["Executor"], function(d) {
        function f(b, a) {
            this.cf = b;
            this.Gk = this.Nw ? this.cf.dj : a ? 2 * a : 4E3
        }
        f.prototype = {
            $c: function(b) {
                b ? this.gf() : d.addTimedTask(this.Ae, this.Gk + Number(this.cf.De), this)
            },
            Ae: function() {
                this.verifySuccess() || this.gf()
            }
        };
        return f
    });
    define("lscO", ["Inheritance", "lscN"], function(d, f) {
        function b(a, c, g, e, d) {
            this._callSuperConstructor(b, [a, d]);
            this.Dc = c;
            this.va = g;
            this.rc = e
        }
        b.prototype = {
            verifySuccess: function() {
                return !this.va.vy(this.Dc)
            },
            gf: function() {
                this.va.Qd(this.Dc, this.rc + 1, this.Gk)
            },
            uh: function() {
                this.va.onUnsubscription(this.Dc)
            }
        };
        d(b, f);
        return b
    });
    define("lscL", ["Inheritance", "lscN"], function(d, f) {
        function b(a, c, d, f, h) {
            this._callSuperConstructor(b, [a, h]);
            this.Dc = c;
            this.va = d;
            this.rc = f
        }
        var a, c;
        for (c in {
                $c: !0
            }) a = c;
        b.prototype = {
            verifySuccess: function() {
                return !this.va.ty(this.Dc)
            },
            gf: function() {
                this.va.Me(this.Dc, this.rc + 1, this.Gk)
            },
            $c: function(c) {
                c || this.va.RB(this.Dc);
                this._callSuperMethod(b, a, arguments)
            },
            uh: function() {}
        };
        d(b, f);
        return b
    });
    define("lscM", ["Inheritance", "lscN", "Assertions"], function(d, f) {
        function b(a, c, g, e, d, f, h) {
            this._callSuperConstructor(b, [a, h]);
            this.Dc = c;
            this.ts = g;
            this.va = e;
            this.Zu = d;
            this.rc = f
        }
        b.prototype = {
            verifySuccess: function() {
                return !this.va.uy(this.Dc, this.ts)
            },
            gf: function() {
                this.va.ct(this.Dc, this.ts, this.Zu, this.rc + 1, this.Gk)
            },
            uh: function() {}
        };
        d(b, f);
        return b
    });
    define("lscp", "LoggerManager lscAe Executor EnvironmentStatus lscAj ASSERT lscO lscL lscM".split(" "), function(d, f, b, a, c, g, e, p, k) {
        function h(c, e, g, d) {
            this.Ms = 1;
            this.o = c;
            this.Ql = e;
            this.Gv = g;
            this.options = d;
            this.$a = 0;
            this.zb = !1;
            this.Zy = 1;
            this.M = {};
            this.sd = 0;
            this.m = {};
            this.Ed = {};
            this.jv = b.addRepetitiveTask(this.Sp, 5E3, this);
            a.addBeforeUnloadHandler(this);
            a.addUnloadHandler(this)
        }

        function l(a, b, c) {
            this.zn = this.dt = this.An = !1;
            this.Bh = 0;
            this.ak = !1;
            this.Bv = c;
            this.Du = b;
            this.Fd = a
        }
        var m = d.getLoggerProxy(f.Eb);
        h.prototype = {
            toString: function() {
                return "[|PushPageCollectionHandler|]"
            },
            Wc: function() {
                return this.$a
            },
            Nc: function(a) {
                return a == this.$a
            },
            Al: function(a) {
                var b = this.o.Bc;
                b && b.dx(this.o.f.Wa()) > a && m.logWarn(d.resolve(45))
            },
            Op: function() {
                this.m = {};
                for (var a in this.Ed) this.Ed[a] = {}
            },
            wd: function(a) {
                for (var b in this.M) a(this.M[b], b)
            },
            js: function(a, b) {
                this.M[a] = b;
                this.Ed[a] = {};
                this.sd++;
                this.Ql.X("clientsCount", this.sd);
                m.logDebug(d.resolve(46),
                    this);
                a !== f.Wo && (this.Gv.qm(function(a, c) {
                    b.wh("lscD", a, c)
                }), this.options.qm(function(a, c) {
                    b.wh("lscE", a, c)
                }), this.Ql.qm(function(a, c) {
                    b.wh("lscC", a, c)
                }), b.onStatusChange(this.o.Rb()), this.zb ? b.cd(this.$a) : b.ze(this.$a))
            },
            ls: function(a) {
                m.logDebug(d.resolve(47), this, a);
                if (this.M[a]) {
                    var b = this.Ed[a],
                        c;
                    for (c in b) this.Ks(c);
                    this.M[a].G();
                    delete this.M[a];
                    delete this.Ed[a];
                    this.sd--;
                    this.Ql.X("clientsCount", this.sd)
                }
            },
            pe: function(a) {
                a = this.m[a];
                return a ? this.tf(a.Fd) :
                    (m.logDebug(d.resolve(48)), null)
            },
            tf: function(a) {
                return this.M[a] ? this.M[a] : (m.logDebug(d.resolve(49)), null)
            },
            fz: function(a) {
                this.wd(function(b) {
                    b.onStatusChange(a)
                });
                return !0
            },
            cd: function() {
                this.Op();
                this.zb = !0;
                var a = ++this.$a;
                this.wd(function(b) {
                    b.cd(a)
                })
            },
            ze: function() {
                this.Op();
                this.zb = !1;
                var a = ++this.$a;
                this.wd(function(b) {
                    b.ze(a)
                })
            },
            onSubscription: function(a) {
                this.m[a] && (this.m[a].An = !1)
            },
            Wf: function(a) {
                this.onUnsubscription(a)
            },
            ty: function(a) {
                return this.m[a] ? this.m[a].An && !this.m[a].ak : !1
            },
            RB: function(a) {
                this.m[a] && (this.m[a].dt = !0)
            },
            onUnsubscription: function(a) {
                if (this.m[a]) {
                    var b = this.m[a].Fd;
                    delete this.m[a];
                    this.Ed[b] && delete this.Ed[b][a]
                }
            },
            vy: function(a) {
                return this.m[a] ? this.m[a].dt && this.m[a].ak : !1
            },
            uy: function(a, b) {
                return this.m[a] ? this.m[a].zn && this.m[a].Bh == b : !1
            },
            Xf: function(a, b) {
                this.m[a] && b == this.m[a].Bh && (this.m[a].zn = !1)
            },
            Kx: function(a, b) {
                if (this.M[a] && this.o.Pm()) {
                    var c = this.Zy++;
                    this.Ed[a][c] = !0;
                    var e = this.Fw(b, c);
                    this.m[c] = new l(a, e.add, e.remove);
                    m.logDebug(d.resolve(50));
                    this.Me(c, 1);
                    return c
                }
                g.fail();
                m.logError(d.resolve(44), this, a)
            },
            Me: function(a, b, c) {
                this.m[a] && (3 <= b && this.Al(1), this.m[a].An = !0, c = new p(this.options, a, this, b, c), this.o.f.zA(a, this.m[a].Du, this, 2 <= b, c))
            },
            Ks: function(a) {
                this.m[a] && !this.m[a].ak && this.Qd(a, 1)
            },
            Qd: function(a, b, c) {
                this.m[a] && (3 <= b && this.Al(1), this.m[a].ak = !0, c = new e(this.options, a, this, b, c), this.o.f.BA(a, this.m[a].Bv, this, 2 <= b, c))
            },
            ld: function(a, b) {
                if (this.m[a]) {
                    var c = ++this.m[a].Bh;
                    this.ct(a, c, b, 1)
                }
            },
            ct: function(a, b, e, g, d) {
                if (this.m[a] &&
                    this.m[a].Bh == b) {
                    3 <= g && this.Al(1);
                    this.m[a].zn = !0;
                    var h = this.m[a].Bh;
                    b = c.ra({
                        LS_table: a,
                        LS_op: "reconf",
                        LS_win_phase: h
                    }, e);
                    e = new k(this.options, a, h, this, e, g, d);
                    this.o.f.AA(a, b, e)
                }
            },
            cz: function() {
                this.wd(function(a) {
                    a.bs()
                })
            },
            Ur: function(a) {
                var b = this.M;
                this.M = {};
                for (var c in b) b[c].Sf(a)
            },
            gz: function(a, b) {
                this.wd(function(c) {
                    c.Uf(a, b)
                })
            },
            G: function() {
                b.stopRepetitiveTask(this.jv);
                a.removeBeforeUnloadHandler(this);
                a.removeUnloadHandler(this)
            },
            unloadEvent: function() {
                this.Ur(!1)
            },
            preUnloadEvent: function() {
                this.cz()
            },
            Sp: function() {
                var a = this;
                this.wd(function(b, c) {
                    b.ping().then(function() {}, function() {
                        a.ls(c)
                    })
                })
            },
            Fw: function(a, b) {
                this.Ms++;
                var e = {
                    LS_table: b,
                    LS_req_phase: this.Ms,
                    LS_win_phase: this.$a
                };
                c.ra(a, e);
                return {
                    add: c.ra(a, {
                        LS_op: "add"
                    }),
                    remove: c.ra(e, {
                        LS_op: "delete"
                    })
                }
            },
            xc: function() {
                this.wd(function(a) {
                    a.xc()
                })
            }
        };
        h.prototype.onPushPageLost = h.prototype.ls;
        h.prototype.onNewPushPage = h.prototype.js;
        h.prototype.unloadEvent = h.prototype.unloadEvent;
        h.prototype.preUnloadEvent = h.prototype.preUnloadEvent;
        return h
    });
    define("lscl", ["LoggerManager", "BrowserDetection", "Helpers", "lscAe"], function(d, f, b, a) {
        var c = f.isProbablyFX(1.5, !0) ? 10 : 50,
            g = c,
            e = 0,
            p = 0,
            k = 0,
            h = null,
            l = null,
            m = null,
            t = d.getLoggerProxy(a.gc);
        return {
            Xc: function() {
                g = c;
                k = p = e = 0;
                m = l = h = null
            },
            Mx: function() {
                h = e;
                l = p;
                m = k;
                var a = b.getTimeStamp();
                k || (k = a);
                6E4 <= a - k && (e = 0, k = a);
                p && 1E3 > a - p && e++;
                p = a
            },
            kk: function() {
                l != p && (e = h, p = l, k = m)
            },
            Hp: function() {
                if (0 != p) {
                    if (!g) return !1;
                    if (e >= g) return t.logError(d.resolve(51)), g = 0, !1
                }
                return !0
            }
        }
    });
    define("lsch", ["lscc", "Inheritance", "lscAj", "Assertions"], function(d, f, b, a) {
        function c(a) {
            this.qC = a
        }
        var g = {
                hf: "encodeRequest",
                Si: "encodeUnqRequest"
            },
            g = b.getReverse(g);
        c.prototype = {
            toString: function() {
                return "[WSEncoder]"
            },
            xm: function(a) {
                return a.length + 2
            },
            rf: function() {
                return ""
            },
            hf: function(a, b, d) {
                b = this.tq(b, d);
                return this._callSuperMethod(c, g.encodeRequest, [a, b, d])
            },
            Si: function(a, b, d, h) {
                b = this.tq(b, h);
                return this._callSuperMethod(c, g.encodeUnqRequest, [a, b, d, h])
            },
            Ri: function(a, b, d, h) {
                return this._callSuperMethod(c,
                    g.encodeRequest, [a, h, d])
            },
            tq: function(c, g) {
                var d = this.qC.gq;
                null == d ? c = b.ra(c, {
                    LS_session: g
                }) : a.verifyValue(d, g, "Unexpected session ID");
                return c
            }
        };
        f(c, d);
        return c
    });
    define("lscAK", "lscAI Inheritance EnvironmentStatus Executor Environment LoggerManager lscAj ASSERT lsch lscAe req".split(" "), function(d, f, b, a, c, g, e, p, k, h, l) {
        function m(a) {
            this._callSuperConstructor(m);
            this.aa = q++;
            r.isDebugLogEnabled() && r.logDebug(g.resolve(58) + this.aa);
            this.i = !1;
            this.Pa = this.Xj = this.Oa = this.Wi = null;
            this.yc = this.Yf = !1;
            this.Ph = null;
            this.un = !1;
            this.gq = null;
            this.Kk = a;
            this.V = m;
            this.rC = new k(this)
        }

        function t(a) {
            a = a.toLowerCase();
            a = 0 == a.indexOf("http://") ?
                a.replace("http://", "ws://") : a.replace("https://", "wss://");
            if (u) {
                var b = "";
                d.Vq(a).forEach(function(a) {
                    "" !== b && (b += "; ");
                    b += a.name + "\x3d" + a.value
                });
                var c = {};
                0 < b.length && (c.headers = {
                    Cookie: b
                });
                return new u(a, "js.lightstreamer.com", c)
            }
            if ("undefined" != typeof WebSocket) return new WebSocket(a, "js.lightstreamer.com");
            if ("undefined" != typeof MozWebSocket) return new MozWebSocket(a, "js.lightstreamer.com");
            m.Qi();
            return null
        }
        var n = g.getLoggerProxy(h.gc),
            r = g.getLoggerProxy(h.cb),
            u = null;
        c.isNodeJS() && (u = l("faye-websocket").Client);
        var q = 1,
            v = !1,
            z = {};
        m.Qi = function(a) {
            a ? z[a] = !0 : v = !0
        };
        m.Us = function(a) {
            a ? delete z[a] : (v = !1, z = {})
        };
        m.ay = function() {
            for (var a in z) return !0;
            return v
        };
        d.jc(m, {
            sa: function(a) {
                if (v || a && z[a]) return !1;
                a = null;
                "undefined" != typeof WebSocket ? a = WebSocket : "undefined" != typeof MozWebSocket && (a = MozWebSocket);
                return a && 2 == a.prototype.CLOSED ? !1 : u || a
            },
            ua: !0,
            ta: function() {
                return !c.isBrowser() || "https:" != location.protocol
            },
            hc: function() {
                return !0
            },
            ic: !1,
            Bf: !0,
            lc: !1
        });
        m.prototype = {
            toString: function() {
                return ["[|WebSocketConnection",
                    this.i, this.Oa, this.Wi, this.Om(), "]"
                ].join("|")
            },
            ea: function() {
                if (this.Pa) {
                    r.logDebug(g.resolve(59));
                    this.Oa = null;
                    if (this.Pa) try {
                        this.Pa.close(1E3)
                    } catch (a) {
                        r.logDebug(g.resolve(60), a)
                    }
                    this.Na()
                }
            },
            Qz: function(b, h, f, q, k) {
                if (this.i) r.logError(g.resolve(52));
                else if (v) return !1;
                this.yc = !1;
                this.Ph = b.Gb;
                this.Oa = h;
                try {
                    this.Pa = t(this.Ph)
                } catch (l) {
                    return r.logDebug(g.resolve(61), l), !1
                }
                n.isDebugLogEnabled() && n.debug("Status timeout in " + this.Kk.xd() + " [currentConnectTimeoutWS]");
                a.addTimedTask(this.Rz, this.Kk.xd(),
                    this, [this.Oa]);
                var p = this;
                this.Pa.onmessage = function(a) {
                    p.pn(a, h, f)
                };
                this.Pa.onerror = function() {
                    p.rz(h, q)
                };
                this.Pa.onclose = function(a) {
                    p.mz(a, h, k, q)
                };
                this.Pa.onopen = function() {
                    if (c.isNodeJS()) {
                        var a = p.Pa.headers;
                        a["set-cookie"] && (a = e.Xz(a["set-cookie"]), d.qp(a))
                    }
                    p.Az(h)
                };
                return !0
            },
            Rz: function(a) {
                if (a == this.Oa && this.Pa && !this.un) try {
                    n.logDebug(g.resolve(62)), this.Kk.b.Km(), this.Pa.close(1E3)
                } catch (b) {
                    r.logDebug(g.resolve(63))
                }
            },
            pa: function(a, b) {
                if (this.i) return r.logError(g.resolve(53)), null;
                if (v) return !1;
                this.Xj = a;
                this.Wi = b;
                r.logDebug(g.resolve(64), a.zd());
                this.Om() && this.at(b);
                return !0
            },
            Yx: function(a) {
                return p.verifyOk(this.Ph) ? 0 == this.Ph.indexOf(a) : (r.logError(g.resolve(54)), !1)
            },
            Om: function() {
                return null != this.Pa && 1 == this.Pa.readyState
            },
            Dg: function(a, b) {
                if (!this.Om()) return null;
                b && (this.Et(b), a.Xi(d.Qo));
                r.isDebugLogEnabled() && r.logDebug(g.resolve(65) + this.aa, a.getFile(), a.getData());
                try {
                    this.Pa.send(a.getFile() + "\r\n" + a.getData())
                } catch (c) {
                    return r.logError(g.resolve(55), c), !1
                }
                return !0
            },
            at: function(a) {
                var b =
                    this.Dg(this.Xj, a);
                p.verifyOk(null !== b) || r.logError(g.resolve(56), a);
                b && (this.i = !0, this.Kk.ew(this.Oa))
            },
            Et: function(a) {
                this.Wi = a
            },
            pn: function(c, e, d) {
                this.Oa != e || b.isUnloaded() || (r.isDebugLogEnabled() && r.logDebug(g.resolve(66) + this.aa, c.data), this.Yf = !0, a.executeTask(d, [c.data, this.Wi]))
            },
            rz: function(c, e) {
                this.Oa != c || b.isUnloaded() || (r.logError(g.resolve(57)), this.yc |= !this.Yf, a.executeTask(e, ["wsc.unknown", this.Oa, !0, this.yc, !1]))
            },
            Az: function(a) {
                this.Oa != a || b.isUnloaded() || (this.un = !0, r.logDebug(g.resolve(67)),
                    this.Xj && this.at())
            },
            mz: function(c, e, d, h) {
                this.Oa != e || b.isUnloaded() || (c = c ? c.code : -1, r.logDebug(g.resolve(68), c, this.Yf), 1E3 == c || 1001 == c ? (a.modifyAllTaskParams(d, [this.Oa, !0]), a.addPackedTimedTask(d, 300), this.Na()) : 1011 == c ? (this.yc |= !this.Yf, d = this.Oa, this.Na(), a.executeTask(h, ["wsc.server", d, !0, this.yc, !0])) : (this.yc |= !this.Yf, d = this.Oa, this.Na(), a.executeTask(h, ["wsc." + c, d, !0, this.yc, !1])))
            },
            Na: function() {
                this.un = this.i = !1;
                this.Xj = this.Oa = null;
                this.Yf = !1;
                this.Ph = this.Pa = null
            },
            yd: function() {
                return this.rC
            },
            TA: function(a) {
                r.isDebugLogEnabled() && r.logDebug(g.resolve(69) + a + ") on WS connection oid\x3d" + this.aa);
                this.gq = a
            }
        };
        f(m, d);
        return m
    });
    define("lscI", ["Inheritance", "lscN"], function(d, f) {
        function b(a, c, g, e) {
            this._callSuperConstructor(b, [e]);
            this.gu = a;
            this.vu = g;
            this.c = c
        }
        b.prototype = {
            verifySuccess: function() {
                return !this.c.Nc(this.vu)
            },
            gf: function() {
                this.c.ej(this.gu)
            },
            Nw: function() {
                return this.cf.dj
            },
            uh: function() {}
        };
        d(b, f);
        return b
    });
    define("RecoveryBean", ["Assertions"], function(d) {
        function f() {
            0 == arguments.length ? this.zv() : (d.assert(2 == arguments.length, "Recovery error (1)"), this.Av(arguments[0], arguments[1]));
            d.assert(this.Vx(), "Recovery error (2)")
        }
        f.prototype = {
            Vx: function() {
                return this.Ya ? -1 != this.Zb : -1 == this.Zb
            },
            zv: function() {
                this.Ya = !1;
                this.Zb = -1
            },
            Av: function(b, a) {
                a.Ya ? b ? (this.Ya = !0, this.Zb = a.Zb) : (this.Ya = !1, this.Zb = -1) : b ? (this.Ya = !0, this.Zb = Date.now()) : (d.assert(-1 == a.Zb, "Recovery error (4)"), this.Ya = !1, this.Zb = -1)
            },
            vA: function() {
                this.Ya = !1;
                this.Zb = -1
            },
            wo: function(b) {
                return this.Ya ? (d.assert(-1 != this.Zb, "Recovery error (5)"), b - (Date.now() - this.Zb)) : b
            }
        };
        return f
    });
    define("lscr", "EnvironmentStatus Helpers LoggerManager Executor lscl lscAe lscI lscG lscq ASSERT BrowserDetection lscAK Assertions RecoveryBean RetryDelayCounter".split(" "), function(d, f, b, a, c, g, e, p, k, h, l, m, t, n) {
        function r(c, e, g, d, h, k, l) {
            this.aa = z++;
            q.isDebugLogEnabled() && q.logDebug(b.resolve(88), "oid\x3d" + this.aa);
            this.wl = a.packTask(this.Lz, this);
            this.vl = a.packTask(this.rn, this);
            this.ul = a.packTask(this.qn, this);
            this.R = c;
            this.le = e;
            this.Jb =
                0;
            this.a = 1;
            this.wa = 0;
            this.Ea = 100 * f.randomG(100);
            this.g = g;
            this.I = d;
            this.Ab = g.Ab;
            this.b = g.b;
            this.Ua = g.Ua;
            this.ga = null;
            this.W = g.W;
            this.Ca = g.ne();
            this.Fr = this.sg = this.kg = 0;
            this.Ie = this.Hd = this.Tm = null;
            this.reset();
            this.bg = !1;
            h ? (this.$e = h.$e, this.Jb = h.Jb, q.logDebug(b.resolve(89) + this.Jb), this.sessionId = h.sessionId, this.Kd = h.Kd, this.Ea = h.Ea, this.kg = h.kg, this.Vn = h.Vn, this.Im = h.Im, this.Za = new n(l, h.Za)) : (t.assert(!l, "Recovery unexpected"), this.Za = new n)
        }
        var u = [, "OFF", "CREATING", "CREATED", "FIRST_PAUSE", "FIRST_BINDING",
                "PAUSE", "BINDING", "RECEIVING", "STALLING", "STALLED", "SLEEP"
            ],
            q = b.getLoggerProxy(g.gc),
            v = b.getLoggerProxy(g.Se),
            z = 1;
        r.Zk = 1;
        r.Ud = 2;
        r.Ro = 3;
        r.To = 4;
        r.So = 5;
        r.Pt = 7;
        r.au = 8;
        r.xC = 9;
        r.zC = 10;
        r.Yt = 6;
        r.Yk = 11;
        r.prototype = {
            reset: function() {
                q.isDebugLogEnabled() && q.logDebug(b.resolve(90) + this.aa);
                this.$e = 0;
                this.sessionId = this.Kd = null;
                this.kg = this.Jb = 0;
                this.Pd = this.Cc = this.ol = !1;
                this.qo = "";
                this.hd = !1;
                this.Za = new n;
                this.bg = !1
            },
            fg: function() {},
            Hb: function(a) {
                q.isDebugLogEnabled() && q.logDebug(b.resolve(91) + this.aa + "):",
                    u[this.a], "-\x3e", u[a]);
                var c = this.a;
                this.a = a;
                this.wa++;
                a = this.wa;
                this.a != c && this.g.IB(this.I);
                return a == this.wa
            },
            ph: function() {
                this.Ea++
            },
            Nc: function(a) {
                return this.Ea == a
            },
            zm: function() {
                var a = this.a;
                return 1 == a ? g.Db : 11 == a ? this.bg ? g.zg : g.Ag : 2 == a ? this.Za.Ya ? g.zg : g.CONNECTING : 3 == a || 4 == a || 5 == a ? g.Ra + this.Pq() : 10 == a ? g.yg : g.Ra + this.Lq()
            },
            i: function() {
                return 1 != this.a && 2 != this.a && 11 != this.a
            },
            sy: function() {
                return 2 == this.a || 7 == this.a || 5 == this.a
            },
            xr: function() {
                return 3 == this.a || 8 == this.a || 9 == this.a || 10 == this.a
            },
            qy: function() {
                return !this.R
            },
            Wa: function() {
                return null == this.Kd ? this.Vn : this.Kd
            },
            Qb: function() {
                return this.sessionId
            },
            Tg: function(a, e) {
                var g = 1 != this.a && 11 != this.a ? !1 : !0;
                if (!c.Hp()) return q.logDebug(b.resolve(92), this), this.Ia("mad", g, !0), !1;
                0 == g && (q.logDebug(b.resolve(93), this), this.Ia("new." + (e || ""), !1, !1));
                q.logInfo(b.resolve(82), this);
                this.reset();
                this.zs();
                this.Ua.X("sessionId", null);
                this.Ua.X("serverSocketName", null);
                this.Ua.X("serverInstanceAddress", null);
                this.Vn = this.Ua.Oh;
                this.Im = this.b.Wn;
                this.ph();
                return !0
            },
            de: function() {
                if (!c.Hp()) return this.Ia("madb", !1, !0), !1;
                this.$e++;
                h.verifyOk(6 == this.a || 4 == this.a || 1 == this.a) || q.logError(b.resolve(70));
                if (1 == this.a) {
                    if (!this.Hb(4)) return !1;
                    this.zs()
                }
                this.lh(!0);
                this.ph();
                this.R ? q.logDebug(b.resolve(94), this) : q.logInfo(b.resolve(83), this);
                return !0
            },
            Bd: function() {
                return 3 == this.a || 5 == this.a || 7 == this.a || 8 == this.a || 9 == this.a || 10 == this.a
            },
            Ns: function(a, c, e) {
                this.I = a;
                this.Cc || (q.logDebug(b.resolve(95), this), this.hd = !1, 2 == this.a || 11 == this.a || 1 == this.a ?
                    (q.logError(b.resolve(71)), this.g.ef(this.I, c, e)) : 6 == this.a || 4 == this.a ? this.g.so(this.I, c, e) : (this.Cc = !0, this.Pd = e, this.qo = c, this.ej(c)))
            },
            sA: function(a) {
                this.I = a;
                this.hd || (q.logDebug(b.resolve(96), this), h.verifyOk(2 != this.a && 11 != this.a && 1 != this.a) || q.logError(b.resolve(72)), 6 == this.a || 4 == this.a ? this.g.vt(this.I) : (this.hd = !0, this.ej("slow")))
            },
            zs: function() {
                1 != this.a && 11 != this.a || this.Ab.dA();
                this.R && this.le && this.Ab.Rs()
            },
            lh: function(a) {
                this.a != r.Zk && this.a != r.Ud && this.a != r.Yk && (0 < this.b.ig ? this.W.GB(this.b.ig,
                    a) : this.W.NB(a))
            },
            Ia: function(a, c, e) {
                1 != this.a && 2 != this.a && 11 != this.a ? (this.g.Uj(this.Wa()), c || this.xA(a), this.I = this.g.os(this.I, e), this.Ua.X("sessionId", null), this.Ua.X("serverSocketName", null), this.Ua.X("serverInstanceAddress", null), this.Ss(), q.logInfo(b.resolve(84), this, a)) : this.Za.Ya && (this.Za = new n, this.I = this.g.os(this.I, e));
                this.mg(!e)
            },
            Ss: function() {
                this.b.Qs(this.b.hg);
                this.b.Os(this.b.hg)
            },
            mg: function(a) {
                this.ph();
                this.reset();
                this.Hb(a ? 11 : 1);
                q.logDebug(b.resolve(97), this)
            },
            Nv: function(a) {
                if (this.Hb(3 ==
                        this.a ? 4 : 6)) {
                    this.ph();
                    var c = a;
                    this.R && (a >= this.b.De || this.b.X("pollingInterval", a), c = this.fx());
                    4 != this.a && c && 0 < c ? (q.logDebug(b.resolve(98)), this.ib("pause", c)) : this.Ae("noPause", this.wa)
                }
            },
            Ae: function(a, c, e, g) {
                c == this.wa && (q.isDebugLogEnabled() && q.logDebug(b.resolve(99) + a + "] while", u[this.a], "cause\x3d", g), a = "timeout." + this.a + "." + this.$e, 11 == this.a && g && (a = g), 2 == this.a ? (e = this.Za.wo(this.b.Qh), this.Za.Ya && 0 < e ? (q.isDebugLogEnabled() && q.logDebug(b.resolve(100) + e), this.b.Km(), this.g.Hh(this.I, a, this.Pd)) :
                    (q.logDebug(b.resolve(101)), this.Ia("create.timeout", !0, !1), this.b.Km(), this.ib("zeroDelay", 0, "create.timeout"))) : 3 == this.a || 7 == this.a || 10 == this.a || 11 == this.a ? this.hd || this.Cc ? this.g.ef(this.I, a + ".switch", this.Pd) : !this.R || this.le ? this.bg ? (q.logDebug(b.resolve(102)), this.g.Hh(this.I, a, this.Pd)) : (q.logDebug(b.resolve(103)), this.Tg(this.sessionId, a)) : this.g.ef(this.I, a, !1) : 5 == this.a ? (this.sg--, this.hd || this.Cc ? this.g.ef(this.I, a + ".switch", this.Pd) : 0 < this.sg || this.le ? this.Tg(this.sessionId, a) : this.R ?
                    this.g.ef(this.I, a + ".switch", this.Pd) : this.Xb(this.I, a)) : 6 == this.a ? (this.R && this.Ab.YB(e), this.de("loop")) : 4 == this.a ? this.de("loop1") : 8 == this.a ? this.bC() : 9 == this.a ? this.aC() : (h.fail(), q.logError(b.resolve(73), this)))
            },
            eo: function() {
                return this.le || this.g.eo()
            },
            Xb: function(a, b) {
                var c = this.eo();
                c && this.Ia("giveup", 1 != this.a && 11 != this.a ? !1 : !0, !0);
                this.g.Xb(a, b, c)
            },
            ia: function(a, c, e, g, d, h, k) {
                var v = this.Za.wo(this.b.Qh);
                q.isDebugLogEnabled() && q.logDebug(b.resolve(104), u[this.a], a, "closedOnServer\x3d" +
                    c, "fromWS\x3d" + e, "unableToOpen\x3d" + g, "noImplAvailable\x3d" + d, "possibleLoop\x3d" + h, "tryRecovery\x3d" + k, "timeLeft\x3d" + v);
                e = k && 0 < v;
                if (8 == this.a || 10 == this.a || 9 == this.a || 7 == this.a || 6 == this.a) e ? (q.logDebug(b.resolve(105)), this.bg = !0, this.Hb(11), this.ib("firstRetryMaxDelay", f.randomG(this.b.cj), a)) : (q.logDebug(b.resolve(106)), this.Ia(a, c, !1), h ? this.ib("retryDelay", this.sl(), a) : this.ib("firstRetryMaxDelay", f.randomG(this.b.cj), a));
                else if (2 == this.a || 3 == this.a || 5 == this.a) this.Za.Ya && 0 < v && !c ? (q.logDebug(b.resolve(107)),
                    this.bg = !0, this.Hb(11), this.ib("currentRetryDelay", this.sl(), a), this.b.pr()) : this.Cc && !this.le || l.isProbablyAndroidBrowser() ? (q.logDebug(b.resolve(108)), this.g.ef(this.I, this.qo + ".error", this.Pd)) : (h = c ? "closed on server" : "socket error", q.logDebug(b.resolve(109) + h), this.Ia(a, c, !1), this.ib("currentRetryDelay", this.sl(), a), this.b.pr())
            },
            jn: function(a) {
                this.ga && this.ga.Hq && this.ga.Hq();
                8 == this.a || 9 == this.a || 10 == this.a || 3 == this.a ? this.Cc ? this.g.so(this.I, this.qo, this.Pd) : this.hd ? this.g.vt(this.I) : this.Nv(a) :
                    (h.fail(), q.logError(b.resolve(75), this))
            },
            ja: function() {
                2 == this.a ? this.Hb(3) && this.$B() : 3 != this.a && (7 == this.a || 5 == this.a || 9 == this.a || 10 == this.a || 8 == this.a ? this.Hb(8) && this.cC() : (h.fail(), q.logError(b.resolve(76), this)))
            },
            Mi: function() {
                c.Mx();
                this.Ie = f.getTimeStamp();
                h.verifyOk(1 == this.a || 11 == this.a) || q.logError(b.resolve(77));
                if (!this.Hb(2)) return !1;
                this.ib("currentConnectTimeout", this.Hw());
                this.ga = this.g.Mq()
            },
            Kg: function() {
                this.Ie = f.getTimeStamp();
                h.verifyOk(6 == this.a || 4 == this.a) || q.logError(b.resolve(78),
                    this);
                if (!this.Hb(6 == this.a ? 7 : 5)) return !1;
                this.ib("bindTimeout", this.tw());
                this.ga = this.g.Mq()
            },
            ib: function(c, e, g) {
                q.isDebugLogEnabled() && q.logDebug(b.resolve(110) + e + " [" + c + "]");
                return a.addTimedTask(this.Ae, e, this, [c, this.wa, e, g])
            },
            cC: function() {
                if (0 < this.b.Ef) {
                    var b = f.getTimeStamp();
                    50 > b - this.Fr && this.Tm ? a.modifyTaskParam(this.Tm, 1, this.wa) : (this.Fr = b, this.Tm = this.ib("keepaliveInterval", this.b.Ef))
                }
            },
            bC: function() {
                this.Hb(9) && this.ib("stalledTimeout", this.b.Bk)
            },
            aC: function() {
                this.Hb(10) && (this.bg =
                    0 < this.Za.wo(this.b.Qh), this.ib("reconnectTimeout", this.b.Hd))
            },
            $B: function() {
                h.verifyValue(this.a, 3) || q.logError(b.resolve(79));
                this.ib("stalledTimeout", this.b.Bk)
            },
            Hw: function() {
                return this.xd()
            },
            tw: function() {
                return this.R ? this.xd() + this.b.vj : 0 < this.sg && null != this.Hd ? this.Hd : this.xd()
            },
            fx: function() {
                if (4 == this.a) return this.b.De;
                var a = this.b.De;
                if (this.Ie) var b = f.getTimeStamp() - this.Ie,
                    a = a > b ? a - b : 0;
                return a
            },
            sl: function() {
                var a = f.getTimeStamp() - this.Ie,
                    b = this.b.Oc;
                return a > b ? 0 : b - a
            },
            Wu: function() {
                this.Ie ||
                    (h.fail(), q.logError(b.resolve(80), this), this.Hd = null);
                var a = f.getTimeStamp() - this.Ie,
                    c = this.xd();
                this.Hd = (a > c ? c : a) + c
            },
            Lz: function(a, b) {
                !d.isUnloaded() && this.Nc(b) && "" !== a && (null == a ? (c.kk(), this.ia("nullresp")) : this.ga.gp(b, a))
            },
            rn: function(a, b, e, g, h) {
                !d.isUnloaded() && this.Nc(b) && (c.kk(), this.ia("failure." + a, !1, e, g, null, h, !0))
            },
            qn: function(a, b) {
                this.Nc(a) && (c.kk(), this.ia("wrongend", null, b, null, null, null, !0))
            },
            sq: function() {
                this.ia("eval")
            },
            Iz: function() {
                this.Cc || this.hd || this.g.Jz(this.I)
            },
            Oz: function() {
                v.isDebugLogEnabled() &&
                    v.logDebug(b.resolve(111));
                this.ja();
                8 == this.a && (this.sg = 1)
            },
            Hz: function(a) {
                v.isDebugLogEnabled() && v.logDebug(b.resolve(112), a);
                this.kg = a;
                this.b.X("maxBandwidth", a)
            },
            pz: function() {
                v.isDebugLogEnabled() && v.logDebug(b.resolve(113));
                this.ia("error41", !0)
            },
            tz: function() {
                v.isDebugLogEnabled() && v.logDebug(b.resolve(114));
                this.ja();
                this.g.xc()
            },
            yz: function(a, c, e, g, d, f) {
                v.isDebugLogEnabled() && v.logDebug(b.resolve(115));
                var l = this.Wa(),
                    p = l;
                null == c || this.Im || (p = c = k.ov(p, c));
                this.Kd = p;
                l != this.Kd && (this.g.Uj(l),
                    this.g.on(this.Kd));
                g && (this.R ? this.b.X("idleTimeout", g) : this.b.X("keepaliveInterval", g));
                2 == this.a ? (null != this.sessionId && this.sessionId != a && (q.logInfo(b.resolve(85) + a + " over " + this.sessionId), this.reset()), this.sessionId = a) : (h.verifyValue(this.sessionId, a) || q.logError(b.resolve(81)), this.Wu());
                this.Ab.HB(this.R);
                this.ja();
                3 == this.a ? this.Za.Ya ? this.Za.vA() : (this.g.cd(e), this.Ua.X("sessionId", a), this.Ua.X("serverSocketName", d), this.Ua.X("serverInstanceAddress", this.Kd), this.ol && (this.Fi(), this.ol = !1)) : (this.g.Vf(e), this.Vf());
                f && this.g.sz(f)
            },
            Nz: function(a) {
                v.isDebugLogEnabled() && v.logDebug(b.resolve(116));
                this.Ab.TB(a);
                this.ja()
            },
            uz: function(a) {
                v.isDebugLogEnabled() && v.logDebug(b.resolve(117));
                this.jn(a)
            },
            Vj: function(a) {
                c.kk();
                this.ia(a, !0)
            },
            vh: function(a) {
                v.isDebugLogEnabled() && v.logDebug(b.resolve(118), a);
                this.Ia("end", !0, !0)
            },
            tn: function(a, b) {
                this.ja();
                this.g.tn(a, b)
            },
            we: function(a) {
                this.ja();
                this.g.we(a)
            },
            ve: function(a) {
                this.ja();
                this.g.ve(a)
            },
            xe: function(a) {
                this.ja();
                this.g.xe(a)
            },
            kn: function(a,
                b) {
                this.ja();
                this.g.kn(a, b)
            },
            nn: function(a, b) {
                this.ja();
                this.g.nn(a, b)
            },
            ln: function(a, b, c, e) {
                this.ja();
                this.g.ln(a, b, e, c)
            },
            ye: function(a, b) {
                this.ja();
                this.g.ye(a, b)
            },
            Tf: function(a, b, c, e) {
                this.ja();
                this.g.Tf(a, b, e, c)
            },
            sn: function(a, b, c) {
                this.ja();
                this.g.sn(a, b, c)
            },
            Uf: function(a, b) {
                this.vh(b);
                this.g.Uf(a, b)
            },
            onUnsubscription: function(a) {
                this.ja();
                this.g.onUnsubscription(a)
            },
            onSubscription: function(a, b, c, e, g) {
                this.ja();
                this.g.onSubscription(a, b, c, e, g)
            },
            Xf: function(a, b) {
                this.ja();
                this.g.Xf(a, b)
            },
            $r: function() {
                this.Jb++
            },
            ej: function(a) {
                q.logInfo(b.resolve(86), this);
                var c = k.Qw(a, this.Ab.kj());
                a = new e(a, this, this.Ea, this.b);
                this.W.Jc(this.sessionId, c, p.Tk, a)
            },
            xA: function(a) {
                q.logInfo(b.resolve(87), this);
                a = k.Jw(this.sessionId, a);
                this.sm(this.sessionId, a, p.Vd, null, this.Wa())
            },
            Fi: function() {
                1 != this.a && 11 != this.a && (2 == this.a ? this.ol = !0 : 0 >= this.kg && 0 >= this.b.Wb || this.kg != this.b.Wb && this.W.Jc(null, k.Bw(this.b), p.Rk, null))
            },
            Vf: function() {
                this.Ss()
            },
            sm: function() {
                throw Error("abstract method");
            },
            xd: function() {
                return this.b.pc
            }
        };
        return r
    });
    define("lscAJ", [], function() {
        function d() {
            this.En = !1;
            this.ck = 0;
            this.Ko = !1
        }
        d.prototype = {
            wq: function(d, b) {
                if (!b && !this.ly(d)) return null;
                0 == this.ck && "/*" == d.substring(0, 2) && (this.Ko = !0);
                var a = -1;
                if (b && !this.Ko) a = d.length;
                else {
                    a = d.lastIndexOf(";\n");
                    if (0 > a) return null;
                    a += 2
                }
                var c = d.substring(this.ck, a);
                0 == this.ck && this.Ko && (c = c.substring(2, c.length));
                this.ck = a;
                return c
            },
            no: function(d) {
                return this.wq(d, !1)
            },
            mo: function(d) {
                return this.wq(d, !0)
            },
            ly: function(d) {
                if (this.En) return !0;
                var b = d.indexOf("setPhase("),
                    a = d.indexOf("setPhase(ph)");
                if (-1 < b) {
                    if (-1 >= a) return this.En = !0;
                    b = d.indexOf("setPhase(", b + 1);
                    if (-1 < b && d.lastIndexOf(";\n") > b) return this.En = !0
                }
                return !1
            }
        };
        return d
    });
    define("lscAN", "lscAI Inheritance Executor BrowserDetection EnvironmentStatus lscAJ Environment LoggerManager lscAj lscAe req".split(" "), function(d, f, b, a, c, g, e, p, k, h, l) {
        function m() {
            this._callSuperConstructor(m);
            this.aa = v++;
            n.isDebugLogEnabled() && n.logDebug(p.resolve(120) + this.aa);
            this.i = !1;
            this.yb = this.Y = this.kc = this.K = null;
            this.lo = !1;
            this.V = m
        }

        function t(a) {
            return function() {
                b.executeTask(a)
            }
        }
        var n = p.getLoggerProxy(h.cb),
            r = e.isBrowser() ? 2 : 3,
            u = !0,
            q;
        e.isNodeJS() &&
            (q = l("xmlhttprequest-cookie").XMLHttpRequest);
        var v = 1,
            z = null;
        d.jc(m, {
            sa: function() {
                if (null !== z) return z;
                a.isProbablyIE(9, !0) ? z = !1 : "undefined" != typeof XMLHttpRequest ? "undefined" != typeof(new XMLHttpRequest).withCredentials ? z = !0 : e.hy() && (z = !0) : !e.isBrowser() && q && (z = !0);
                null === z && (z = !1);
                return z
            },
            Bf: function() {
                return !a.isProbablyOldOpera() && !a.isProbablyPlaystation()
            },
            ua: !0,
            ta: !0,
            hc: function() {
                return e.isNodeJS() ? !0 : "file:" != h.vg ? !0 : e.isBrowserDocument() ? !1 : !0
            },
            ic: !1,
            lc: !0
        });
        m.prototype = {
            toString: function() {
                return ["[|XSXHRConnection",
                    this.i, this.K, this.kc, "]"
                ].join("|")
            },
            ea: function() {
                if (this.i) {
                    n.isDebugLogEnabled() && n.logDebug(p.resolve(121) + this.aa);
                    this.K = null;
                    if (this.Y) try {
                        this.Y.abort()
                    } catch (a) {
                        n.logDebug(p.resolve(122))
                    }
                    this.Na()
                }
            },
            pa: function(a, c, e, d, h) {
                if (this.i) return null;
                this.Y = q ? new q : new XMLHttpRequest;
                this.yb = new g;
                e = b.packTask(this.pn, this, [c, e, h, d]);
                this.Y.onreadystatechange = t(e);
                this.K = c;
                this.kc = null;
                n.isDebugLogEnabled() && n.logDebug(p.resolve(123) + this.aa, a.getFile(), a.getData());
                try {
                    this.Y.open(a.We, a.zd(),
                        !0);
                    this.Y.withCredentials = a.bq;
                    var f = a.lm;
                    if (f)
                        for (var k in f) this.Y.setRequestHeader(k, f[k]);
                    this.Y.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                    this.Y.send(a.getData());
                    this.i = !0
                } catch (l) {
                    return n.logError(p.resolve(119) + this.aa, l), !1
                }
                return !0
            },
            pn: function(a, e, g, d) {
                this.K != a || c.isUnloaded() || (a = null, this.yf() && e && (3 == this.Y.readyState ? a = this.yb.no(this.Y.responseText) : 4 == this.Y.readyState && (a = this.yb.mo(this.Y.responseText)), n.isDebugLogEnabled() && a && n.logDebug(p.resolve(124) +
                    this.aa, a), null != a && b.executeTask(e, [a, this.K])), 4 == this.Y.readyState && (this.yf() || (this.lo ? (d && (n.isDebugLogEnabled && n.logDebug(p.resolve(125) + this.aa), b.executeTask(d, ["status0", this.K, !1, u, !1])), u = !u, this.lo = !1) : e && b.executeTask(e, [null, this.K])), n.isDebugLogEnabled && n.logDebug(p.resolve(126) + this.aa), 4 != this.Y.readyState && "" != a || !g || b.addTimedTask(this.Of, 100, this, [this.K, g]), this.Na()))
            },
            Of: function(a, c) {
                b.executeTask(c, [a])
            },
            Na: function() {
                this.i = !1;
                this.K = null;
                this.Y && (delete this.Y.onreadystatechange,
                    delete this.Y)
            },
            yf: function() {
                try {
                    if (null === this.kc) {
                        if (this.Y.readyState < r) return !1;
                        this.kc = 200 <= this.Y.status && 299 >= this.Y.status;
                        0 == this.Y.status && (this.lo = !0)
                    }
                    return this.kc
                } catch (a) {
                    return n.logDebug(p.resolve(127) + this.aa, a), !1
                }
            }
        };
        f(m, d);
        return m
    });
    define("lscAE", "lscAI Inheritance Executor EnvironmentStatus lscAJ LoggerManager lscAe".split(" "), function(d, f, b, a, c, g, e) {
        function p() {
            this._callSuperConstructor(p);
            this.i = !1;
            this.ya = this.yb = this.K = null;
            this.dk = 0;
            this.V = p
        }

        function k(a) {
            return function() {
                b.executeTask(a)
            }
        }
        var h = g.getLoggerProxy(e.cb),
            l = null;
        d.jc(p, {
            sa: function() {
                return null !== l ? l : l = "undefined" != typeof XDomainRequest ? !0 : !1
            },
            Bf: !0,
            ua: !0,
            ta: !1,
            hc: !1,
            ic: !1,
            lc: !1
        });
        p.prototype = {
            toString: function() {
                return ["[|IEXSXHRConnection",
                    this.i, this.K, "]"
                ].join("|")
            },
            ea: function() {
                if (this.i) {
                    h.logDebug(g.resolve(129));
                    this.K = null;
                    if (this.ya) try {
                        this.ya.abort()
                    } catch (a) {
                        h.logDebug(g.resolve(130))
                    }
                    this.Na()
                }
            },
            pa: function(a, e, d, f, l) {
                if (this.i) return null;
                this.dk = 0;
                this.ya = new XDomainRequest;
                this.yb = new c;
                l = b.packTask(this.uA, this, [e, d, l]);
                var q = b.packTask(this.zp, this, [e, f, "xdr.err"]);
                f = b.packTask(this.zp, this, [e, f, "xdr.timeout"]);
                d = b.packTask(this.Bs, this, [e, d, !1]);
                this.ya.onload = k(l);
                this.ya.onerror = k(q);
                this.ya.ontimeout = k(f);
                this.ya.onprogress =
                    k(d);
                this.K = e;
                h.isDebugLogEnabled() && h.logDebug(g.resolve(131), a.getFile(), a.getData());
                try {
                    this.ya.open(a.We, a.zd()), this.ya.send(a.getData()), this.i = !0
                } catch (v) {
                    return h.logError(g.resolve(128), v), !1
                }
                return !0
            },
            zp: function(c, e, d) {
                this.K != c || a.isUnloaded() || (h.logDebug(g.resolve(132)), b.executeTask(e, [d, c, !1, 0 == this.dk, !1]))
            },
            Bs: function(c, e, d) {
                this.K != c || a.isUnloaded() || (this.dk++, e && (c = d ? this.yb.mo(String(this.ya.responseText)) : this.yb.no(String(this.ya.responseText)), h.isDebugLogEnabled() && h.logDebug(g.resolve(133),
                    c), null != c && b.executeTask(e, [c, this.K])))
            },
            uA: function(c, e, d) {
                this.K != c || a.isUnloaded() || (this.Bs(c, e, !0), this.Na(), h.logDebug(g.resolve(134)), d && b.addTimedTask(this.Of, 100, this, [d, c]))
            },
            Of: function(a, c) {
                b.executeTask(a, [c])
            },
            Na: function() {
                this.i = !1;
                this.yb = this.K = null;
                this.dk = 0;
                this.ya && (this.ya.onload = null, this.ya.onerror = null, this.ya.ontimeout = null, this.ya = this.ya.onprogress = null)
            }
        };
        f(p, d);
        return p
    });
    define("lscAA", ["lscAI", "Inheritance", "Executor"], function(d, f, b) {
        function a() {
            this._callSuperConstructor(a)
        }
        d.jc(a, {
            sa: !1,
            ua: !1,
            ta: !1,
            hc: !1,
            ic: !1,
            lc: !1
        });
        a.prototype = {
            pa: function(a, g, e) {
                e && b.addTimedTask(this.$c, 1E3, this, [e, g]);
                return !0
            },
            $c: function(a, g) {
                b.executeTask(a, ["", g])
            }
        };
        f(a, d);
        return a
    });
    define("IFrameHandler", ["BrowserDetection", "EnvironmentStatus", "Environment"], function(d, f, b) {
        var a = d.isProbablyAWebkit() && d.isProbablyChrome(32, !0) ? null : "about:blank",
            c = {},
            g = {
                createFrame: function(e, g) {
                    if (!b.isBrowserDocument()) return null;
                    var f = document.getElementsByTagName("BODY")[0];
                    if (!f) return null;
                    g = g || a;
                    var h = document.createElement("iframe");
                    h.style.visibility = "hidden";
                    h.style.height = "0px";
                    h.style.width = "0px";
                    h.style.display = "none";
                    h.name = e;
                    h.id = e;
                    d.isProbablyIE() || d.isProbablyOldOpera() ? (h.src =
                        g, f.appendChild(h)) : (f.appendChild(h), h.src = g);
                    try {
                        if (h.contentWindow) {
                            try {
                                h.contentWindow.name = e
                            } catch (l) {}
                            c[e] = h.contentWindow;
                            return c[e]
                        }
                        return document.frames && document.frames[e] ? (c[e] = document.frames[e], c[e]) : null
                    } catch (l) {
                        return null
                    }
                },
                getFrameWindow: function(a, b, d) {
                    b && !c[a] && this.createFrame(a, d);
                    return c[a] || null
                },
                disposeFrame: function(a) {
                    if (c[a]) {
                        try {
                            document.getElementsByTagName("BODY")[0].removeChild(document.getElementById(a))
                        } catch (b) {}
                        delete c[a]
                    }
                },
                removeFrames: function() {
                    for (var a in c) try {
                        document.getElementsByTagName("BODY")[0].removeChild(document.getElementById(a))
                    } catch (b) {}
                    c = {}
                }
            };
        g.createFrame = g.createFrame;
        g.getFrameWindow = g.getFrameWindow;
        g.disposeFrame = g.disposeFrame;
        g.removeFrames = g.removeFrames;
        f.addUnloadHandler(g.removeFrames);
        return g
    });
    define("lscg", ["lscd", "Inheritance"], function(d, f) {
        function b() {}
        b.prototype = {
            xm: function() {
                return 15
            },
            Am: function(a) {
                return a ? encodeURIComponent(a).length - a.length : 0
            },
            Ho: function(a) {
                return "LS_querystring\x3d" + encodeURIComponent(a)
            }
        };
        f(b, d);
        return b
    });
    define("lscf", ["lscg", "Inheritance"], function(d, f) {
        function b() {}
        b.prototype = {
            toString: function() {
                return "[LegacyEncoder]"
            },
            rf: function() {
                return ".html"
            },
            Ho: function(a) {
                return a
            }
        };
        f(b, d);
        return b
    });
    define("lscAB", "lscAI lscAA Inheritance IFrameHandler Executor Environment LoggerManager lscf lscAe lscAj".split(" "), function(d, f, b, a, c, g, e, p, k, h) {
        function l(b) {
            this._callSuperConstructor(l);
            b && (this.target = h.mk(b), a.getFrameWindow(b, !0));
            this.i = !1;
            this.V = l;
            this.Dj = 0
        }
        var m = new p,
            t = e.getLoggerProxy(k.cb);
        d.jc(l, {
            sa: function() {
                return g.isBrowserDocument()
            },
            ua: !0,
            ta: !0,
            hc: !0,
            ic: !0,
            lc: !1
        });
        l.prototype = {
            toString: function() {
                return ["[|FormConnection", this.target,
                    "]"
                ].join("|")
            },
            ea: function() {
                t.logDebug(e.resolve(136));
                this.i = !1;
                this.Dj++
            },
            pa: function(a, b, g, d) {
                if (this.i) return null;
                this._callSuperMethod(l, this.ti, [a, b, g, d]);
                try {
                    this.Dj++;
                    var h = this.nw();
                    if (!h) return !1;
                    t.isDebugLogEnabled() && t.logDebug(e.resolve(137), a.getFile(), a.getData());
                    h.Uc.method = a.We;
                    h.Uc.target = this.target;
                    h.Uc.action = a.zd();
                    h.ek.value = a.getData();
                    h.Uc.submit();
                    c.addTimedTask(this.Cv, 1E3, this, [h.Uc, this.Dj]);
                    this.i = !0
                } catch (f) {
                    return t.logError(e.resolve(135), f), !1
                }
                return !0
            },
            nw: function() {
                var a =
                    document.getElementsByTagName("BODY")[0];
                if (!a) return null;
                var b = {};
                b.Uc = document.createElement("FORM");
                try {
                    b.Uc.acceptCharset = "utf-8"
                } catch (c) {}
                b.Uc.style.display = "none";
                b.ek = document.createElement("INPUT");
                b.ek.type = "hidden";
                b.ek.name = "LS_querystring";
                b.Uc.appendChild(b.ek);
                a.appendChild(b.Uc);
                return b
            },
            Cv: function(a, b) {
                a.parentNode.removeChild(a);
                b == this.Dj && (this.i = !1)
            },
            yd: function() {
                return m
            }
        };
        b(l, f);
        return l
    });
    define("lscAC", "lscAI lscAA lscAH Inheritance IFrameHandler Executor EnvironmentStatus Environment lscAB LoggerManager lscf lscAe lscAj".split(" "), function(d, f, b, a, c, g, e, p, k, h, l, m, t) {
        function n(a) {
            this._callSuperConstructor(n);
            this.target = t.mk(a);
            this.Kc = 0;
            this.i = !1;
            this.gj = null;
            c.getFrameWindow(this.target, !0);
            this.V = n
        }
        var r = new l,
            u = h.getLoggerProxy(m.cb);
        d.jc(n, {
            sa: function() {
                return p.isBrowserDocument()
            },
            ua: !1,
            ta: !1,
            hc: !0,
            ic: !0,
            Bf: !0,
            lc: !1
        });
        n.prototype = {
            toString: function() {
                return ["[|FrameConnection", this.i, this.target, this.Kc, this.gj, "]"].join("|")
            },
            hu: function(a) {
                a == this.Kc && (this.Kc++, this.i && (this.ip(this.Kc, b.Bu), this.i = !1))
            },
            ea: function() {
                u.logDebug(h.resolve(140));
                var a = ++this.Kc;
                g.addTimedTask(this.hu, 0, this, [a])
            },
            ip: function(a, b, g, d, f) {
                if (a == this.Kc && !e.isUnloading()) {
                    this._callSuperMethod(n, this.ti, [b, g, d, f]);
                    this.Kc++;
                    u.isDebugLogEnabled() && u.logDebug(h.resolve(141), b.getFile(), b.getData());
                    try {
                        var k = c.getFrameWindow(this.target);
                        if (null == k) return u.logError(h.resolve(138)), !1;
                        k.location.replace(b.Cx());
                        this.i = !0
                    } catch (l) {
                        return u.logError(h.resolve(139), l), !1
                    }
                    return !0
                }
            },
            Dy: function(a, b, c, e) {
                this.gj || (this.gj = new k(this.target));
                this.Kc++;
                if (a = this.gj.pa(a, b, c, e)) this.i = !0;
                return a
            },
            pa: function(a, c, e, d) {
                if (a.method == b.ri) return this.Dy(a, c, e, d);
                var h = ++this.Kc;
                g.addTimedTask(this.ip, 0, this, [h, a, c, e, d]);
                return !0
            },
            yd: function() {
                return r
            }
        };
        a(n, f);
        return n
    });
    define("Dismissable", ["Executor"], function(d) {
        function f() {
            this.initTouches()
        }
        f.prototype = {
            clean: function() {},
            initTouches: function(b) {
                this.xo = this.wf = 0;
                this.timeout = b || 5E3
            },
            lC: function(b) {
                b == this.xo && 0 >= this.wf && this.clean()
            },
            dismiss: function() {
                this.wf--;
                0 >= this.wf && d.addTimedTask(this.lC, this.timeout, this, [this.xo])
            },
            touch: function() {
                this.xo++;
                0 > this.wf && (this.wf = 0);
                this.wf++
            }
        };
        f.prototype.touch = f.prototype.touch;
        f.prototype.dismiss = f.prototype.dismiss;
        f.prototype.clean = f.prototype.clean;
        f.prototype.initTouches =
            f.prototype.initTouches;
        return f
    });
    define("lscy", "LoggerManager lscAC lscAH lscAj Executor EnvironmentStatus IFrameHandler Global Environment Inheritance Dismissable lscAe Helpers".split(" "), function(d, f, b, a, c, g, e, p, k, h, l, m, t) {
        function n(a) {
            this.path = a;
            this.Hg = t.randomG();
            this.status = k.isBrowserDocument() && (window.ActiveXObject || "undefined" != typeof XMLHttpRequest) ? 2 : -1;
            this.zi = ++u;
            this.Va = "LS_AJAXFRAME_" + this.zi;
            this.initTouches();
            this.Ru()
        }
        var r = d.getLoggerProxy(m.cb),
            u = 0,
            q = {};
        n.rw = function(a) {
            q[a] || (q[a] =
                new n(a), q[a].pa(!1));
            return q[a]
        };
        n.prototype = {
            toString: function() {
                return ["[|AjaxFrameHandler", this.status, "]"].join("|")
            },
            Ru: function() {
                var a = this;
                p.qa(this.zi, "LS_a", function(b) {
                    a.lz(b)
                }, "A")
            },
            clean: function() {
                this.status = -1;
                p.Ii(this.zi, "LS_a", "A");
                var a = this.path;
                q[a] && delete q[a];
                e.disposeFrame(this.Va)
            },
            Xc: function(a) {
                this.Hg++;
                this.status = a ? 3 : 0
            },
            pa: function(e) {
                if (-1 != this.status && (r.logDebug(d.resolve(142)), !this.Da())) {
                    this.Xc(e);
                    e = this.Hg;
                    a.vr() && r.logDebug(d.resolve(143));
                    var g = "id\x3d" +
                        this.zi + "\x26";
                    a.rj() || (g += "domain\x3d" + a.sc() + "\x26");
                    g = new b(this.path, "xhr.html", g);
                    (new f(this.Va)).pa(g);
                    c.addTimedTask(this.kw, 1E4, this, [e]);
                    c.addTimedTask(this.Gx, 2E3, this, [e])
                }
            },
            lz: function() {
                g.isUnloaded() || 1 == this.status || (r.logDebug(d.resolve(144)), this.status = 1)
            },
            kw: function(a) {
                -1 == this.status || this.Hg != a || this.Da() || (r.logDebug(d.resolve(145)), this.pa(!0))
            },
            Gx: function(a) {
                -1 == this.status || this.Hg != a || this.Da() || (r.logDebug(d.resolve(146)), this.status = 4)
            },
            disable: function() {
                this.status = -1;
                this.Hg++
            },
            Da: function() {
                return 1 === this.status
            },
            sr: function() {
                return -1 === this.status || 3 === this.status || 4 === this.status
            },
            CA: function(a, b, c, g) {
                if (this.sr()) return !1;
                if (1 !== this.status) return null;
                r.logDebug(d.resolve(147), a);
                var h;
                try {
                    h = !1 !== e.getFrameWindow(this.Va).sendRequest(a, b, c, g)
                } catch (f) {
                    h = !1, r.logDebug(d.resolve(148), f)
                }!1 === h && this.disable();
                return h
            }
        };
        h(n, l, !0, !0);
        return n
    });
    define("lscAL", "lscAI Inheritance lscy EnvironmentStatus Executor Environment LoggerManager lscAe".split(" "), function(d, f, b, a, c, g, e, p) {
        function k() {
            this._callSuperConstructor(k);
            this.error = this.response = this.kc = this.sender = this.K = null;
            this.i = !1;
            this.a = 0;
            this.LS_x = this.qz;
            this.Zc = null;
            this.V = k
        }
        var h = e.getLoggerProxy(p.cb);
        d.jc(k, {
            sa: function() {
                return g.isBrowserDocument() && (window.ActiveXObject || "undefined" != typeof XMLHttpRequest)
            },
            ua: !1,
            ta: !1,
            hc: !0,
            ic: !1,
            lc: !0
        });
        k.prototype = {
            toString: function() {
                return ["[|XHRConnection", this.i, this.a, this.K, "]"].join("|")
            },
            pa: function(a, c, g, d, f) {
                this.Zc = b.rw(a.Gb);
                if (this.Zc.sr()) return this.Zc.dismiss(), !1;
                if (!this.Zc.Da() || this.i) return null;
                this.Zc.touch();
                this.K = c;
                this.kc = null;
                this.response = g;
                this.error = d;
                this.Yp = f;
                this.a++;
                var k = this,
                    q = this.a;
                this.LS_h = function() {
                    k.ms(q)
                };
                this.i = !0;
                h.isDebugLogEnabled() && h.logDebug(e.resolve(150), a.getFile(), a.getData());
                return this.Zc.CA(a.zd(), a.getData(), this, a.lm)
            },
            ea: function() {
                if (this.i) {
                    this.Na();
                    h.logDebug(e.resolve(151));
                    try {
                        this.sender && this.sender.abort && this.sender.abort()
                    } catch (a) {
                        h.logError(e.resolve(149), a)
                    }
                    this.Ji()
                }
            },
            yf: function() {
                try {
                    if (null === this.kc) {
                        if (2 > this.sender.readyState) return !1;
                        this.kc = 200 <= this.sender.status && 299 >= this.sender.status
                    }
                    return this.kc
                } catch (a) {
                    return h.logDebug(e.resolve(152), a), !1
                }
            },
            ms: function(b) {
                a.isUnloaded() || b != this.a || !this.sender || 4 != this.sender.readyState && "complete" != this.sender.readyState || (b = null, this.yf() && (b = this.sender.responseText, b = b.toString(),
                    "/*" == b.substring(0, 2) && (b = b.substring(2, b.length - 2))), h.isDebugLogEnabled() && h.logDebug(e.resolve(153), b), this.response && c.executeTask(this.response, [b, this.K]), c.addTimedTask(this.Of, 100, this, [this.K]), this.Na(), this.Ji())
            },
            Of: function(a) {
                c.executeTask(this.Yp, [a])
            },
            qz: function() {
                a.isUnloaded() || (this.Zc.disable(), h.logDebug(e.resolve(154)), this.Na(), this.error && c.executeTask(this.error, ["xhr.unknown", this.K, !1, !1, !1]), this.Ji())
            },
            Ji: function() {
                try {
                    delete this.sender.onreadystatechange
                } catch (a) {
                    h.logDebug(e.resolve(155),
                        a)
                }
                try {
                    delete this.sender
                } catch (a) {
                    h.logDebug(e.resolve(156), a)
                }
                this.response = this.error = null;
                this.Zc && this.Zc.dismiss()
            },
            Na: function() {
                this.i = !1;
                this.a++
            }
        };
        f(k, d);
        return k
    });
    define("lscAM", "lscAI lscAL Inheritance EnvironmentStatus Executor BrowserDetection lscAJ Environment LoggerManager lscAe".split(" "), function(d, f, b, a, c, g, e, p, k, h) {
        function l() {
            this._callSuperConstructor(l);
            this.yb = null;
            this.V = l
        }
        var m = k.getLoggerProxy(h.cb),
            t = null;
        d.jc(l, {
            sa: function() {
                return null !== t ? t : t = p.isBrowserDocument() ? g.isProbablyIE() ? !1 : "undefined" != typeof XMLHttpRequest ? "undefined" != typeof(new XMLHttpRequest).addEventListener : !1 : !1
            },
            Bf: function() {
                return !g.isProbablyOldOpera()
            },
            ua: !1,
            ta: !1,
            hc: !0,
            ic: !1,
            lc: !0
        });
        l.prototype = {
            toString: function() {
                return ["[|XHRStreamingConnection", this.i, this.a, this.K, "]"].join("|")
            },
            pa: function(a, b, c, g, d) {
                a = this._callSuperMethod(l, this.ti, [a, b, c, g, d]);
                m.logDebug(k.resolve(157));
                a && (this.yb = new e);
                return a
            },
            ms: function(b) {
                !a.isUnloaded() && b == this.a && this.sender && (b = null, this.yf() && this.response && (3 == this.sender.readyState ? b = this.yb.no(this.sender.responseText) : 4 == this.sender.readyState && (b = this.yb.mo(this.sender.responseText)),
                    m.isDebugLogEnabled() && m.logDebug(k.resolve(158), b), null != b && c.executeTask(this.response, [b, this.K])), 4 == this.sender.readyState && (!this.yf() && this.response && c.executeTask(this.response, [null, this.K]), m.isDebugLogEnabled() && m.logDebug(k.resolve(159)), 4 != this.sender.readyState && "" != b || !this.Yp || c.addTimedTask(this.Of, 100, this, [this.K]), this.Na(), this.Ji()))
            }
        };
        b(l, f);
        return l
    });
    define("lscAg", ["Executor", "IFrameHandler", "Global", "BrowserDetection", "lscAj"], function(d, f, b, a, c) {
        function g(a) {
            this.mm = a;
            this.ready = !1;
            this.Zm = c.sc();
            this.mq = this.$i = !1;
            this.Lj = -1;
            this.pq = a = c.mk(this.Sq() + "_" + this.Zm);
            d.addTimedTask(this.gv, 3E3, this);
            var g = "about:blank";
            this.Oj() && (this.Lj = ++e, g = b.qa(this.Lj, "EQCallback_" + a, this.Ex(), "Q"), g = "javascript:(function(){document.open();" + ("document.domain\x3d'" + c.sc() + "';") + ("parent." + g + "(window);") + "document.close();})()");
            try {
                this.qc = f.getFrameWindow(a,
                    !0, g), this.Uy() ? d.addTimedTask(this.bm, 1, this) : this.Oj() || this.bm()
            } catch (h) {}
        }
        var e = 0;
        g.prototype = {
            Rq: function() {
                return null
            },
            verify: function() {
                return !0
            },
            G: function() {
                d.addTimedTask(f.disposeFrame, 0, f, [this.pq]);
                null !== this.Lj && b.Ii(this.Lj, "EQCallback_" + this.pq, "Q");
                this.mq = !0
            },
            og: function() {
                return this.$i || this.mq ? !1 : c.sc() == this.Zm ? !0 : this.fn() ? !1 : !0
            },
            Da: function() {
                return this.ready
            },
            bm: function() {
                var b = this.Rq();
                this.Oj() ? this.qc.document.write("\x3cscript\x3edocument.domain\x3d'" + this.Zm + "';\x3c/script\x3e") :
                    a.isProbablyOldOpera() && !b || this.qc.document.open();
                b && this.qc.document.write(b);
                this.Oj() || a.isProbablyOldOpera() && !b || this.qc.document.close();
                this.ready = this.verify()
            },
            Ex: function() {
                var a = this;
                return function(b) {
                    a.qc = b;
                    a.bm()
                }
            },
            Oj: function() {
                return a.isProbablyIE() && !c.rj()
            },
            fn: function() {
                return a.isProbablyIE() || a.isProbablyOldOpera() || a.isProbablyKonqueror(4.4, !0)
            },
            Uy: function() {
                return a.isProbablyKonqueror()
            },
            mu: function(a, b) {
                this.$i = !0;
                this.mm && (this.mm.Yb = [a, b], d.executeTask(this.mm))
            },
            gv: function() {
                this.ready ||
                    this.mu(5)
            }
        };
        return g
    });
    define("lscAG", "LoggerManager Executor lscAg Inheritance Dismissable lscAe Helpers".split(" "), function(d, f, b, a, c, g, e) {
        function p(a, b) {
            this.su = a;
            this._callSuperConstructor(p, [b]);
            this.Rg = null;
            this.initTouches()
        }

        function k(a, b, c) {
            try {
                a.appendChild(b), b.src = c
            } catch (e) {}
        }
        var h = d.getLoggerProxy(g.cb);
        p.prototype = {
            toString: function() {
                return "[JSONPFrame]"
            },
            Qu: function(a, b) {
                try {
                    var c = this.Cw();
                    if (!c) return c;
                    var e = this.qc.document.createElement("script");
                    e.id = a;
                    e.type = "text/javascript";
                    f.addTimedTask(k,
                        50, null, [c, e, b])
                } catch (g) {
                    return h.logDebug(d.resolve(160), g), !1
                }
                return !0
            },
            Fv: function(a) {
                var b = this.qc.document.getElementById(a);
                f.addTimedTask(function() {
                    b && b.parentNode && b.parentNode.removeChild(b)
                }, 4E3)
            },
            clean: function() {
                this.G()
            },
            Cw: function() {
                if (this.Rg) return this.Rg;
                this.Rg = this.qc.document.getElementsByTagName("BODY")[0];
                if (!this.Rg) {
                    if (this.rc) return 2E3 < e.getTimeStamp() - this.rc ? !1 : null;
                    this.rc = e.getTimeStamp();
                    return null
                }
                return this.Rg
            },
            Sq: function() {
                return "LS6__JF_" + this.su
            }
        };
        a(p, b);
        a(p, c, !0, !0);
        return p
    });
    define("lsce", ["lscg", "Inheritance"], function(d, f) {
        function b() {}
        b.prototype = {
            toString: function() {
                return "[JSONPEncoder]"
            }
        };
        f(b, d);
        return b
    });
    define("lscAF", "lscAI lscAA Inheritance Helpers Environment lscAG Executor LoggerManager lsce lscAe".split(" "), function(d, f, b, a, c, g, e, p, k, h) {
        function l(b) {
            this._callSuperConstructor(l);
            this.originalTarget = b;
            this.target = b + a.randomG();
            this.Kb = new g(this.target, e.packTask(this.Pr, this));
            this.Vi = 0;
            this.Pn = "script_" + a.randomG();
            this.rc = null;
            this.wp = !1;
            this.Bq = !0;
            this.V = l
        }
        var m, t;
        for (t in {
                qk: !0
            }) m = t;
        var n = p.getLoggerProxy(h.cb),
            r = /(^|&)LS_domain=[^&]*/,
            u = new k;
        d.jc(l, {
            sa: function() {
                return c.isBrowserDocument()
            },
            ua: !0,
            ta: !0,
            hc: !0,
            ic: !0,
            lc: !1
        });
        l.prototype = {
            toString: function() {
                return ["[|JSONPConnection", this.target, this.Pn, this.rc, "]"].join("|")
            },
            Pr: function() {
                this.wp = !0
            },
            qk: function(a, b, c, e, g, d) {
                (this.Bq || 10 == this.Vi) && a.Xi("LS_force_head\x3dtrue\x26");
                this.Bq = !1;
                var h = a.getData(),
                    h = h.replace(r, "");
                0 == h.indexOf("\x26") && (h = h.substring(1));
                a.setData(h);
                return this._callSuperMethod(l, m, [a, b, c, e, g, d])
            },
            pa: function(b, c, d, h) {
                this.ea();
                if (this.wp) return !1;
                if (!this.Kb.og() && this.Kb.fn() || 10 == this.Vi) this.Kb.G(), this.Vi = 0, this.target = this.originalTarget + a.randomG(), this.Kb = new g(this.target, e.packTask(this.Pr, this));
                if (!this.Kb.Da()) return null;
                this.Vi++;
                n.isDebugLogEnabled() && n.logDebug(p.resolve(161), b.getFile(), b.getData());
                var f = b.zd(),
                    k = b.getData(),
                    f = this.Kb.Qu(this.Pn, f + "?" + k);
                if (!f) return f;
                this.Kb.touch();
                this._callSuperMethod(l, this.ti, [b, c, d, h]);
                return !0
            },
            ea: function() {
                this.Kb.dismiss();
                if (this.Kb.og() || !this.Kb.fn()) {
                    n.logDebug(p.resolve(162));
                    try {
                        this.Kb.Fv(this.Pn)
                    } catch (a) {}
                }
            },
            yd: function() {
                return u
            }
        };
        b(l, f);
        return l
    });
    define("lscz", "LoggerManager lscAN lscAE lscAM lscAL lscAC lscAF lscAB lscAA lscAK lscAe".split(" "), function(d, f, b, a, c, g, e, p, k, h, l) {
        function m(a, b, c) {
            this.$m = a;
            this.Vu = b;
            this.Bp = c;
            this.bk = -1
        }

        function t() {
            return !1
        }
        var n = d.getLoggerProxy(l.cb);
        m.KC = function() {
            h.sa = t
        };
        m.LC = function() {
            f.sa = t;
            b.sa = t;
            a.sa = t;
            c.sa = t
        };
        m.JC = function() {
            p.sa = t;
            g.sa = t
        };
        m.$o = [];
        l = [f, b, a, g];
        for (var r = 0; r < l.length; r++) l[r].Bf() &&
            m.$o.push(l[r]);
        m.Qt = [f, b, c, e, p];
        m.wg = [f, b, c, e, g];
        m.dy = function(a) {
            return a.V === g
        };
        m.XC = function(a) {
            return a.V.prototype.$c != k.prototype.$c
        };
        m.xf = function(a, b, c, e, g, h, f) {
            n.isDebugLogEnabled() && n.logDebug(d.resolve(163), b.name || b.toString().match(u)[1]);
            if (!b.sa(a)) return n.logDebug(d.resolve(164)), !1;
            if (c && !b.ua()) return n.logDebug(d.resolve(165)), !1;
            if (e && !b.hc()) return n.logDebug(d.resolve(166)), !1;
            if (g && !b.ta()) return n.logDebug(d.resolve(167)), !1;
            if (h && !b.lc()) return n.logDebug(d.resolve(168)),
                !1;
            if (a = f) {
                a: {
                    for (a = 0; a < f.length; a++)
                        if (f[a] == b) {
                            f = !0;
                            break a
                        } f = !1
                }
                a = !f
            }
            if (a) return n.logDebug(d.resolve(169)), !1;
            n.isDebugLogEnabled() && n.logDebug(d.resolve(170), b.name || b.toString().match(u)[1]);
            return !0
        };
        m.prototype = {
            Gm: function() {
                return this.bk < this.$m.length - 1
            },
            br: function(a, c, e, g, h) {
                for (n.isDebugLogEnabled() && n.logDebug(d.resolve(171), "serverToUse", a, "isCrossSite", c, "areCookiesRequired", e, "isCrossProtocol", g, "hasExtraHeaders", h); this.Gm();) {
                    this.bk++;
                    var k = this.$m[this.bk];
                    if (!((this.Bp || this.Vu) &&
                            k === b || this.Bp && k === f) && this.xf(a, k, c, e, g, h)) return k
                }
                return null
            },
            xf: function(a, b, c, e, g, d) {
                return m.xf(a, b, c, e, g, d, this.$m)
            },
            Hc: function() {
                n.logDebug(d.resolve(172));
                this.bk = -1
            }
        };
        var u = /^function\s?([^\s(]*)/;
        return m
    });
    define("lscAD", ["lscAC", "BrowserDetection", "IFrameHandler", "Executor"], function(d, f, b, a) {
        function c() {
            this.Nj = !1
        }
        c.prototype = {
            bA: function(a) {
                (this.Nj = a === d) && b.getFrameWindow("LS6__HOURGLASS", !0)
            },
            KB: function() {
                a.addTimedTask(this.LB, 900, this)
            },
            LB: function() {
                if (this.Nj && (this.Nj = !1, !f.isProbablyAKhtml() && !f.isProbablyIE(6, !0) && !f.isProbablyIE(9, !1))) try {
                    window.open("about:blank", "LS6__HOURGLASS", null, !0)
                } catch (a) {}
            }
        };
        return c
    });
    define("lsct", "lscAe Inheritance lscr lscz lscAD lscAH lscAj lscq Executor LoggerManager BrowserDetection EnvironmentStatus lscAE lscAN".split(" "), function(d, f, b, a, c, g, e, p, k, h, l, m, t, n) {
        function r(a, b, c, e, g, d, h) {
            this._callSuperConstructor(r, arguments);
            this.Xe = this.Mj = this.nc = this.la = this.eq = null;
            this.fg(d)
        }

        function u(a) {
            a && a != z || (z++, v = 1)
        }
        var q = {
                Tg: "createSession",
                de: "bindSession",
                mg: "shutdown",
                Kg: "bindSent",
                ja: "onEvent",
                ia: "onErrorEvent"
            },
            q = e.getReverse(q),
            v = 1,
            z = 1,
            C = h.getLoggerProxy(d.gc);
        h.getLoggerProxy(d.Se);
        r.prototype = {
            fg: function(b) {
                b = b || !this.b.Li;
                this.eq = new a(a.wg, !1, b);
                this.nc = this.R ? new a(a.wg, !1, b) : new a(a.$o, !this.b.Io, b);
                this.la = null
            },
            Lq: function() {
                return this.R ? d.ec : d.Xd
            },
            Pq: function() {
                return this.R ? d.ec : d.xg
            },
            toString: function() {
                return ["[|SessionHTTP", "oid\x3d" + this.aa, this.R, this.le, this.a, this.wa, this.Ea, this.sg, this.sessionId, this.Jb, this.Cc, this.hd, "]"].join("|")
            },
            Tg: function(a, b) {
                if (!this._callSuperMethod(r, q.createSession,
                        [a, b])) return !1;
                this.Wl(this.wa, b, a);
                return !0
            },
            Wl: function(a, b, c) {
                if (a == this.wa) {
                    this.g.kq();
                    if (e.vr()) {
                        if (0 >= v) {
                            C.logDebug(h.resolve(175));
                            k.addTimedTask(this.Wl, 3E3, this, [a, c, "offline"]);
                            return
                        }
                        v--;
                        0 == v && k.addTimedTask(u, 2E4, null, [z])
                    }
                    a = this.km(c, this.Wl, b, !1);
                    null !== a && (a ? this.Mi() : !1 === a && (C.logWarn(h.resolve(174)), this.ia("no_impl_available", !0, !1, !1, !0)))
                }
            },
            de: function(a) {
                if (!this._callSuperMethod(r, q.bindSession, [a])) return !1;
                this.Xe && this.Xe.ea();
                this.fw();
                this.Ci(this.wa, a);
                return !0
            },
            fw: function() {
                if (!m.isLoaded() &&
                    (null === this.b.Ak && (l.isProbablyAndroidBrowser() || l.isProbablyApple()) || !0 === this.b.Ak)) {
                    var a = this.$e,
                        c = this;
                    m.addOnloadHandler(function() {
                        k.addTimedTask(function() {
                            a == c.$e && c.a == b.au && c.ej("spinfix")
                        }, c.b.ho)
                    })
                }
            },
            Ci: function(a, b) {
                if (a == this.wa) {
                    this.Mj || this.R || (this.Mj = new c);
                    var e = this.km(null, this.Ci, b, !1);
                    null !== e && (e ? this.Kg() : !1 !== e || this.R || this.Xb(this.I, "streaming.unavailable"))
                }
            },
            Hh: function() {
                this.ph();
                var a = this.km(null, this.Hh, "network.error", !0);
                null !== a && (a ? this.Mi() : !1 === a && (C.logError(h.resolve(173)),
                    this.ia("no_impl_available", !0, !1, !1, !0)))
            },
            mg: function(a) {
                this._callSuperMethod(r, q.shutdown, [a]);
                this.Xe && this.Xe.ea()
            },
            ij: function(a, c, e, h) {
                var f = this.a == b.Zk || this.a == b.Yk,
                    k = new g(this.Wa() + d.Uk);
                k.Rh(this.b.Tb());
                k.Th(this.b.ah(f));
                var q = !k.ta() && !k.ua();
                a = h ? p.hx(this.Ea, this.sessionId, this.b, c, this.Ab.kj(), q, this.Jb) : p.ex(this.Ea, this.sessionId, this.b, this.Ua, f, this.R, a, c, this.Ab.kj(), e, q);
                k.setData(a);
                return k
            },
            km: function(c, e, d, f) {
                var q = this.a == b.Zk || this.a == b.Yk,
                    l = !q,
                    v = this.ij(c, d, !0, f),
                    r = this.Wa();
                this.W.kl(null);
                this.la && this.la.V == t && (this.la = null);
                var m = q ? this.eq : this.nc;
                this.la && !m.xf(r, this.la.V, v.ua(), this.b.Tb(), v.ta(), this.b.mh(q)) && (m.Hc(), this.la = null);
                for (var u = !1, n = (this.R ? "LS6__POLLFRAME" : "LS6__PUSHFRAME") + "_" + this.Ca;
                    (this.la || m.Gm()) && !1 === u;) {
                    if (!this.la) {
                        u = m.br(r, v.ua(), this.b.Tb(), v.ta(), this.b.mh(q));
                        if (!u) return m.Hc(), !1;
                        this.la = new u(n)
                    }
                    v.uk(a.dy(this.la) && l ? g.fu : g.ri);
                    f ? v.Je(p.ix(this.la.yd().rf())) : v.Je(p.er(q, this.R, this.la.yd().rf()));
                    u = this.la.qk(v, this.Ea,
                        this.wl, this.vl, this.ul, this.Ca);
                    if (null === u) return C.logDebug(h.resolve(177)), k.addTimedTask(e, 50, this, [this.wa, d, c]), null;
                    !1 === u ? this.la = null : (C.logDebug(h.resolve(178)), m.Hc(), this.Xe = this.la)
                }
                return u
            },
            Kg: function() {
                this._callSuperMethod(r, q.bindSent);
                this.en() && this.Mj.bA(this.Xe.V)
            },
            en: function() {
                return !this.R
            },
            ia: function(a, b, c, e, g, d) {
                !e || this.la.V != n && this.la.V != t || this.g.oz(this.I);
                this._callSuperMethod(r, q.onErrorEvent, arguments)
            },
            ja: function() {
                this.a == b.So && u();
                !this.en() || this.a != b.Pt &&
                    this.a != b.So || this.Mj.KB();
                this._callSuperMethod(r, q.onEvent)
            },
            sm: function(a, b, c, e, g) {
                this.W.Jc(a, b, c, e, g)
            }
        };
        f(r, b);
        return r
    });
    define("lscu", "lscAe lscr lsct Inheritance lscAK lscz lscq Executor LoggerManager ASSERT lscAH lscAj".split(" "), function(d, f, b, a, c, g, e, p, k, h, l, m) {
        function t(a, b, c, e, g, d, h) {
            this._callSuperConstructor(t, arguments);
            this.U = null;
            this.cc = 1;
            this.Zf = null;
            this.mf = !1
        }
        var n = {
                Mi: "createSent",
                Ae: "onTimeout",
                jn: "onLoop",
                rn: "onStreamError",
                qn: "onStreamEnd",
                ia: "onErrorEvent",
                mg: "shutdown",
                Xb: "onSessionGivesUp",
                Vf: "onSessionBound"
            },
            n = m.getReverse(n),
            r = k.getLoggerProxy(d.gc);
        t.prototype = {
            toString: function() {
                return ["[|SessionWS", "oid\x3d" + this.aa, this.R, this.le, this.a, this.wa, this.Ea, this.cc, this.sg, this.sessionId, this.Jb, this.U, this.Cc, this.hd, "]"].join("|")
            },
            ge: function(a) {
                this.cc = a
            },
            Lq: function() {
                return this.R ? d.Zd : d.Bg
            },
            Pq: function() {
                return d.xg
            },
            vn: function() {
                h.verifyValue(this.cc, 1) || r.logError(k.resolve(179));
                this.Zf = this.Ea;
                this.U = new c(this);
                var a = this.Wa(),
                    b = new l(a + d.Uk);
                b.Rh(this.b.Tb());
                b.Th(this.b.ah(!1));
                if (g.xf(a, c, b.ua(), this.b.Tb(), b.ta(), this.b.mh(!1)) &&
                    (r.logDebug(k.resolve(186)), this.U.Qz(b, this.Zf, this.wl, this.vl, this.ul))) return this.W.kl(this.U), this.ge(2), !0;
                this.ge(5);
                return !1
            },
            Mi: function() {
                this._callSuperMethod(t, n.createSent);
                this.b.dm && !this.mf && this.vn()
            },
            Ci: function(a, b) {
                if (a == this.wa)
                    if (this.mf = !1, 1 == this.cc ? this.vn() : 2 != this.cc || this.U.Yx(this.Wa()) || (r.logWarn(k.resolve(184)), this.U.ea(), this.ge(1), this.vn()), 6 == this.cc) this.Xb(this.I, "ws.early.closed");
                    else if (5 == this.cc) this.Xb(this.I, "ws.notgood");
                else if (3 == this.cc) c.Qi(this.Wa()),
                    this.Xb(this.I, "ws.early.openfail");
                else {
                    var g = this.ij(null, b, !1, !1),
                        d = !1;
                    g.Je(e.er(!1, this.R, this.U.yd().rf()));
                    var f = !1;
                    2 == this.cc ? (d = this.U.qk(g, this.Ea, this.wl, this.vl, this.ul, this.Ca), f = !0) : 4 == this.cc ? d = this.U.Dg(g, this.Ea) : (h.fail(), r.logError(k.resolve(180), this));
                    null === d ? (r.logDebug(k.resolve(187)), p.addTimedTask(this.Ci, 50, this, [a, b])) : !1 === d ? (r.logWarn(k.resolve(185)), this.Xb(this.I, "ws.false")) : f || (r.logDebug(k.resolve(188)), this.Kg())
                }
            },
            ew: function(a) {
                this.Zf == a && (r.logDebug(k.resolve(189)),
                    this.Kg(), this.ge(4))
            },
            Ae: function(a, b, c, e, g) {
                b == this.wa && (this.a == f.Ud && (this.mf = !0), this._callSuperMethod(t, n.onTimeout, [a, b, c, e, g]))
            },
            jn: function(a) {
                this._callSuperMethod(t, n.onLoop, [a]);
                this.U && this.U.Et(this.Ea)
            },
            rn: function(a, b, c, e, g) {
                c ? b == this.Zf && this._callSuperMethod(t, n.onStreamError, [a, this.Ea, c, e, g]) : (this.a == f.Ud && (this.mf = !0), this._callSuperMethod(t, n.onStreamError, arguments))
            },
            qn: function(a, b) {
                b ? a == this.Zf && (this.a == f.Xt || this.a == f.Ud || this.a == f.Ro ? this.ia("ws.early.end", !1, !0) : (h.verifyDiffValue(this.a,
                    f.To) || r.logError(k.resolve(181), this), this._callSuperMethod(t, n.onStreamEnd, [this.Ea, b]))) : (this.a == f.Ud && (this.mf = !0), this._callSuperMethod(t, n.onStreamEnd, arguments))
            },
            ia: function(a, b, e, g, d, l) {
                e ? (h.verifyDiffValue(this.cc, 1) || r.logError(k.resolve(182), this), g ? this.ge(3) : this.ge(6), this.a == f.Xt || this.a == f.Ud || this.a == f.Ro ? r.logDebug(k.resolve(190), this) : this.a == f.To ? (r.logDebug(k.resolve(191), this), g && c.Qi(this.Wa()), this.Xb(this.I, "ws.error." + a)) : this.R && this.a == f.Yt ? (h.verifyNotOk(g) || r.logError(k.resolve(183),
                    this), r.logDebug(k.resolve(192), this), this.Ia(a, b, !1), this.Ae("zeroDelay", this.wa, 0, "ws.broken.wait")) : this._callSuperMethod(t, n.onErrorEvent, arguments)) : (this.a == f.Ud && (this.mf = !0), this._callSuperMethod(t, n.onErrorEvent, arguments))
            },
            mg: function(a) {
                this._callSuperMethod(t, n.shutdown, [a]);
                this.U && (this.Zf = null, this.U.ea(), this.U = null, this.W.kl(null));
                this.ge(1)
            },
            en: function() {
                return !1
            },
            Xb: function(a, b) {
                c.Qi(this.Wa());
                this._callSuperMethod(t, n.onSessionGivesUp, [a, b])
            },
            Vf: function() {
                this._callSuperMethod(t,
                    n.onSessionBound);
                this.U.TA(this.sessionId)
            },
            sm: function(a, b, c, e, g) {
                this.W.Ju(a, b, c, e, g)
            }
        };
        a(t, b);
        return t
    });
    define("lscv", ["LoggerManager", "Global", "Helpers", "ASSERT", "lscAe"], function(d, f, b, a, c) {
        function g(a) {
            this.gk = 0;
            this.Ma = null;
            this.oh = !1;
            this.b = a;
            this.c = null
        }
        var e = d.getLoggerProxy(c.Se),
            p = d.getLoggerProxy(c.gc);
        g.prototype = {
            toString: function() {
                return ["[", "lscv", this.Ma, this.gk, .5, 7E3, "]"].join("|")
            },
            fy: function(a) {
                return null != this.Ma && this.Ma > a
            },
            fe: function(a) {
                this.c = a
            },
            kj: function() {
                return null != this.Ma && 0 < this.Ma ? Math.round(this.Ma) : null
            },
            Rs: function() {
                this.Ma = null;
                this.oh = !1
            },
            dA: function() {
                this.oh = !1
            },
            YB: function(a) {
                this.zt(a)
            },
            TB: function(b) {
                a.verifyOk(this.c.xr()) || e.logError(d.resolve(193));
                this.c.qy() && (this.zt(1E3 * b) ? this.b.fo && this.c.Iz() : this.c.Oz())
            },
            HB: function(a) {
                a || this.Rs();
                this.gk = b.getTimeStamp()
            },
            zt: function(a) {
                var c = b.getTimeStamp();
                if (!this.gk) return !0;
                a = c - this.gk - a;
                if (null == this.Ma) return this.Ma = a, p.logDebug(d.resolve(196)), !1;
                if (2E4 < a && a > 2 * this.Ma && (this.oh = !this.oh)) return p.logInfo(d.resolve(194)), 7E3 < this.Ma;
                this.Ma = .5 * this.Ma + .5 * a;
                if (60 > this.Ma) return this.Ma =
                    0, p.logDebug(d.resolve(197)), !1;
                if (this.fy(7E3)) return p.logInfo(d.resolve(195)), !0;
                p.logDebug(d.resolve(198));
                return !1
            }
        };
        return g
    });
    define("lscH", ["LoggerManager", "lscG", "ASSERT", "lscAe"], function(d, f, b, a) {
        function c(a) {
            this.oa = [];
            this.keys = {};
            this.Ze = a;
            this.Oy = 0
        }
        var g = d.getLoggerProxy(a.Zo);
        c.prototype = {
            toString: function() {
                return ["[|ControlRequestBatch", this.Ze, this.oa.length, "]"].join("|")
            },
            il: function(a, b) {
                this.keys[a] = b;
                this.oa.push(a);
                (function() {
                    if (this.Ze == f.nd) {
                        var a = b.LS_sequence,
                            c = b.LS_msg_prog;
                        if (null != a && null != c)
                            for (var e = 0, m = this.oa.length - 1; e < m; e++) {
                                var t = this.oa[e],
                                    n = t.LS_msg_prog;
                                a ==
                                    t.LS_sequence && c == n && (g.isDebugLogEnabled() && g.logErrorExc(Error("backtrace"), "Duplicated message", "seq\x3d", a, "prog\x3d", c, "ptr\x3d", b === t), g.logError(d.resolve(199), "seq\x3d", a, "prog\x3d", c))
                            }
                    }
                })()
            },
            Ku: function(a, b) {
                this.keys[a] ? this.keys[a] = b : this.il(a, b)
            },
            Ye: function(a, c) {
                var k = a.Fg;
                if (k == f.nd || k == f.md || k == f.Wd) {
                    if (this.Ze != k) return b.fail(), g.logError(d.resolve(200), this), !1;
                    k == f.Wd ? this.Ku("H", a) : this.il(this.Oy++, a);
                    return !0
                }
                if (this.Ze != f.hi) return b.fail(), g.logError(d.resolve(201), this),
                    !1;
                var h;
                switch (k) {
                    case f.Rk:
                        h = "C";
                        break;
                    case f.Tk:
                        h = "F";
                        break;
                    case f.Po:
                        h = "X" + a.getKey();
                        break;
                    default:
                        h = a.getKey()
                }
                var l = this.keys[h];
                g.logDebug(d.resolve(205), this, h, a);
                if (l) {
                    if (k == f.Rk || k == f.Tk) {
                        c || (g.logDebug(d.resolve(206)), this.oo(h, a));
                        return
                    }
                    if (k == f.Xk) {
                        l.Ge ? (g.logDebug(d.resolve(207)), c || this.oo(h, a)) : l.Fg == f.Xk ? g.logDebug(d.resolve(208)) : (g.logDebug(d.resolve(209)), b.verifyNotOk(c) || g.logError(d.resolve(202), this), c || this.nA(h));
                        return
                    }
                    if (k == f.Vd) {
                        for (; l && a.Ge != l.Ge;) g.logDebug(d.resolve(210)),
                            h += "_", l = this.keys[h];
                        if (l) {
                            g.logDebug(d.resolve(211));
                            return
                        }
                    } else {
                        c || (g.logDebug(d.resolve(212)), this.oo(h, a));
                        return
                    }
                }
                g.logDebug(d.resolve(213));
                this.il(h, a)
            },
            getLength: function() {
                return this.oa.length
            },
            oo: function(a, b) {
                this.keys[a] = b
            },
            Kn: function(a) {
                if (this.oa.length <= a) return g.logError(d.resolve(203)), null;
                var b = this.oa[a];
                this.oa.splice(a, 1);
                a = this.keys[b];
                delete this.keys[b];
                return a
            },
            nA: function(a) {
                if (!this.keys[a]) return g.logError(d.resolve(204)), null;
                for (var b = 0; b < this.oa.length; b++)
                    if (this.oa[b] ==
                        a) return this.Kn(b)
            },
            shift: function() {
                return this.Kn(0)
            },
            pop: function() {
                return this.Kn(this.oa.length - 1)
            },
            Ff: function() {
                return this.Dm(this.oa.length - 1)
            },
            dh: function() {
                return this.Dm(0)
            },
            Dm: function(a) {
                return 0 >= this.oa.length ? null : this.keys[this.oa[a]]
            },
            pf: function() {
                return this.Ze
            }
        };
        return c
    });
    define("lscF", "lscG lscH LoggerManager lscAH Executor lscz lscAe ASSERT".split(" "), function(d, f, b, a, c, g, e, p) {
        function k() {
            this.a = this.request = this.Qc = this.Aa = null
        }

        function h(a, b, c, e) {
            this.Hm = this.Pi = this.Fj = this.Vl = this.bn = this.Ja = this.nc = null;
            this.Jh = this.Ad = this.Ib = 0;
            this.a = this.status = this.N = 1;
            this.fi = 0;
            this.s = null;
            this.bw = !1;
            this.Gc = a;
            this.b = b;
            this.jm = c;
            this.U = null;
            this.fg(e);
            this.Hc()
        }
        var l = b.getLoggerProxy(e.Zo),
            m = {
                1: "IDLE",
                2: "STAND BY",
                3: "WAITING RESP"
            };
        h.prototype = {
            toString: function() {
                return ["[|ControlConnectionHandler", m[this.status], this.s, this.Jh, this.Ib, "]"].join("|")
            },
            iB: function(a) {
                this.Jh = a;
                l.logDebug(b.resolve(236), this)
            },
            GB: function(a, c) {
                c ? (this.Ad = this.Ib = a, l.logInfo(b.resolve(222), this)) : 0 == this.Ad || a < this.Ad ? (this.Ib = a, l.logInfo(b.resolve(223), this)) : (this.Ib = this.Ad, l.logInfo(b.resolve(224), this));
                1 == this.status && this.bt(this.N)
            },
            bt: function(a) {
                1 == this.status && this.N == a && 0 != this.Ib && (l.logDebug(b.resolve(237), this),
                    this.Jc(null, "", d.Wd))
            },
            NB: function(a) {
                a ? (l.logInfo(b.resolve(225), this), this.Ad = this.Ib = 0) : 0 == this.Ad ? (l.logInfo(b.resolve(226), this), this.Ib = 0) : (l.logInfo(b.resolve(227), this), this.Ib = this.Ad)
            },
            fg: function(a) {
                this.nc = new g(g.Qt, !1, !this.b.Li || a);
                this.Ja = null
            },
            ea: function() {
                l.logDebug(b.resolve(238));
                this.Ja && this.Ja.ea()
            },
            fa: function(a) {
                this.N++;
                1 == a && 0 < this.Ib && c.addTimedTask(this.bt, this.Ib, this, [this.N]);
                l.isDebugLogEnabled() && l.logDebug(b.resolve(239) + m[this.status] + " -\x3e " + m[a]);
                this.status =
                    a
            },
            Hc: function() {
                l.logDebug(b.resolve(240), this);
                this.Jh = 0;
                this.bn = new f(d.nd);
                this.Vl = new f(d.hi);
                this.Hm = new f(d.Wd);
                this.U = null;
                this.Ad = this.Ib = 0;
                this.Fj || (this.Fj = new f(d.md));
                this.Pi || (this.Pi = new f(d.hi));
                this.ik = [this.bn, this.Vl, this.Fj, this.Pi, this.Hm];
                this.a++;
                var a = this.s ? this.s.pf() : null;
                null !== a && a !== d.Vd && a !== d.md ? (p.verifyDiffValue(this.status, 1) || l.logError(b.resolve(214)), this.ea(), this.s = null, this.fa(1, "_reset"), this.Pc(!1, "reset1")) : null === a && (p.verifyValue(this.status, 1) || l.logError(b.resolve(215)),
                    p.verifyValue(this.s, null) || l.logError(b.resolve(216)), this.Pc(!1, "reset2"))
            },
            kl: function(a) {
                a ? l.logDebug(b.resolve(241), this) : this.U && l.logDebug(b.resolve(242), this);
                this.U = a
            },
            Jc: function(a, b, e, g, d) {
                c.addTimedTask(this.sp, 0, this, [this.a, a, b, e, g, d])
            },
            Ju: function(a, b, c, e, g) {
                this.sp(this.a, a, b, c, e, g)
            },
            fv: function(a, b) {
                return b == d.Vd || b == d.md ? !0 : this.a === a
            },
            up: function(a, b) {
                a == d.nd ? this.bn.Ye(b) : a == d.md ? this.Fj.Ye(b) : a == d.Vd ? this.Pi.Ye(b) : a == d.Wd ? this.Hm.Ye(b) : this.Vl.Ye(b)
            },
            sp: function(a, c, e, g, h, f) {
                this.fv(a,
                    g) && (l.logInfo(b.resolve(228), this, e), a = new d(e, h, g, c, f), this.up(g, a), 1 == this.status ? this.Pc(!0, "add") : l.logDebug(b.resolve(243), this))
            },
            Pc: function(a, e) {
                !0 === a ? (l.logDebug(b.resolve(244), a, this), this.iq(this.N, e)) : c.addTimedTask(this.iq, !1 === a ? 0 : a, this, [this.N, "async." + e])
            },
            iq: function(a, c) {
                if (a == this.N) {
                    for (var e = 0; 1 > e;) {
                        e++;
                        this.fa(2, "dequeueControlRequests");
                        l.logDebug(b.resolve(245), c, this);
                        var g = null;
                        null != this.s ? (l.logDebug(b.resolve(246)), g = this.$s(this.s)) : (l.logDebug(b.resolve(247)), g = this.wA());
                        if (1 == g) l.logInfo(b.resolve(229)), this.s = null;
                        else {
                            if (2 == g) {
                                l.logInfo(b.resolve(230));
                                this.Pc(200, "later");
                                return
                            }
                            if (3 == g) {
                                l.logWarn(b.resolve(219));
                                this.s && this.s.hn(!0);
                                this.s = null;
                                this.Pc(!1, "no");
                                return
                            }
                            if (4 == g) {
                                l.logInfo(b.resolve(231));
                                this.fa(3, "dequeueControlRequests");
                                this.s && this.s.hn();
                                this.Pc(4E3, "http");
                                return
                            }
                            if (5 == g) l.logInfo(b.resolve(232)), this.fa(3, "dequeueControlRequests"), this.s && this.s.hn(), this.s = null, this.fa(1, "dequeueControlRequests");
                            else {
                                l.logInfo(b.resolve(233));
                                this.ea();
                                this.fa(1, "dequeueControlRequests");
                                return
                            }
                        }
                    }
                    this.Pc(!1, "limit")
                }
            },
            wA: function() {
                for (var a = 0; a < this.ik.length;) {
                    this.fi = this.fi < this.ik.length - 1 ? this.fi + 1 : 0;
                    if (0 < this.ik[this.fi].getLength()) return this.$s(this.ik[this.fi]);
                    a++
                }
                return null
            },
            $s: function(g) {
                if (g.Ze == d.nd)
                    for (var h = 0, f = g.oa.length; h < f; h++) {
                        var k = g.oa[h],
                            q = k.LS_sequence,
                            v = k.LS_msg_prog;
                        if (null != q && null != v)
                            for (var m = h + 1, C = g.oa.length; m < C; m++) {
                                var B = g.oa[m],
                                    w = B.LS_msg_prog;
                                q == B.LS_sequence && v == w && (l.isDebugLogEnabled() && l.logErrorExc(Error("backtrace"),
                                    "Duplicated message", "seq\x3d", q, "prog\x3d", v, "ptr\x3d", k === B), l.logError(b.resolve(217), "seq\x3d", q, "prog\x3d", v))
                            }
                    }
                h = this.Gc.Wa();
                f = this.b.Tb();
                k = this.b.ah(!1);
                (q = g.dh()) ? (q = new a((q.Ge && !0 !== q.Ge ? q.Ge : h) + e.Uk), q.Rh(f), q.Th(k), f = q) : f = null;
                if (null == f) return l.logDebug(b.resolve(248)), 1;
                l.logDebug(b.resolve(249));
                k = !1;
                if (this.U) {
                    l.logDebug(b.resolve(250));
                    k = this.fq(g, this.U);
                    if (null == k) return l.logDebug(b.resolve(251)), 1;
                    f.Je(k.getFile());
                    f.setData(k.getData());
                    k = this.U.Dg(f);
                    if (!1 === k) this.U = null;
                    else return null === k ? 2 : 5
                }
                this.Ja && !this.nc.xf(h, this.Ja.V, f.ua(), this.b.Tb(), f.ta(), this.b.mh(!1)) && (this.nc.Hc(), this.Ja = null);
                for (; this.Ja || this.nc.Gm();) {
                    if (!this.Ja) {
                        k = this.nc.br(h, f.ua(), this.b.Tb(), f.ta(), this.b.mh(!1));
                        if (!k) return l.logWarn(b.resolve(220), this.Ja), this.nc.Hc(), 3;
                        this.Ja = new k("LS6__CONTROLFRAME");
                        l.logDebug(b.resolve(252), this.Ja)
                    }
                    k = this.fq(g, this.Ja);
                    if (null == k) return l.logDebug(b.resolve(253)), 1;
                    f.Je(k.getFile());
                    f.setData(k.getData());
                    f.uk(k.We);
                    this.s.fB(this.N);
                    this.Ja.ea();
                    this.bw && (f.rb = f.rb.replace(/LS_session=.*&/g, "LS_session\x3dFAKE\x26"));
                    k = this.Ja.pa(f, this.s.a, c.packTask(this.Dz, this), c.packTask(this.ia, this));
                    if (!1 === k) l.logDebug(b.resolve(254)), this.Ja = null;
                    else {
                        if (null === k) return l.logDebug(b.resolve(255)), 2;
                        this.nc.Hc();
                        return 4
                    }
                }!1 !== k && (p.fail(), l.logError(b.resolve(218)));
                return 3
            },
            fq: function(a, b) {
                var c = b.yd();
                if (null == this.s) this.s = new k, this.s.it(c), this.s.fill(a, this.Jh, this.Gc.Qb(), this.b.Tb(), this.b.ah(!1));
                else if (this.s.Vy(c) && (this.s.it(c), c =
                        this.s.hA(this.Jh, this.Gc.Qb(), this.b.Tb(), this.b.ah(!1))))
                    for (var e = c.pf(); 0 < c.getLength();) this.up(e, c.shift());
                return this.s.isEmpty() ? this.s = null : this.s.request
            },
            Dz: function(a, c) {
                if (this.s && c == this.s.a) {
                    l.logInfo(b.resolve(234), c);
                    this.fa(1, "onReadyForNextRequest");
                    var e = this.s.dh().Fg;
                    this.s = null;
                    e == d.Vd || this.Zx(a) ? this.Pc(!1, "ready4next") : this.Gc.UB()
                }
            },
            Zx: function(a) {
                return "" === a ? !0 : null === a.match(/^window.LS_lastError\[\d+] = "sync error";$/m)
            },
            ia: function(a, c) {
                this.s && c == this.s.a && (l.logInfo(b.resolve(235),
                    this, a), this.fa(1, "onErrorEvent"), this.s = null, this.Pc(!1, "error"))
            }
        };
        k.prototype = {
            toString: function() {
                return this.Aa ? this.Aa.toString() : null
            },
            pf: function() {
                return this.Aa ? this.Aa.pf() : null
            },
            dh: function() {
                return this.Aa ? this.Aa.dh() : null
            },
            getLength: function() {
                return this.Aa ? this.Aa.getLength() : 0
            },
            shift: function() {
                return this.Aa ? this.Aa.shift() : null
            },
            Vy: function(a) {
                return a != this.Qc
            },
            it: function(a) {
                this.Qc = a
            },
            fill: function(a, c, e, g, d) {
                if (!(0 >= a.getLength()))
                    if (this.Aa = new f(a.pf()), this.request = this.Qc.Qx(a,
                            g, d), g = "", d = this.Qc.encode(a, e, !0), null === d) this.request = this.Aa = null;
                    else {
                        var h = this.Qc.xm(this.request.getFile()),
                            k = this.Qc.Am(d) + d.length;
                        0 < c && k + h > c && l.logWarn(b.resolve(221), g);
                        do g += d, this.Aa.Ye(a.shift()), h += k, 0 < a.getLength() && (d = this.Qc.encode(a, e)) && (k = this.Qc.Am(d) + d.length); while (d && (0 == c || h + k < c) && 0 < a.getLength());
                        this.request.setData(this.Qc.Ho(g))
                    }
            },
            hA: function(a, b, c, e) {
                var g = this.Aa;
                this.Aa = null;
                this.fill(g, a, b, c, e);
                return 0 < g.getLength() ? g : null
            },
            fB: function(a) {
                this.a = a
            },
            isEmpty: function() {
                return 0 >=
                    this.getLength()
            },
            hn: function(a) {
                for (var b = 0, e = null; e = this.Aa.Dm(b);)(e = e.jj()) && c.addTimedTask(e.$c, 0, e, [a]), b++
            }
        };
        return h
    });
    define("lscJ", ["Inheritance", "lscN", "lscAj"], function(d, f) {
        function b(a, c, d, f, h, l, m) {
            this._callSuperConstructor(b, [c]);
            this.Un = f;
            this.ad = h;
            this.nk = l;
            this.a = d;
            this.Gc = a;
            this.mC = m
        }
        var a, c;
        for (c in {
                $c: !0
            }) a = c;
        b.prototype = {
            $c: function(c) {
                this._callSuperMethod(b, a, [c]);
                c || (this.Gc.DA(this.nk, this.ad), this.mC || this.Gc.$y(this.nk, this.ad))
            },
            verifySuccess: function() {
                return this.Gc.ev(this.a) && this.Un.J[this.ad] && null != this.Un.J[this.ad].Fh ? !1 : !0
            },
            gf: function() {
                this.Gc.tA(this.ad, this)
            },
            uh: function() {}
        };
        d(b, f);
        return b
    });
    define("lscK", ["lscJ", "lscG", "LoggerManager", "lscAe"], function(d, f, b, a) {
        function c(a, b, c) {
            this.active = !1;
            this.Jj = 0;
            this.Jd = {};
            this.Pe = {};
            this.Ct = 0;
            this.W = a;
            this.da = b;
            this.cf = c
        }
        var g = b.getLoggerProxy(a.Wt);
        c.prototype = {
            ea: function() {
                this.active = !1;
                this.Jd = {};
                this.Ct = 0;
                this.Pe = {};
                this.Jj++;
                g.logDebug(b.resolve(262))
            },
            fl: function() {
                g.logDebug(b.resolve(263));
                if (!this.active) {
                    for (var a in this.Jd) {
                        var c = this.Jd[a],
                            f;
                        for (f in c.J) {
                            var h = c.J[f].Fh;
                            if (null != h) {
                                var l =
                                    new d(this, this.cf, this.Jj, c, f);
                                this.Tn(f, h, l)
                            }
                        }
                    }
                    this.active = !0
                }
            },
            Dg: function(c, f, k, h) {
                g.logDebug(b.resolve(264));
                var l = this.Jd[f];
                null == l && (l = {
                    Kf: 0,
                    J: {}
                }, this.Jd[f] = l);
                l.Kf++;
                c = {
                    LS_message: c
                };
                var m = !1;
                k && (c.LS_outcome = "", m = !0);
                f != a.Fc && (c.LS_sequence = encodeURIComponent(f), m = !0, h && (c.LS_max_wait = h));
                m && (c.LS_ack = "", c.LS_msg_prog = f == a.Fc ? this.Hy(l.Kf) : l.Kf);
                h = {};
                h.Fh = c;
                h.listener = k;
                l.J[l.Kf] = h;
                this.active && (g.logInfo(b.resolve(256), c), f = new d(this, this.cf, this.Jj, l, l.Kf, f, m), this.Tn(l.Kf, c, f))
            },
            Hy: function(a) {
                var b =
                    ++this.Ct;
                this.Pe[b] = a;
                return b
            },
            Kh: function(a) {
                return this.Pe[a] ? this.Pe[a] : a
            },
            kA: function(a) {
                for (var b in this.Pe)
                    if (this.Pe[b] == a) {
                        delete this.Pe[b];
                        break
                    }
            },
            ev: function(a) {
                return a == this.Jj
            },
            tA: function(a, c) {
                var d = c.Un.J[a].Fh;
                g.logDebug(b.resolve(265), d);
                this.Tn(a, d, c)
            },
            Tn: function(a, b, c) {
                this.W.Jc(a, b, f.nd, c)
            },
            Cu: function(c, d) {
                d = c == a.Fc ? this.Kh(d) : d;
                g.logInfo(b.resolve(257), c, d);
                var f = this.Jd[c];
                f.J[d] && (null != f.J[d].Fh && (g.logDebug(b.resolve(266)), f.J[d].Fh = null), null == f.J[d].listener && (g.logDebug(b.resolve(267)),
                    this.Ve(c, d)))
            },
            $y: function(a, c) {
                g.logDebug(b.resolve(268), a, c);
                this.Ve(a, c)
            },
            Ve: function(c, d) {
                g.logDebug(b.resolve(269));
                var f = this.Jd[c];
                f && f.J[d] && (delete f.J[d], c == a.Fc && this.kA(d))
            },
            vb: function(a, b) {
                var c = this.Jd[a];
                return c && c.J[b] && c.J[b].listener ? c.J[b].listener : null
            },
            DA: function(a, c) {
                g.logDebug(b.resolve(270), a, c);
                var d = this.vb(a, c);
                if (d) {
                    var h = this.da.tf(d.Fd);
                    h && h.hs(d.Eh)
                }
            },
            iu: function(c, d) {
                d = c == a.Fc ? this.Kh(d) : d;
                g.logInfo(b.resolve(258), c, d);
                var f = this.vb(c, d);
                if (f) {
                    var h = this.da.tf(f.Fd);
                    h && h.fs(f.Eh)
                }
                this.Ve(c, d)
            },
            bz: function(c, d) {
                d = c == a.Fc ? this.Kh(d) : d;
                g.logInfo(b.resolve(259), c, d);
                var f = this.vb(c, d);
                if (f) {
                    var h = this.da.tf(f.Fd);
                    h && h.ye(f.Eh)
                }
                this.Ve(c, d)
            },
            az: function(c, d, f, h) {
                h = c == a.Fc ? this.Kh(h) : h;
                g.logInfo(b.resolve(260), c, h);
                var l = this.vb(c, h);
                if (l) {
                    var m = this.da.tf(l.Fd);
                    m && m.gs(l.Eh, d, f)
                }
                this.Ve(c, h)
            },
            dz: function(c, d, f, h) {
                h = c == a.Fc ? this.Kh(h) : h;
                g.logInfo(b.resolve(261), c, h);
                var l = this.vb(c, h);
                if (l) {
                    var m = this.da.tf(l.Fd);
                    m && m.Tf(l.Eh, d, f)
                }
                this.Ve(c, h)
            }
        };
        return c
    });
    define("lscj", ["LoggerManager", "Executor", "Global", "ASSERT", "lscAe"], function(d, f, b, a, c) {
        function g(a) {
            this.jm = a;
            this.ub = [];
            this.kr = !1;
            this.lsc = {};
            this.lsc.LS_window = b["_" + a];
            this.lsc.window = this.lsc.LS_window;
            this.Ev = this.mw(this.lsc)
        }
        var e = d.getLoggerProxy(c.cb);
        g.prototype = {
            toString: function() {
                return "[EvalQueue|" + this.ub.length + "]"
            },
            mw: function() {
                eval("var lsc \x3d arguments[0]");
                return function(a) {
                    with(lsc) eval(a)
                }
            },
            gp: function(a, b) {
                this.og() && (this.ub.push({
                        p: a,
                        d: b
                    }), e.isDebugLogEnabled() &&
                    e.logDebug(d.resolve(272)), f.addTimedTask(this.Oi, 0, this))
            },
            fe: function(a) {
                this.c = a
            },
            Oi: function() {
                for (e.isDebugLogEnabled() && e.logDebug(d.resolve(273), this.ub.length); 0 < this.ub.length;) {
                    var b = this.ub.shift();
                    if (this.c && this.c.Nc(b.p)) try {
                        this.Ev(b.d)
                    } catch (c) {
                        this.kr = !0, this.ub = [], a.fail(), console.log(c), e.logError(d.resolve(271), c, b.d), this.c.sq()
                    } else e.isDebugLogEnabled() && e.logDebug(d.resolve(274), b.p, this.c)
                }
            },
            og: function() {
                return !this.kr
            },
            G: function() {}
        };
        return g
    });
    define("lsci", [], function() {
        function d(d) {
            this.lsc = {};
            this.lsc.LS_window = d;
            this.ready = !1
        }
        d.prototype = {
            Da: function() {
                return this.ready
            },
            Ew: function() {
                return this.lsc
            },
            Vv: function(d) {
                eval("var lsc \x3d this.lsc");
                with(lsc) eval(d);
                this.ready = !0
            }
        };
        return d
    });
    define("lscw", "LoggerManager Executor lscAg Inheritance Global lsci lscAe".split(" "), function(d, f, b, a, c, g, e) {
        function p(a, b) {
            this.jm = a;
            this._callSuperConstructor(p, [f.packTask(this.cs, this)]);
            this.ub = [];
            this.Ui = b ? b : new g(c["_" + a])
        }
        var k = d.getLoggerProxy(e.cb),
            h = 0;
        p.prototype = {
            toString: function() {
                return "[WrappedEvalQueue|" + this.ub.length + "]"
            },
            gp: function(a, b) {
                this.og() && (this.ub.push({
                    p: a,
                    d: b
                }), k.isDebugLogEnabled() && k.logDebug(d.resolve(276)), f.addTimedTask(this.Oi,
                    0, this))
            },
            Hq: function() {
                this.$i = !0
            },
            fe: function(a) {
                this.c = a
            },
            Rq: function() {
                return "\x3cscript\x3ewindow.evalProxy \x3d function(lsc,_p){with(lsc){eval(_p);}};\x3c/script\x3e"
            },
            verify: function() {
                return this.qc.evalProxy ? !0 : !1
            },
            Sq: function() {
                return "LS6__EQ_" + this.jm + "_" + ++h
            },
            Oi: function() {
                if (this.ready)
                    for (k.isDebugLogEnabled() && k.logDebug(d.resolve(277)); 0 < this.ub.length;) {
                        var a = this.ub.shift();
                        if (this.c && this.c.Nc(a.p)) {
                            var b = null,
                                c = null;
                            if (!this.Ui.Da() && (-1 < (b = a.d.indexOf("// END OF HEADER")) ||
                                    -1 < (c = a.d.indexOf("myEnv.LS_window \x3d LS_window;")))) {
                                var e; - 1 < b ? (e = a.d.substring(0, b), b = a.d.substring(b)) : (e = a.d.substring(0, c + 28), b = a.d.substring(c + 28));
                                a.d = b;
                                this.Ui.Vv(e)
                            }
                            try {
                                this.qc.evalProxy(this.Ui.Ew(), a.d)
                            } catch (g) {
                                this.cs(a.d, g);
                                break
                            }
                        }
                    } else f.addTimedTask(this.Oi, 100, this)
            },
            cs: function(a, b) {
                this.$i = !0;
                this.ub = [];
                k.logError(d.resolve(275), b, a);
                this.c && this.c.sq()
            }
        };
        a(p, b);
        return p
    });
    define("lscs", "Executor BrowserDetection ASSERT LoggerManager Helpers lscq lscl lscAK lsct lscu EnvironmentStatus Global lsco lscG lscAe lscv lscF lscK lscj lscw".split(" "), function(d, f, b, a, c, g, e, p, k, h, l, m, t, n, r, u, q, v, z, C) {
        function B(b, c) {
            this.aa = E++;
            A.isDebugLogEnabled() && A.logDebug(a.resolve(291) + this.aa);
            this.status = 1;
            this.N = 0;
            this.Il = this.c = null;
            this.me = "";
            this.va =
                b;
            this.da = c;
            this.b = b.sb;
            this.Ua = b.Fb;
            this.Ca = b.ne();
            this.Ab = new u(this.b, this.Ca);
            this.Vz = new t(this.Ca, c);
            l.addUnloadHandler(this);
            this.Xv();
            this.Yg = null;
            this.W = new q(this, b.sb, this.Ca, !1);
            this.Id = new v(this.W, this.da, this.b)
        }

        function w(a) {
            switch (a) {
                case 1:
                    return "No session";
                case 2:
                    return "WS Streaming";
                case 3:
                    return "prepare WS Streaming";
                case 4:
                    return "WS Polling";
                case 5:
                    return "prepare WS Polling";
                case 6:
                    return "HTTP Streaming";
                case 7:
                    return "prepare HTTP Streaming";
                case 8:
                    return "HTTP Polling";
                case 9:
                    return "prepare HTTP Polling";
                case 10:
                    return "Shutting down"
            }
        }
        var H = {
                2: 7,
                6: 9,
                4: 3,
                8: 3,
                _2: 3,
                _6: 9,
                _4: 3,
                _8: 7
            },
            D = {
                2: 7,
                6: 9,
                4: 3,
                8: 3,
                _2: 3,
                _6: 9,
                _4: 3,
                _8: 9
            },
            L = {
                2: 3,
                6: 7,
                4: 5,
                8: 9
            },
            y = {
                2: 5,
                6: 9,
                7: 9,
                9: 9
            },
            F = {
                3: !0,
                5: !0,
                7: !0,
                9: !0
            },
            x = a.getLoggerProxy(r.Se),
            A = a.getLoggerProxy(r.gc),
            E = 1;
        B.prototype = {
            Xv: function() {
                var a = this;
                m.qa(this.Ca, "LS_forceReload", function() {
                    a.c && a.c.ia("server.exit", !0)
                })
            },
            fa: function(b) {
                A.isDebugLogEnabled() && A.logDebug(a.resolve(292), w(this.status), "-\x3e", w(b));
                this.status = b;
                this.N++
            },
            Ia: function(a, b, c) {
                1 != this.status && 10 !=
                    this.status && this.c && this.c.Ia(a ? "api" : b, !1, c)
            },
            UB: function() {
                1 != this.status && 10 != this.status && this.c && this.c.Vj("control.syncerror")
            },
            Wx: function() {
                return 1 != this.status && 10 != this.status
            },
            Yu: function(a, b, c, e, g) {
                null != this.c && this.c.Bd() ? this.ff(a, b, c, e, g) : (this.status = e ? g ? 9 : 5 : g ? 7 : 3, this.c.Cc = !0)
            },
            ff: function(a, b, c, g, d, h, f) {
                a && e.Xc();
                this.kq();
                a = a ? "api" : h;
                this.me = b ? "_" : "";
                !f && this.Wx() ? (this.fa(g ? d ? 9 : 5 : d ? 7 : 3), this.ko(a), this.c.Ns(this.N, a, c)) : (this.Ps(), b = this.c ? this.c.Qb() : null, a = "new." + a, this.Ia(!1,
                    a, !1), this.fa(g ? d ? 8 : 4 : d ? 6 : 2), this.Gn(g, c, d), this.c.Tg(b, a))
            },
            Gn: function(a, b, c, e, g) {
                var d = null !== this.Yg;
                c = c ? k : h;
                g && (d = !1);
                this.c = new c(a, b, this, this.N, e, d, g);
                e && e.mg();
                this.Ab.fe(this.c);
                this.ga && this.ga.fe(this.c);
                this.Vz.fe(this.c)
            },
            de: function(a, b, c, e) {
                this.fa(b ? c ? 8 : 4 : c ? 6 : 2);
                this.Gn(b, a, c, this.c);
                this.c.de(e)
            },
            Hh: function(b, c, e) {
                A.logDebug(a.resolve(293), c);
                b != this.N ? A.logDebug(a.resolve(294)) : (c = L[this.status] || this.status, b = 3 == c || 7 == c ? !1 : !0, c = 3 == c || 5 == c ? !1 : !0, this.fa(b ? c ? 8 : 4 : c ? 6 : 2), this.Gn(b,
                    e, c, this.c, !0), this.c.Hh())
            },
            eo: function() {
                return "_" == this.me && L[this.status] == D[this.me + this.status]
            },
            Xb: function(c, e, g) {
                c == this.N && (g ? (A.logInfo(a.resolve(283)), this.fa(1)) : (c = D[this.status] || this.status, 7 == c && f.wr() && (c = 9), A.logInfo(a.resolve(284), w(this.status), w(c)), 1 == c || 10 == c ? (b.fail(), A.logError(a.resolve(278))) : (this.fa(c), this.ko(e), this.c.Ns(this.N, e, !1))))
            },
            Jz: function(c) {
                c == this.N && (c = y[this.status], A.logInfo(a.resolve(285), w(this.status), w(c)), c ? (this.fa(c), this.ko("slow"), this.c.sA(this.N)) :
                    (b.fail(), A.logError(a.resolve(279), w(this.status), this.c)))
            },
            ef: function(c, e, g) {
                c == this.N && (c = H[this.me + this.status] || this.status, A.logInfo(a.resolve(286), w(this.status), w(c)), 1 == c || 10 == c ? (b.fail(), A.logError(a.resolve(280))) : this.ff(!1, "_" == this.me, g, 3 == c || 7 == c ? !1 : !0, 3 == c || 5 == c ? !1 : !0, e, !0))
            },
            so: function(c, e, g) {
                c == this.N && (c = this.status, A.logInfo(a.resolve(287), w(this.status)), F[c] ? this.de(g, 3 == c || 7 == c ? !1 : !0, 3 == c || 5 == c ? !1 : !0, e) : (b.fail(), A.logError(a.resolve(281))))
            },
            vt: function(b) {
                A.logInfo(a.resolve(288));
                this.so(b, "slow", !1)
            },
            SB: function(c, e) {
                if (c == this.N) {
                    var g = this.status;
                    A.logInfo(a.resolve(289), w(this.status));
                    F[g] ? this.ff(!1, "_" == this.me, !1, 3 == g || 7 == g ? !1 : !0, 3 == g || 5 == g ? !1 : !0, "switch.timeout." + e, !0) : (b.fail(), A.logError(a.resolve(282)))
                }
            },
            ko: function(a) {
                d.addTimedTask(this.SB, this.b.ro + (this.Ab.kj() || 0), this, [this.N, a])
            },
            Ps: function() {
                this.W.Hc();
                this.Id.ea()
            },
            Tl: function() {
                var a = null !== this.Yg;
                this.c && this.c.fg(a);
                this.W && this.W.fg(a)
            },
            oz: function(a) {
                a == this.N && this.Tl()
            },
            kq: function() {
                null !==
                    this.Yg && 1E3 < c.getTimeStamp() - this.Yg && (this.Yg = null, this.Tl())
            },
            Pm: function() {
                return this.c ? this.c.i() || this.c.Za.Ya : null
            },
            zm: function() {
                return this.c ? this.c.zm() : r.Db
            },
            Wa: function() {
                return this.c ? this.c.Wa() : this.Ua.Oh
            },
            Qb: function() {
                return this.c ? this.c.Qb() : null
            },
            Mq: function() {
                if (!this.ga || !this.ga.og()) {
                    if (f.isProbablyIE(9, !0)) {
                        var a = null;
                        this.ga && (a = this.ga.Ui, this.ga.G());
                        this.ga = new C(this.Ca, a)
                    } else this.ga = new z(this.Ca);
                    this.ga.fe(this.c)
                }
                return this.ga
            },
            G: function() {
                this.ga && this.ga.G();
                l.removeUnloadHandler(this)
            },
            unloadEvent: function() {
                this.Ia(!1, "unload", !0);
                this.fa(10)
            },
            ne: function() {
                return this.Ca
            },
            IB: function(a) {
                a == this.N && this.va.ez()
            },
            cd: function(b) {
                A.logInfo(a.resolve(290), this.c);
                this.Vf(b);
                this.Id.fl();
                this.va.cd();
                this.lh(!1)
            },
            Vf: function(b) {
                A.logDebug(a.resolve(295), this.c);
                b && this.W.iB(b)
            },
            os: function(b, c) {
                if (b != this.N) return null;
                A.logDebug(a.resolve(296), this.c);
                this.Ps();
                this.va.ze();
                c ? this.fa(1) : this.fa(this.status);
                return this.N
            },
            tn: function(b, c) {
                var e = this.da.pe(b[0]);
                e ? (x.isDebugLogEnabled() && x.logDebug(a.resolve(298), b), e.xh(b, c)) : x.logDebug(a.resolve(297), this)
            },
            xe: function(b) {
                var c = this.da.pe(b[0]);
                c ? (x.isDebugLogEnabled() && x.logDebug(a.resolve(300), b), c.onLostUpdates(b[0], b[1], b[2])) : x.logDebug(a.resolve(299), this)
            },
            we: function(b) {
                var c = this.da.pe(b[0]);
                c ? (x.isDebugLogEnabled() && x.logDebug(a.resolve(302), b), c.onEndOfSnapshot(b[0], b[1])) : x.logDebug(a.resolve(301), this)
            },
            ve: function(b) {
                var c = this.da.pe(b[0]);
                c ? (x.isDebugLogEnabled() && x.logDebug(a.resolve(304),
                    b), c.onClearSnapshot(b[0], b[1])) : x.logDebug(a.resolve(303), this)
            },
            Uf: function(b, c) {
                x.isDebugLogEnabled() && x.logDebug(a.resolve(305), b, c);
                this.da.gz(b, c)
            },
            sn: function(b, c, e) {
                var g = this.da.pe(b);
                g ? (x.isDebugLogEnabled() && x.logDebug(a.resolve(306), b, c, e), g.Wf(b, c, e)) : x.logDebug(a.resolve(307), this);
                this.da.Wf(b)
            },
            onUnsubscription: function(b) {
                var c = this.da.pe(b);
                c ? (x.isDebugLogEnabled() && x.logDebug(a.resolve(308), b), c.onUnsubscription(b)) : x.logDebug(a.resolve(309), this);
                this.da.onUnsubscription(b)
            },
            Xf: function(b,
                c) {
                this.da.Xf(b, c);
                x.isDebugLogEnabled() && x.logDebug(a.resolve(310), b, c);
                this.da.Xf(b, c)
            },
            onSubscription: function(b, c, e, g, d) {
                this.da.onSubscription(b);
                var h = this.da.pe(b);
                h ? (x.isDebugLogEnabled() && x.logDebug(a.resolve(312), b, c, e, g, d), h.onSubscription(b, g, d, c, e)) : x.logDebug(a.resolve(311), this)
            },
            kn: function(b, c) {
                x.isDebugLogEnabled() && x.logDebug(a.resolve(313), b, c);
                this.Id.Cu(b, c)
            },
            nn: function(b, c) {
                x.isDebugLogEnabled() && x.logDebug(a.resolve(314), b, c);
                this.Id.iu(b, c)
            },
            ln: function(b, c, e, g) {
                x.isDebugLogEnabled() &&
                    x.logDebug(a.resolve(315), b, g, c, e);
                this.Id.az(b, c, g, e)
            },
            ye: function(b, c) {
                x.isDebugLogEnabled() && x.logDebug(a.resolve(316), b, c);
                this.Id.bz(b, c)
            },
            Tf: function(b, c, e, g) {
                x.isDebugLogEnabled() && x.logDebug(a.resolve(317), b, g, c, e);
                this.Id.dz(b, c, g, e)
            },
            Uj: function(a) {
                this.va.Uj(a)
            },
            on: function(b) {
                x.isDebugLogEnabled() && x.logDebug(a.resolve(318), b);
                this.va.on(b)
            },
            sz: function(a) {
                this.Il && a != this.Il && p.ay() && (p.Us(), this.ff(!1, "_" == this.me, !1, !1, !1, "ip", !1));
                this.Il = a
            },
            xc: function() {
                this.va.xc()
            },
            Sn: function(a,
                b, c, e) {
                this.Id.Dg(a, b, c, e)
            },
            Nh: function(a, b) {
                var c = g.Vw(this.N, a, b);
                this.W.Jc(null, c, n.md, null)
            },
            Fi: function() {
                this.c && this.c.Fi()
            },
            zA: function(a, b, c, e, g) {
                this.W.Jc(a, b, n.hi, g, e)
            },
            BA: function(a, b, c, e, g) {
                this.W.Jc(a, b, n.Xk, g, e)
            },
            AA: function(a, b, c) {
                this.W.Jc(a, b, n.Po, c)
            },
            lh: function(a) {
                this.c && this.c.lh(a)
            }
        };
        B.prototype.unloadEvent = B.prototype.unloadEvent;
        return B
    });
    define("lscm", ["lscY", "lscP", "Executor"], function(d, f, b) {
        function a(a, b) {
            this.o = a;
            this.id = b
        }
        var c = f.tt;
        f = {
            wh: c,
            Sf: c,
            onStatusChange: c,
            cd: c,
            ze: c,
            bs: c,
            Uf: c,
            xc: c,
            ping: f.ut,
            onSubscription: c,
            onUnsubscription: c,
            onEndOfSnapshot: c,
            xh: c,
            onLostUpdates: c,
            onClearSnapshot: c,
            Wf: c,
            ye: c,
            gs: c,
            Tf: c,
            fs: c,
            hs: c
        };
        a.methods = f;
        a.prototype = {
            sk: function(a) {
                this.target = a
            },
            Zr: function(a, b, c) {
                ("lscD" == a ? this.o.Fb : "lscE" == a ? this.o.sb : this.o.ka).X(b, c)
            },
            Dp: function(a) {
                a ==
                    this.o.Wc() && this.o.nq()
            },
            Ep: function(a) {
                a == this.o.Wc() && this.o.Lv()
            },
            ws: function() {
                if (null === this.o) throw "net";
                return !0
            },
            Up: function() {
                b.addTimedTask(this.o.Mp, 0, this.o);
                b.addTimedTask(this.o.Mp, 1E3, this.o)
            },
            Me: function(a, b) {
                return a != this.o.Wc() ? null : this.o.subscribe(this.id, b)
            },
            Qd: function(a, b) {
                return a != this.o.Wc() ? null : this.o.unsubscribe(b)
            },
            ld: function(a, b, c) {
                return a != this.o.Wc() ? null : this.o.ld(b, c)
            },
            eh: function(a, b, c, g, d) {
                if (a != this.o.Wc()) return null;
                this.o.Sn(b, c, null == g ? null : {
                        Eh: g,
                        Fd: this.id
                    },
                    d)
            },
            Gq: function(a) {
                this.o.Nh(a)
            },
            G: function() {
                this.o = null
            }
        };
        for (var g in f) a.prototype[g] = d.Sg(g, f[g]);
        return a
    });
    define("lsck", "Global lscAe LoggerManager lscC lscD lscE lscp lscs lscG Executor lscm Helpers".split(" "), function(d, f, b, a, c, g, e, p, k, h, l, m) {
        function t(b, k, l, r, m, t) {
            this.ka = new a(b);
            this.ka.lg(this, !0);
            this.Fb = new c(l);
            this.Fb.lg(this, !0);
            this.sb = new g(k);
            this.sb.lg(this, !0);
            this.Um = null;
            this.M = new e(this, this.ka, this.Fb, this.sb);
            if (r && r.xj()) this.Bc = r.wv(this, h.packTask(this.G, this), t), b = this.Bc.jj(),
                null != b && (this.zl = r.vv(this, b), this.zl.addListener(this.M)), this.id = this.Bc.ha();
            else {
                this.Bc = null;
                do this.id = "NS" + n++; while (d.sj(this.id, "lsEngine"))
            }
            d.qa(this.id, "lsEngine", this);
            this.f = new p(this, this.M);
            this.Ap(m, f.Wo);
            this.ka.Qg && this.nq()
        }
        var n = m.randomG(),
            r = "1777";
        isNaN(r) && (r = 0);
        var u = b.getLoggerProxy(f.gc);
        t.prototype = {
            toString: function() {
                return "[LightstreamerEngine " + this.id + "]"
            },
            Ap: function(a, b) {
                b || (b = "LOCAL" + n++);
                var c = new l(this, b);
                c.sk(a);
                a.gB(c);
                this.M.js(b, c)
            },
            ne: function() {
                return this.id
            },
            Pm: function() {
                return this.f.Pm()
            },
            Wc: function() {
                return this.M.Wc()
            },
            ze: function() {
                this.M.ze()
            },
            cd: function() {
                this.M.cd()
            },
            G: function() {
                this.f.Ia(!1, "suicide", !0);
                this.f.G();
                d.hv(this.id);
                this.Bc && this.Bc.G();
                this.M.Ur(!0);
                this.M.G();
                this.zl && this.zl.G()
            },
            Lv: function() {
                u.logInfo(b.resolve(319));
                this.ka.X("connectionRequested", !1);
                this.f.Ia(!0, "api", !0)
            },
            Jv: function() {
                var a = this.sb.fj;
                u.logInfo(b.resolve(320), a);
                if (null === a) var c = !0,
                    g = !1,
                    e = !1,
                    d = !1,
                    a = !1;
                else c = !0, g = a == f.pi || a == f.Qe, e = !g, d = a == f.Zd || a ==
                    f.ec, a = a == f.ec || a == f.Xd || a == f.Qe;
                this.f.Yu(c, g, e, d, a)
            },
            nq: function() {
                u.logInfo(b.resolve(321));
                this.ka.X("connectionRequested", !0);
                var a = this.sb.fj;
                null === a ? this.f.ff(!0, !1, !1, !1, !1) : this.Kv(a)
            },
            Kv: function(a) {
                var b = a == f.pi || a == f.Qe;
                this.f.ff(!0, b, !b, a == f.Zd || a == f.ec, a == f.ec || a == f.Xd || a == f.Qe)
            },
            af: function(a, b, c) {
                this.M.wd(function(g) {
                    g.wh(a, b, c)
                });
                "maxBandwidth" == b ? this.f.Fi(c) : "forcedTransport" == b ? this.ka.Qg && this.Jv() : "reverseHeartbeatInterval" == b ? this.f.lh(!1) : "corsXHREnabled" != b && "xDomainStreamingEnabled" !=
                    b || this.f.Tl();
                return !0
            },
            Uj: function(a) {
                this.Bc && this.Bc.Is(a)
            },
            on: function(a) {
                this.Bc && this.Bc.Eu(a)
            },
            Rb: function() {
                return this.f.zm()
            },
            ez: function() {
                var a = this.Rb();
                if (this.Um != a) {
                    var b = this.Um;
                    this.Um = a;
                    this.M.fz(a, b);
                    if (this.onStatusChange) this.onStatusChange(a)
                }
            },
            Sn: function(a, b, c, g) {
                var e = this.Rb();
                if (e == f.Db || e == f.Ag) return !1;
                this.f.Sn(a, b, c, g);
                return !0
            },
            Nh: function(a) {
                this.f.Nh(a, r);
                return !0
            },
            subscribe: function(a, b) {
                return this.M.Kx(a, b)
            },
            unsubscribe: function(a) {
                this.M.Ks(a)
            },
            ld: function(a,
                b) {
                this.M.ld(a, b)
            },
            Mp: function() {
                this.M.Sp()
            },
            xc: function() {
                this.M.xc()
            }
        };
        return t
    });
    define("lscAX", ["lscAe"], function(d) {
        function f(b, a, c) {
            this.id = b;
            this.w = a;
            this.status = c
        }
        f.prototype = {
            Rb: function() {
                return this.status
            }
        };
        return {
            eg: function(b, a) {
                return this.In(a + "_" + b)
            },
            pC: function(b, a, c) {
                c = c.join("|");
                this.write(d.Yd + a + "_" + b, c)
            },
            Gl: function(b, a) {
                this.clean(d.Yd + a + "_" + b)
            },
            Jn: function(b) {
                return this.In(b)
            },
            fA: function(b) {
                b = this.In(b);
                if (!b) return null;
                for (var a = [], c = 0; c < b.length; c++) {
                    var g = b[c].split("_");
                    if (2 == g.length) {
                        var e = this.eg(g[1], g[0]);
                        null != e && a.push(new f(g[0],
                            g[1], e))
                    }
                }
                return a
            },
            gl: function(b, a, c) {
                b = d.Yd + b;
                a += c ? "_" + c : "";
                c = this.read(b);
                if (!c) c = "|";
                else if (-1 < c.indexOf("|" + a + "|")) return !1;
                this.write(b, c + (a + "|"));
                return !0
            },
            Ih: function(b, a, c) {
                b = d.Yd + b;
                a += c ? "_" + c : "";
                if (c = this.read(b)) a = "|" + a + "|", -1 < c.indexOf(a) && (c = c.replace(a, "|"), "|" == c ? this.clean(b) : this.write(b, c))
            },
            sw: function() {
                for (var b = this.keys(), a = [], c = 0; c < b.length; c++) 0 == b[c].indexOf(d.Yd) && (b[c] = b[c].substring(d.Yd.length), a.push(b[c]));
                return a
            },
            In: function(b) {
                b = d.Yd + b;
                b = this.read(b);
                if (!b) return null;
                b = b.split("|");
                "" == b[0] && b.shift();
                "" == b[b.length - 1] && b.pop();
                return 0 < b.length ? b : null
            }
        }
    });
    define("lscAY", ["lscAj", "lscAX"], function(d, f) {
        return d.ra({
            read: function(b) {
                return localStorage.getItem(b)
            },
            write: function(b, a) {
                localStorage.setItem(b, a)
            },
            clean: function(b) {
                localStorage.removeItem(b)
            },
            keys: function() {
                for (var b = [], a = 0; a < localStorage.length; a++) b.push(localStorage.key(a));
                return b
            }
        }, f)
    });
    define("CookieManager", ["Helpers", "Environment"], function(d, f) {
        var b = !1,
            a = {
                areCookiesEnabled: function() {
                    return b
                },
                getAllCookiesAsSingleString: function() {
                    return this.areCookiesEnabled() ? document.cookie.toString() : null
                },
                writeCookie: function(a, b) {
                    this.Lt(a, b, "")
                },
                Lt: function(a, b, e) {
                    this.areCookiesEnabled() && (document.cookie = encodeURIComponent(a) + "\x3d" + b + "; " + e + "path\x3d/;")
                },
                readCookie: function(a) {
                    if (!this.areCookiesEnabled()) return null;
                    a = encodeURIComponent(a) + "\x3d";
                    for (var b = this.getAllCookiesAsSingleString(),
                            b = b.split(";"), e = 0; e < b.length; e++)
                        if (b[e] = d.trim(b[e]), 0 == b[e].indexOf(a)) return b[e].substring(a.length, b[e].length);
                    return null
                },
                removeCookie: function(a) {
                    if (this.areCookiesEnabled()) {
                        var b = new Date;
                        b.setTime(b.getTime() - 864E5);
                        this.Lt(a, "deleting", "expires\x3d" + b.toUTCString() + "; ")
                    }
                },
                cv: function() {
                    if (f.isBrowserDocument() && ("http:" == document.location.protocol || "https:" == document.location.protocol)) {
                        b = !0;
                        var a = "LS__cookie_test" + d.randomG();
                        this.writeCookie(a, "testing");
                        var g = this.readCookie(a);
                        if ("testing" == g && (this.removeCookie(a), g = this.readCookie(a), null == g)) return;
                        b = !1
                    }
                }
            };
        a.cv();
        a.areCookiesEnabled = a.areCookiesEnabled;
        a.getAllCookiesAsSingleString = a.getAllCookiesAsSingleString;
        a.writeCookie = a.writeCookie;
        a.removeCookie = a.removeCookie;
        a.readCookie = a.readCookie;
        return a
    });
    define("lscAV", ["CookieManager", "lscAX", "lscAj", "Helpers"], function(d, f, b, a) {
        return b.ra({
            read: function(a) {
                return d.readCookie(a)
            },
            write: function(a, b) {
                d.writeCookie(a, b)
            },
            clean: function(a) {
                d.removeCookie(a)
            },
            keys: function() {
                for (var b = [], b = d.getAllCookiesAsSingleString().split(";"), g = 0; g < b.length; g++) b[g] = a.trim(b[g]), b[g] = b[g].substring(0, b[g].indexOf("\x3d")), b[g] = decodeURIComponent(b[g]);
                return b
            }
        }, f)
    });
    define("lscAU", "lscAY lscAV Executor Dismissable Inheritance lscAe Helpers lscAj".split(" "), function(d, f, b, a, c, g, e, p) {
        function k(a) {
            this._callSuperConstructor(k);
            this.ca = a;
            this.Fk = null
        }
        var h = [],
            l = g.Te + g.Yo,
            m = 6E4;
        k.prototype = {
            start: function() {
                this.Fk && b.stopRepetitiveTask(this.Fk);
                this.Fk = b.addRepetitiveTask(this.Wp, m, this);
                b.addTimedTask(this.Wp, 0, this)
            },
            clean: function() {
                b.stopRepetitiveTask(this.Fk);
                for (var a = 0; a < h.length; a++)
                    if (h[a] == this) {
                        h.splice(a, 1);
                        break
                    }
            },
            Wp: function() {
                for (var a = e.getTimeStamp(), b = this.ca.sw(), c = 0; c < b.length; c++) 0 < b[c].indexOf("_") && this.Cl(b[c], null, a);
                for (c = 0; c < b.length; c++) - 1 >= b[c].indexOf("_") && this.dv(b[c])
            },
            Cl: function(a, b, c) {
                if (!b) {
                    b = a.split("_");
                    if (2 != b.length) return !1;
                    a = b[0];
                    b = b[1]
                }
                var e = this.ca.eg(b, a);
                return e ? c ? c - e[g.ni] > l ? (this.ca.Gl(b, a), !1) : !0 : !0 : !1
            },
            dv: function(a) {
                for (var b = this.ca.Jn(a), c = 0; c < b.length; c++) 0 < b[c].indexOf("_") ? this.Cl(b[c]) || this.ca.Ih(a, b[c]) : this.Cl(b[c], a) || this.ca.Ih(a, b[c])
            }
        };
        c(k, a, !1, !0);
        d = new k(d);
        var t = new k(f),
            n = p.Ip() ? d : t;
        return {
            start: function(a) {
                a = a ? t : n;
                for (var b = 0; b < h.length; b++)
                    if (h[b] == a) {
                        a.touch();
                        return
                    } h.push(a);
                a.touch();
                a.start()
            },
            stop: function(a) {
                a = a ? t : n;
                for (var b = 0; b < h.length; b++) h[b] == a && a.dismiss()
            },
            IC: function(a) {
                m = a;
                for (a = 0; a < h.length; a++) h[a].start()
            }
        }
    });
    define("lscAR", ["lscAj", "lscAX"], function(d, f) {
        var b = {};
        return d.ra({
            read: function(a) {
                return b[a]
            },
            write: function(a, c) {
                b[a] = c
            },
            clean: function(a) {
                delete b[a]
            },
            keys: function() {
                var a = [],
                    c;
                for (c in b) a.push(c);
                return a
            }
        }, f)
    });
    define("lscX", ["Environment"], function(d) {
        return {
            Gp: function() {
                return d.isBrowserDocument() && "undefined" !== typeof SharedWorker && "undefined" !== typeof Blob && window.URL
            },
            yv: function(d) {
                return window.URL.createObjectURL(new Blob([d]))
            },
            qA: function(d) {
                window.URL.revokeObjectURL(d)
            }
        }
    });
    define("lscW", "Executor EventDispatcher Inheritance LoggerManager lscAe Promise".split(" "), function(d, f, b, a, c, g) {
        function e() {
            this._callSuperConstructor(e);
            this.$b = this.Td = null
        }
        var p = c.mi,
            k = a.getLoggerProxy(c.Eb);
        e.eu = 'var listeners\x3d{},nextId\x3d0,MASTER\x3d"MASTER",REMOTE\x3d"REMOTE",INITIALIZATION\x3d"INITIALIZATION",REMOVE\x3d"REMOVE",ALL\x3d"ALL",FAILED\x3d"FAILED",KILL\x3d"KILL";onconnect\x3dfunction(a){var b\x3da.ports[0];a\x3dnextId++;listeners[MASTER]||(a\x3dMASTER);listeners[a]\x3db;b.addEventListener("message",function(a){a\x3da.data;if(a.type\x3d\x3dREMOVE)delete listeners[a.target];else if(a.type\x3d\x3dKILL)terminate();else if(a.target\x3d\x3d\x3dALL)for(var c in listeners)listeners[c]!\x3db\x26\x26sendMessage(c,a,b);else sendMessage(a.target,a,b)});b.start();b.postMessage({type:INITIALIZATION,id:a});a!\x3d\x3dMASTER\x26\x26listeners[MASTER].postMessage({type:REMOTE,id:a})};function sendMessage(a,b,d){(a\x3dlisteners[a])?a.postMessage(b):(b.type\x3dFAILED,d.postMessage(b))}function terminate(){self.close();for(var a in listeners)listeners[a].close()};';
        e.prototype = {
            Da: function() {
                return null !== this.$b
            },
            start: function(b) {
                var c = new SharedWorker(b);
                b = new g(function(b, g) {
                    c.onerror = function() {
                        k.logInfo(a.resolve(322));
                        g("SharedWorker broken")
                    }
                });
                this.Td = c.port;
                var e = this;
                this.Td.onmessage = function(a) {
                    e.Tj(a.data)
                };
                this.Td.start();
                return b
            },
            G: function() {
                try {
                    this.$b == p && this.Td.postMessage({
                        type: "KILL"
                    }), this.Td.close()
                } catch (a) {}
                this.Td = null
            },
            Tj: function(a) {
                if (k.isDebugLogEnabled()) {
                    var b = "RECEIVED",
                        c;
                    for (c in a) b += " " + c.toString() + ":" + a[c];
                    k.logDebug(b)
                }
                "INITIALIZATION" ==
                a.type ? (this.$b = a.id, this.dispatchEvent("onReady")) : "REMOTE" == a.type ? this.dispatchEvent("onRemote", [a.id]) : "FAILED" == a.type ? this.dispatchEvent("onMessageFail", [a.target, a.an]) : this.dispatchEvent("onMessage", [a])
            },
            Ls: function(a) {
                a || (a = this.$b);
                try {
                    this.Td.postMessage({
                        type: "REMOVE",
                        target: a
                    })
                } catch (b) {}
            },
            sendMessage: function(a, b, c, g) {
                if (!this.Da()) return !1;
                b = {
                    type: b,
                    sender: this.$b,
                    target: a,
                    an: c,
                    Yb: g
                };
                if (k.isDebugLogEnabled()) {
                    g = "SENDING";
                    for (var e in b) g += " " + e.toString() + ":" + b[e];
                    k.logDebug(g)
                }
                try {
                    this.Td.postMessage(b)
                } catch (d) {
                    this.dispatchEvent("onMessageFail",
                        [a, c])
                }
                return !0
            }
        };
        b(e, f);
        return e
    });
    define("lscT", "Executor EventDispatcher Inheritance LoggerManager lscAj lscAe".split(" "), function(d, f, b, a, c, g) {
        function e() {
            this._callSuperConstructor(e);
            this.he = {};
            this.$b = null;
            this.Tz = 1
        }
        var p = a.getLoggerProxy(g.Eb),
            k = g.mi;
        e.prototype = {
            Da: function() {
                return null !== this.$b
            },
            start: function(b) {
                this.ready = !0;
                if (b) {
                    this.he[k] = b;
                    var c = this;
                    d.addTimedTask(function() {
                        try {
                            b.connect(c)
                        } catch (g) {
                            -2147467260 != g.Wr && p.logError(a.resolve(326), g)
                        }
                    }, 0)
                } else this.$b = k, this.dispatchEvent("onReady")
            },
            G: function() {},
            connect: function(a) {
                d.addTimedTask(this.ju, 0, this, [a])
            },
            ju: function(a) {
                var b = this.Tz++;
                this.he[b] = a;
                this.dispatchEvent("onRemote", [b]);
                this.sendMessage(b, "INITIALIZATION", -1, [b])
            },
            Ls: function(a) {
                delete this.he[a]
            },
            sendMessage: function(a, b, c, g) {
                if (!this.Da()) return !1;
                if ("ALL" == a)
                    for (var e in this.he) this.lp(e, b, c, g);
                else this.lp(a, b, c, g);
                return !0
            },
            lp: function(b, c, g, e) {
                try {
                    if (this.he[b] && this.he[b].Tj) {
                        var f = this;
                        d.addTimedTask(function() {
                            try {
                                f.he[b].Tj(b, f.$b, c, g, e)
                            } catch (d) {
                                -2147467260 !=
                                    d.Wr && (p.logError(a.resolve(327), d), f.dispatchEvent("onMessageFail", [b, g]))
                            }
                        }, 0)
                    } else this.dispatchEvent("onMessageFail", [b, g])
                } catch (k) {
                    this.dispatchEvent("onMessageFail", [b, g])
                }
            },
            Tj: function(a, b, g, e, d) {
                a = {
                    target: c.oc(a),
                    type: c.oc(g),
                    an: c.oc(e),
                    sender: c.oc(b)
                };
                if (d)
                    for (a.Yb = [], b = 0; b < d.length; b++) a.Yb[b] = c.oc(d[b]);
                this.uu(a)
            },
            uu: function(b) {
                try {
                    "INITIALIZATION" == b.type ? (this.$b = b.Yb[0], this.dispatchEvent("onReady")) : this.dispatchEvent("onMessage", [b])
                } catch (c) {
                    -2147467260 != c.Wr && p.logError(a.resolve(328),
                        c)
                }
            }
        };
        b(e, f, !1, !0);
        return e
    });
    define("lscAW", "Global Executor lscAe lscAU lscAY lscAV lscAR Helpers EnvironmentStatus IFrameHandler LoggerManager lscAj lscX lscW lscT".split(" "), function(d, f, b, a, c, g, e, p, k, h, l, m, t, n, r) {
        function u(a, b) {
            this.w = a;
            this.o = b;
            this.L = this.id = null;
            this.ca = e
        }
        var q = l.getLoggerProxy(b.Eb),
            v = m.Ip() ? c : g,
            z = p.randomG(),
            C = b.ni;
        u.$q = function() {
            return v
        };
        u.prototype = {
            toString: function() {
                return ["[SharedStatus", this.id,
                    this.w, "]"
                ].join("|")
            },
            jj: function() {
                return this.L
            },
            Eg: function() {
                this.Ys = !0;
                k.addBeforeUnloadHandler(this);
                k.addUnloadHandler(this)
            },
            zB: function(c, e, d, f) {
                if (this.Ys) return !1;
                this.Ov = e || {};
                this.Bj = null;
                this.yk = 500;
                this.po = c;
                this.ie = null;
                this.host = location.host;
                this.Lg = this.Va = b.fc;
                this.Dn = !1;
                this.Cq = 0;
                d ? (this.ca = g, a.start(!0)) : (this.ca = v, a.start());
                this.iw = d;
                this.vo = this.Ck = null;
                this.si();
                this.mp();
                this.L = null;
                f || !t.Gp() ? this.Va = this.Iq() : this.Lg = this.ow();
                this.th = {};
                q.logInfo(l.resolve(331));
                this.Eg();
                return !0
            },
            AB: function() {
                if (this.Ys) return !1;
                this.si(!0);
                this.mp();
                q.logInfo(l.resolve(332));
                this.Eg();
                return !0
            },
            mp: function() {
                d.Hu(this.w, this.o)
            },
            si: function(a) {
                do this.id = z++; while (d.sj(this.id, "lsEngine"));
                a || (this.ca.gl(this.w, this.id) ? this.ca.eg(this.w, this.id) && this.si() : this.si())
            },
            wu: function() {
                this.vo = f.addRepetitiveTask(this.iA, b.Te, this);
                q.logInfo(l.resolve(333), this)
            },
            Iq: function() {
                var a = this.Va;
                a == b.fc && (a = m.mk("LSF__" + m.sc() + "_" + this.id + "_" + this.w), this.L = new r, d.qa(this.id, b.li, this.L));
                h.getFrameWindow(a, !0) ? (this.yk = 500, this.np()) : (this.Ck = f.addTimedTask(this.Iq, this.yk, this), this.yk *= 2);
                return a
            },
            ow: function() {
                var a = t.yv(n.eu);
                this.L = new n;
                this.np(a);
                d.qa(this.id, b.oi, a);
                return a
            },
            np: function(a) {
                var b = this;
                this.L.addListener({
                    onReady: function() {
                        b.Es();
                        b.Ck = f.addTimedTask(b.wu, 0, b);
                        b.L.removeListener(this)
                    }
                });
                this.L.start(a)
            },
            ha: function() {
                return this.id
            },
            Eu: function(a) {
                a != this.ie && (this.ie = a, this.ca.gl(a, this.id, this.w))
            },
            Is: function(a) {
                this.ie != a ? null == this.ie ? q.logWarn(l.resolve(330),
                    a) : q.logError(l.resolve(329), this.ie, a) : this.ie = null;
                this.ca.Ih(a, this.id, this.w)
            },
            dx: function(a) {
                a = this.ca.fA(a);
                if (!a) return 0;
                for (var c = 0, g = 0; g < a.length; g++) p.getTimeStamp() - a[g].Rb()[C] > b.Te || c++;
                return c
            },
            Es: function() {
                this.Bj = p.getTimeStamp() + this.Cq;
                this.ca.pC(this.w, this.id, [this.Bj, this.Va, this.host, b.Qk, b.vg, this.Lg])
            },
            iA: function() {
                if (this.Dn) q.logDebug(l.resolve(336)), this.Dn = !1;
                else {
                    var a = !1;
                    if (this.po) {
                        q.logDebug(l.resolve(337), this);
                        var c = this.ca.Jn(this.w);
                        if (c) {
                            q.logDebug(l.resolve(339),
                                this.w);
                            for (var g = 0; g < c.length; g++)
                                if (c[g] != this.id) {
                                    var e = this.ca.eg(this.w, c[g]);
                                    e ? e[b.Oo] != b.Qk || e[b.Xo] != b.vg ? q.logDebug(l.resolve(341), c[g]) : (e[C] == this.Bj && (this.Cq = p.randomG(5)), e[C] > this.Bj ? a |= this.Wy(c[g], e[C]) : this.th[c[g]] && delete this.th[c[g]]) : q.logDebug(l.resolve(340), c[g])
                                }
                        } else q.logDebug(l.resolve(338), this)
                    }
                    a || (q.logDebug(l.resolve(342)), this.ca.gl(this.w, this.id), this.Es())
                }
            },
            Wy: function(a, b) {
                q.logDebug(l.resolve(343) + a + " with a newer status");
                if (this.th[a]) {
                    if (this.th[a] == b || this.Ov[a]) return !1;
                    q.logInfo(l.resolve(334) + this.id);
                    this.Wv()
                }
                this.th[a] = b;
                return !0
            },
            Wv: function() {
                this.clean();
                this.po && f.executeTask(this.po)
            },
            Gr: function() {
                this.ca.Gl(this.w, this.id);
                this.ca.Ih(this.w, this.id);
                this.Dn = !0
            },
            clean: function() {
                q.logInfo(l.resolve(335), this);
                f.stopRepetitiveTask(this.vo);
                f.stopRepetitiveTask(this.Ck);
                this.Ck = this.vo = null;
                this.Va != b.fc ? h.disposeFrame(this.Va) : this.Lg != b.fc && t.qA(this.Lg);
                this.Lg = this.Va = b.fc;
                this.Is(this.ie);
                this.w && d.oA(this.w, this.o);
                this.L && (d.Ii(this.id, b.li), d.Ii(this.id,
                    b.oi));
                this.L = null;
                this.Gr()
            },
            unloadEvent: function() {
                this.clean()
            },
            preUnloadEvent: function() {
                this.Gr()
            },
            G: function() {
                this.clean();
                k.removeBeforeUnloadHandler(this);
                k.removeUnloadHandler(this);
                a.stop(this.iw)
            }
        };
        u.prototype.unloadEvent = u.prototype.unloadEvent;
        u.prototype.preUnloadEvent = u.prototype.preUnloadEvent;
        return u
    });
    define("lscU", ["Executor", "lscAe", "lscAj", "lscAi"], function(d, f, b) {
        function a(a, b, d) {
            this.Cs = a;
            this.target = d;
            this.id = c++;
            this.buffer = [];
            this.ready = !1;
            this.Gd = {};
            this.Yy = 0;
            b && this.JA(b)
        }
        var c = 0;
        a.prototype = {
            JA: function(a) {
                this.L = a;
                a.addListener(this);
                if (a.Da()) this.onReady()
            },
            G: function(a) {
                this.L && !a && this.L.G()
            },
            onListenStart: function() {
                if (this.L.Da()) this.onReady()
            },
            onReady: function() {
                if (!this.ready) {
                    this.ready = !0;
                    for (var a = 0; a < this.buffer.length; a++) {
                        var b = this.buffer[a],
                            c =
                            this.call(b.method, b.Yb, b.uq);
                        b.uq && b.eA(c)
                    }
                    this.buffer = []
                }
            },
            onMessage: function(a) {
                this.tu(a.sender, a.an, a.type, a.Yb)
            },
            tu: function(a, b, c, d) {
                "RESPONSE" == c ? this.Gd[b] && (this.Gd[b].ok(d[0]), delete this.Gd[b]) : a === this.target && (c = this.Cs[c].apply(this.Cs, d), "undefined" !== typeof c && this.yA(a, b, c))
            },
            mn: function(a, b) {
                this.Gd[b] && (this.Gd[b].Pj(f.Zt), delete this.Gd[b])
            },
            yA: function(a, b, c) {
                this.L.sendMessage(a, "RESPONSE", b, [c])
            },
            call: function(a, c, p, k) {
                c = b.Ai(c);
                if (this.ready) {
                    var h = this.id + "_" + this.Yy++;
                    this.L.sendMessage(this.target,
                        a, h, c);
                    if (p) {
                        var l = this;
                        return new Promise(function(a, b) {
                            l.Gd[h] = {
                                ok: a,
                                Pj: b
                            };
                            k && d.addTimedTask(function() {
                                l.Gd[h] && b(f.$t)
                            }, k)
                        })
                    }
                } else {
                    var m = {
                        target: this.target,
                        method: a,
                        Yb: c,
                        uq: p,
                        GC: k
                    };
                    this.buffer.push(m);
                    if (p) return new Promise(function(a) {
                        m.eA = a
                    })
                }
            }
        };
        a.prototype.onReady = a.prototype.onReady;
        a.prototype.onMessageFail = a.prototype.mn;
        a.prototype.onMessage = a.prototype.onMessage;
        a.prototype.onListenStart = a.prototype.onListenStart;
        return a
    });
    define("lscQ", ["lscU", "lscAj"], function(d, f) {
        function b(a, b) {
            this.Lm(a, b)
        }
        b.Sg = function(a, b) {
            return b.jl ? function() {
                return this.channel.call(a, [this.$a].concat(f.Ai(arguments)), b.Go, b.Ts)
            } : function() {
                return this.channel.call(a, arguments, b.Go, b.Ts)
            }
        };
        b.prototype = {
            Lm: function(a, b) {
                this.channel = new d(this, a, b)
            },
            yt: function(a) {
                this.channel.G(a)
            }
        };
        return b
    });
    define("lscn", ["Inheritance", "lscm", "lscQ"], function(d, f, b) {
        function a(b, c, g) {
            this._callSuperConstructor(a, [b, g]);
            this.Lm(c, g)
        }
        var c, g;
        for (g in {
                G: !0
            }) c = g;
        a.prototype = {
            G: function() {
                this._callSuperMethod(a, c);
                this.yt(!0)
            }
        };
        var e = f.methods;
        for (g in e) a.prototype[g] = b.Sg(g, e[g]);
        d(a, f);
        d(a, b, !0);
        return a
    });
    define("lscR", ["EventDispatcher", "Inheritance", "lscn"], function(d, f, b) {
        function a(b, g) {
            this._callSuperConstructor(a);
            this.L = g;
            this.o = b;
            this.L.addListener(this)
        }
        a.prototype = {
            Ez: function(a) {
                var g = new b(this.o, this.L, a);
                this.dispatchEvent("onNewPushPage", [a, g])
            },
            mn: function(a) {
                this.L.Ls(a);
                this.dispatchEvent("onPushPageLost", [a])
            },
            G: function() {
                this.L.G()
            }
        };
        a.prototype.onRemote = a.prototype.Ez;
        a.prototype.onMessageFail = a.prototype.mn;
        f(a, d);
        return a
    });
    define("lscAS", [], function() {
        return {
            Pk: "ATTACH",
            ki: "ATTACH:FAST",
            Re: "IGNORE",
            tg: "ABORT",
            ji: "CREATE",
            bp: "WAIT"
        }
    });
    define("lscAQ", "Inheritance lscAP lscQ lscAe Executor LoggerManager".split(" "), function(d, f, b, a, c, g) {
        function e(b, c) {
            this._callSuperConstructor(e, [b]);
            this.rq = "remote";
            this.Lm(c, a.mi);
            this.iC(c)
        }
        var p, k;
        for (k in {
                G: !0
            }) p = k;
        var h = g.getLoggerProxy(a.Eb),
            l = 2E3;
        e.prototype = {
            iC: function(a) {
                var b = this;
                a.Da() ? this.Gs(a) : (a.addListener({
                    onReady: function() {
                        b.Gs(a)
                    }
                }), c.addTimedTask(this.jC, l, this))
            },
            jC: function(a) {
                a.Da() || (l *= 2, this.Sf())
            },
            Gs: function(b) {
                b.$b == a.mi &&
                    (h.logInfo(g.resolve(344) + this.Ca + " is a master but should be a slave: engine must die"), c.addTimedTask(this.Sf, 0, this, [!1, !0]))
            },
            G: function() {
                this._callSuperMethod(e, p);
                this.yt()
            }
        };
        var m = f.methods;
        for (k in m) e.prototype[k] = b.Sg(k, m[k]);
        d(e, f);
        d(e, b, !0);
        return e
    });
    define("lscAh", ["LoggerManager", "Helpers", "lscAe"], function(d, f, b) {
        function a() {
            this.Ds = null
        }

        function c(a, b) {
            return "var callFun \x3d " + function(a, b) {
                window.name != a || window != top || window.Lightstreamer && window.Lightstreamer.Mt || (window.name = b, window.close())
            }.toString() + "; callFun('" + a + "', '" + b + "');"
        }
        var g = 0,
            e = 0,
            p = !1,
            k = !1,
            h = d.getLoggerProxy(b.Eb),
            l = [];
        a.prototype = {
            Cy: function(a, b) {
                var f = null;
                try {
                    l[a] && (f = l[a])
                } catch (v) {
                    f = null
                }
                if (f && (delete l[a], this.Ir(f, a, b))) return !0;
                a: {
                    var f = "javascript:" +
                        ('eval("' + c(a, a + "__TRASH") + '; ")'),
                        r = null;h.logDebug(d.resolve(346));
                    if (k) f = !1;
                    else {
                        try {
                            try {
                                var u;
                                if (window.SymError) {
                                    var q = !0; - 5 > e - g && (q = !1);
                                    window.SymRealWinOpen && q ? (g++, u = window.SymRealWinOpen(f, a, "height\x3d100,width\x3d100", !0)) : (p || (p = !0, h.logWarn(d.resolve(345))), g = 0, u = null)
                                } else u = window.open(f, a, "height\x3d100,width\x3d100", !0);
                                r = u
                            } catch (v) {
                                r = null
                            }
                        } catch (v) {
                            h.logDebug(d.resolve(347), v);
                            f = !1;
                            break a
                        }
                        if (r) try {
                            e++
                        } catch (v) {
                            k = !0
                        }
                        f = r
                    }
                }
                if (!1 === f) return h.logDebug(d.resolve(348)), !1;
                if (!f) return h.logDebug(d.resolve(349)),
                    !0;
                h.logDebug(d.resolve(350));
                this.Ir(f, a, b);
                return !0
            },
            Ir: function(a, b, c) {
                try {
                    h.logDebug(d.resolve(351));
                    if (a.closed) return h.logDebug(d.resolve(352)), !1;
                    var g = a;
                    if (c) {
                        if (a == a.top && !a.Lightstreamer) {
                            h.logDebug(d.resolve(353));
                            try {
                                a.name != b && a.name != b + "__TRASH" || a.close()
                            } catch (e) {
                                h.logDebug(d.resolve(354), e)
                            }
                            return !1
                        }
                        g = a.parent;
                        if (null == g) return h.logDebug(d.resolve(355)), !1
                    }
                    if (!g.Lightstreamer) return h.logDebug(d.resolve(356)), !1;
                    if (!g.Lightstreamer.Mt) return h.logDebug(d.resolve(357)), !1;
                    h.logDebug(d.resolve(358));
                    this.Ds = g;
                    l[b] = a
                } catch (e) {
                    return h.logDebug(d.resolve(359), e), !1
                }
                return !0
            }
        };
        return a
    });
    define("lscV", ["Promise", "lscAh"], function(d, f) {
        function b(a) {
            this.Va = a
        }
        var a = {};
        b.prototype = {
            jx: function() {
                if (a[this.Va]) return d.resolve(null);
                var b = new f;
                return b.Cy(this.Va, !0) ? (b = b.Ds, null == b ? (a[this.Va] = !0, d.resolve(null)) : d.resolve(b)) : d.resolve(null)
            }
        };
        return b
    });
    define("lscAT", "LoggerManager Global lscAe Promise Helpers Executor lscAP lscAQ lscAS lscAW lscT lscW lscV".split(" "), function(d, f, b, a, c, g, e, p, k, h, l, m, t) {
        function n(a, b) {
            var c = h.$q();
            c.Gl(b, a);
            c.Ih(b, a)
        }

        function r(a, c, g, e, d, f, h) {
            this.w = c;
            this.Ey = d;
            this.Cn = g;
            this.vs = e;
            this.Md = f;
            this.hh = 0;
            this.Og = {};
            this.He = 0;
            this.client = a;
            this.Nn = !1;
            this.Ig = h || b.Ot;
            this.Pj = this.ok = null;
            this.Qj = !1
        }
        var u = d.getLoggerProxy(b.Eb);
        r.op = 0;
        r.prototype = {
            stop: function() {
                u.logInfo(d.resolve(361));
                this.He++;
                this.Nn || this.$k()
            },
            find: function(a) {
                this.Og = a || {};
                a = this.ru();
                this.$d(this.He, !1);
                return a
            },
            tm: function() {
                return this.Og
            },
            cp: function(a) {
                this.Nn = !0;
                this.ok(a);
                this.stop()
            },
            $k: function() {
                this.Nn = !0;
                this.Pj();
                this.stop()
            },
            jp: function() {
                this.Qj = !0
            },
            kp: function() {
                this.vs == k.ji ? (u.logInfo(d.resolve(362)), this.cp(null)) : this.vs == k.bp ? (u.logInfo(d.resolve(363), 1E3), g.addTimedTask(this.$d, 1E3, this, [this.He, !1])) : (u.logInfo(d.resolve(364)), this.$k())
            },
            bl: function(a, b, c) {
                if (this.Cn == k.tg) u.logInfo(d.resolve(365)), this.$k();
                else if (this.Cn != k.Re) {
                    u.logInfo(d.resolve(366) + c);
                    var g;
                    1 == a ? (g = new e(this.client), b.Ap(g)) : (a = 2 == a ? new l : new m, b = a.start(b), g = new p(this.client, a), b.then(null, function() {
                        u.logInfo(d.resolve(367) + c + " must die");
                        g.Sf(!1, !0)
                    }));
                    g.jt(c);
                    this.cp(g)
                } else u.logInfo(d.resolve(368)), this.stop()
            },
            $d: function(a, c) {
                if (this.He == a)
                    if (a = ++this.He, u.logDebug(d.resolve(372)), this.Ey) u.logDebug(d.resolve(374)), this.kp();
                    else if (this.Md) {
                    u.logDebug(d.resolve(375));
                    try {
                        var e = this.Md.Lightstreamer,
                            f = e.sx(this.w);
                        u.logDebug(d.resolve(376) + f + " (" + this.w + ").");
                        if (null != f) {
                            var h = f.ne();
                            if (e.sj(h, b.oi)) {
                                this.bl(3, e.Uq(h, b.oi), h);
                                return
                            }
                            if (e.sj(h, b.li)) {
                                this.bl(2, e.Uq(h, b.li), h);
                                return
                            }
                        } else 1 == c && this.jp()
                    } catch (k) {
                        u.logDebug(d.resolve(377) + k)
                    }
                    this.Md = null;
                    this.$d(this.He, !1)
                } else {
                    u.logDebug(d.resolve(378));
                    var l = this,
                        p = ++this.hh;
                    g.addTimedTask(function() {
                        p == l.hh && l.hh++
                    }, b.cu);
                    r.op++;
                    this.al(this.hh).then(function(c) {
                        r.op--;
                        if (a == l.He)
                            if (u.logDebug(d.resolve(379)),
                                null == c) u.logDebug(d.resolve(380)), l.kp();
                            else {
                                u.logInfo(d.resolve(369) + c.id);
                                var g = c.values,
                                    e = g[b.No],
                                    f = g[b.St];
                                if (e !== b.fc) try {
                                    u.logDebug(d.resolve(381) + c.id + " shares through shared worker", e), l.bl(3, e, c.id)
                                } catch (h) {
                                    l.$d(a, !1)
                                } else f !== b.fc ? (u.logDebug(d.resolve(382) + c.id + " shares through direct communication", f), c = (new t(f)).jx(), null != c ? c.then(function(b) {
                                    (l.Md = b) || l.jp();
                                    l.$d(a, !0)
                                }) : l.$d(a, !1)) : (u.logInfo(d.resolve(370), g), l.$d(a, !1))
                            }
                    })
                }
            },
            ru: function() {
                var b = this;
                return new a(function(a, c) {
                    b.ok =
                        a;
                    b.Pj = c
                })
            },
            al: function(e, f) {
                if (this.hh != e) return a.resolve(null);
                var l = this,
                    p = b.Te,
                    m = b.Te + b.Yo,
                    r = h.$q();
                return new a(function(a) {
                    if (f)
                        for (var h in f) {
                            var t = r.eg(l.w, h);
                            if (t && t[b.ni] != f[h]) {
                                l.Og[h] = !0;
                                a({
                                    id: h,
                                    values: t
                                });
                                return
                            }
                        }
                    var y = {};
                    if (h = r.Jn(l.w))
                        for (var F = !1, x = 0; x < h.length; x++)
                            if (!l.Og[h[x]])
                                if (t = r.eg(l.w, h[x]), !t || 5 > t.length) n(h[x], l.w), u.logDebug(d.resolve(383), h[x]);
                                else if (t[b.Oo] != b.Qk || t[b.Xo] != b.vg) u.logDebug(d.resolve(384), t);
                    else {
                        var A = c.getTimeStamp(),
                            E = parseInt(t[b.ni]),
                            A = A - E,
                            G = t[b.No] !=
                            b.fc || l.Cn == k.ki;
                        if (A <= (G ? p : m)) {
                            if (G) {
                                l.Og[h[x]] = !0;
                                a({
                                    id: h[x],
                                    values: t
                                });
                                return
                            }
                            F = !0;
                            y[h[x]] = E
                        } else G && A <= m ? (F = !0, y[h[x]] = E) : 6E4 < A && (u.logInfo(d.resolve(371)), n(h[x], l.w))
                    }
                    F ? (u.logDebug(d.resolve(385)), g.addTimedTask(function() {
                        l.al(e, y).then(function(b) {
                            a(b)
                        })
                    }, b.Te)) : f ? (u.logDebug(d.resolve(386)), a(null)) : (u.logDebug(d.resolve(387), l.Ig), g.addTimedTask(function() {
                        l.al(e, {}).then(function(b) {
                            a(b)
                        })
                    }, l.Ig))
                })
            }
        };
        r.aw = {
            stop: function() {},
            find: function() {
                return a.resolve(null)
            },
            tm: function() {
                return {}
            }
        };
        r.Au = {
            stop: function() {},
            find: function() {
                return a.reject(null)
            },
            tm: function() {
                return {}
            }
        };
        return r
    });
    define("ConnectionSharing", "lscAe LoggerManager Inheritance Setter Environment IllegalArgumentException lscAW lscR lscAS lscAT lscX".split(" "), function(d, f, b, a, c, g, e, p, k, h, l) {
        function m(a, b, e, h, k) {
            if (!a) throw new g("The share name is missing");
            if (!t.test(a)) throw new g("The given share name is not valid, use only alphanumeric characters");
            if (!r[e]) throw new g("sharePolicyOnNotFound must be one of: CREATE, ABORT, WAIT");
            if (!n[b]) throw new g("sharePolicyOnFound must be one of: ATTACH, ATTACH:FAST, IGNORE, ABORT");
            this.Ee = this.checkBool(h, !0);
            if (!c.isBrowserDocument()) {
                if (u[b]) throw new g("ATTACH* can only be used if the LightstreamerClient is loaded inside a browser document");
                this.Ee = !0
            }
            "file:" != d.vg || h || (q.logWarn(f.resolve(388)), h = !0);
            this.Ee = h;
            this.w = a;
            this.gd = b;
            this.Wh = e;
            this.Md = k;
            this.Ig = null;
            this.Qr = !1;
            q.isDebugLogEnabled() && q.logDebug(f.resolve(392), "shareName\x3d" + this.w, "sharePolicyOnFound\x3d" + this.gd, "sharePolicyOnNotFound\x3d" + this.Wh, "preventCrossWindowShare\x3d" + this.Ee, "shareRef\x3d" + this.Md)
        }
        var t = /^[a-zA-Z0-9]*$/,
            n = {};
        n[k.Pk] = !0;
        n[k.ki] = !0;
        n[k.Re] = !0;
        n[k.tg] = !0;
        var r = {};
        r[k.ji] = !0;
        r[k.tg] = !0;
        r[k.bp] = !0;
        var u = {};
        u[k.Pk] = !0;
        u[k.ki] = !0;
        var q = f.getLoggerProxy(d.Eb);
        m.prototype = {
            wv: function(a, b, c) {
                a = new e(this.w, a);
                this.Ee ? a.AB() : (b = this.Tu() ? null : b, a.zB(b, c));
                return a
            },
            vv: function(a, b) {
                return new p(a, b)
            },
            Tu: function() {
                return this.gd === k.Re || this.Qr
            },
            Qj: function() {
                this.Qr = !0
            },
            tv: function(a, b) {
                var c = new m(this.w, b ? k.Re : this.gd, this.gd == k.Pk || this.gd == k.ki ? k.ji : this.Wh, this.Ee, this.Md);
                c.Ig =
                    a;
                return c
            },
            dw: function(a) {
                if (this.gd == k.Re && this.Wh == k.ji) return q.logInfo(f.resolve(389)), h.aw;
                if (this.gd != k.Re && this.gd != k.tg || this.Wh != k.tg) return q.logInfo(f.resolve(391)), new h(a, this.w, this.gd, this.Wh, this.Ee, this.Md, this.Ig);
                q.logInfo(f.resolve(390));
                return h.Au
            },
            tx: function() {
                return this.w
            },
            xj: function() {
                return this.Ee || l.Gp()
            }
        };
        m.prototype.getShareName = m.prototype.tx;
        b(m, a, !0, !0);
        return m
    });
    define("ls_sbc", ["ConnectionSharing"], function(d) {
        return function(f) {
            return {
                enableSharing: function(b, a, c, g, e) {
                    a == c && "ABORT" == a ? f.em(null) : f.em(new d(b, a, c, g, e))
                },
                isMaster: function() {
                    return f.zf()
                }
            }
        }
    });
    define("LightstreamerClient", "Helpers Global Executor lscC lscE lscD lscAP lscAI lscAO lscAc Inheritance Setter EventDispatcher lscAe EnvironmentStatus IllegalArgumentException Environment LoggerManager IllegalStateException ASSERT lsco lsck ls_sbc BrowserDetection lscAK".split(" "), function(d, f, b, a, c, g, e, p, k, h, l, m, t, n, r, u, q, v, z, C, B, w, H, D, L) {
        function y(b, e) {
            this.C = y;
            this._callSuperConstructor(y);
            this.Zp = new c;
            this.Sl = new g;
            this.connectionOptions = this.Zp;
            this.connectionDetails = this.Sl;
            this.connectionSharing = H(this);
            this.ka = new a;
            this.sb = this.Zp;
            this.Fb = this.Sl;
            b && this.Fb.rt(b);
            e && this.Fb.gt(e);
            this.ka.lg(this);
            this.sb.lg(this);
            this.Fb.lg(this);
            this.u = new h(this.sb);
            this.Ke = this.S = null;
            this.Zg = this.Xh = 0;
            this.eC = ++A;
            this.J = new k;
            this.rh = n.Db;
            this.Hi = null;
            this.Ht = {};
            r.addUnloadHandler(this)
        }
        var F = v.getLoggerProxy(n.Ok),
            x = v.getLoggerProxy(n.Eb),
            A = 0,
            E = /^[a-zA-Z0-9_]*$/;
        y.Fu = function(a, b) {
            q.isNodeJS() &&
                p.qp(b)
        };
        y.Gw = function(a) {
            if (q.isNodeJS()) {
                var b = [];
                p.Vq(a).forEach(function(a) {
                    b.push(a.toString())
                });
                return b
            }
        };
        y.setLoggerProvider = function(a) {
            v.setLoggerProvider(a)
        };
        y.Ut = "javascript_client";
        y.Vt = "7.2.0 build 1777";
        y.simulateSilence = function(a) {
            B.CB(a)
        };
        y.prototype = {
            toString: function() {
                return ["[|LightstreamerClient", this.eC, this.N, this.PC, "]"].join("|")
            },
            sk: function(a) {
                this.S = a;
                this.u.ai(a);
                this.J.ai(a);
                this.kt = this.Zg;
                this.Hi = b.addRepetitiveTask(a.Bl, 5E3, a)
            },
            Tp: function() {
                this.S && (this.Ht[this.S.ne()] = !0, this.u.ai(null), this.J.ai(null), this.Hi && (b.stopRepetitiveTask(this.Hi), this.Hi = null), this.S.G(), this.S = null, this.se && (this.se.G(), this.se = null), this.ka.Qg ? this.nl(n.Ag) : this.nl(n.Db));
                this.search && (this.search.stop(), this.search = null)
            },
            af: function(a, b, c) {
                this.S && this.S.Zr(a, b, c);
                return !0
            },
            Vr: function(a, b) {
                b != this.ka && this.dispatchEvent("onPropertyChange", [a])
            },
            em: function(a) {
                var c = q.isBrowser() ? navigator.userAgent.toLowerCase() : null;
                null == c || -1 == c.indexOf("ucbrowser") && -1 == c.indexOf("ubrowser") ?
                    (this.Zg++, b.addTimedTask(this.qq, 0, this, [a, this.Zg])) : x.logInfo(v.resolve(394))
            },
            qq: function(a, b) {
                if (b == this.Zg)
                    if (this.Xh++, this.Tp(), (this.Ke = a) && !a.xj() && x.logInfo(v.resolve(395)), a && a.xj()) {
                        b = this.Xh;
                        var c = this,
                            g = a.dw(this);
                        this.search = g;
                        this.search.find(this.Ht).then(function(a) {
                            b == c.Xh && (1 == c.search.Qj && c.Ke.Qj(), null === a ? c.bo(b, g.tm()) : c.sk(a))
                        }, function() {
                            b == c.Xh && c.dispatchEvent("onShareAbort")
                        })
                    } else null == a && this.ka.Qg && this.bo()
            },
            Sv: function(a, b) {
                if (this.kt == this.Zg)
                    if (this.Tp(), r.isUnloading() ||
                        r.isUnloaded()) F.logInfo(v.resolve(396));
                    else if (this.Ke) {
                    F.logInfo(v.resolve(397));
                    var c = null;
                    2 >= this.ka.sd || (a ? c = 1E4 : (c = 200 + 500 * d.randomG(this.ka.sd), 5E3 < c && (c = 5E3)));
                    c = this.Ke.tv(c, b);
                    this.qq(c, this.kt)
                } else C.fail(), F.logError(v.resolve(393))
            },
            unloadEvent: function() {
                this.disconnect();
                this.S && this.S.Up()
            },
            bo: function(a, b) {
                if (!a || a == this.Xh) return this.sk(new e(this)), this.se = new w(this.ka, this.sb, this.Fb, this.Ke, this.S, b), this.S.jt(this.se.ne()), this.S.nB(this.se.Wc()), this.S
            },
            zf: function() {
                return null !=
                    this.se
            },
            connect: function() {
                if (!this.Fb.Oh) throw new z("Configure the server address before trying to connect");
                F.logInfo(v.resolve(398));
                b.addTimedTask(this.Ou, 0, this)
            },
            Ou: function() {
                if (!this.rh || this.rh == n.Db) {
                    null != this.Ke && this.Ke.xj() || this.se || this.bo();
                    F.logDebug(v.resolve(400));
                    this.ka.X("connectionRequested", !0);
                    var a = this.S;
                    a && a.Dp()
                }
            },
            disconnect: function() {
                F.logInfo(v.resolve(399));
                b.addTimedTask(this.Pu, 0, this)
            },
            Pu: function() {
                F.logDebug(v.resolve(401));
                this.ka.X("connectionRequested",
                    !1);
                var a = this.S;
                a && a.Ep()
            },
            Rb: function() {
                return this.rh
            },
            sendMessage: function(a, c, g, e, d) {
                if (!c) c = n.Fc;
                else if (!E.test(c)) throw new u("The given sequence name is not valid, use only alphanumeric characters plus underscore, or null");
                g = g || 0 == g ? this.checkPositiveNumber(g, !0) : null;
                d = this.checkBool(d, !0);
                b.addTimedTask(this.Nu, 0, this, [a, c, e, g, d])
            },
            Nu: function(a, b, c, g, e) {
                this.S && this.S.zb ? this.J.eh(a, b, c, g) : e ? this.J.Tv(a, b, c, g) : c && this.J.fireEvent("onAbort", c, [a, !1])
            },
            FA: function(a, b) {
                this.dispatchEvent("onServerError",
                    [a, b])
            },
            pk: function() {
                this.u.Zz();
                this.J.iv()
            },
            GA: function() {
                this.u.Ix();
                this.J.Hx()
            },
            nl: function(a) {
                a != this.rh && (this.rh = a, this.dispatchEvent("onStatusChange", [a]))
            },
            Nh: function(a) {
                return this.S && this.S.zb ? (this.S.Gq(a), !0) : !1
            },
            xc: function() {
                this.dispatchEvent("onServerKeepalive")
            },
            xx: function() {
                var a = [],
                    b = this.u.pb,
                    c;
                for (c in b) b[c].wt || a.push(b[c]);
                return a
            },
            subscribe: function(a) {
                this.u.pp(a)
            },
            unsubscribe: function(a) {
                this.u.Hs(a)
            },
            addListener: function(a) {
                this._callSuperMethod(y, "addListener", [a])
            },
            removeListener: function(a) {
                this._callSuperMethod(y, "removeListener", [a])
            },
            getListeners: function() {
                return this._callSuperMethod(y, "getListeners")
            }
        };
        y.__restoreWs = L.Us;
        y.addCookies = y.Fu;
        y.getCookies = y.Gw;
        y.setLoggerProvider = y.setLoggerProvider;
        y.LIB_NAME = y.Ut;
        y.LIB_VERSION = y.Vt;
        y.prototype.connect = y.prototype.connect;
        y.prototype.disconnect = y.prototype.disconnect;
        y.prototype.getStatus = y.prototype.Rb;
        y.prototype.sendMessage = y.prototype.sendMessage;
        y.prototype.getSubscriptions = y.prototype.xx;
        y.prototype.subscribe =
            y.prototype.subscribe;
        y.prototype.unsubscribe = y.prototype.unsubscribe;
        y.prototype.addListener = y.prototype.addListener;
        y.prototype.removeListener = y.prototype.removeListener;
        y.prototype.getListeners = y.prototype.getListeners;
        y.prototype.enableSharing = y.prototype.em;
        y.prototype.isMaster = y.prototype.zf;
        y.prototype.unloadEvent = y.prototype.unloadEvent;
        y.prototype.preUnloadEvent = y.prototype.unloadEvent;
        l(y, t, !1, !0);
        l(y, m, !0, !0);
        return y
    });
    define("lscAa", ["lscAe", "Assertions"], function(d, f) {
        function b(a, b, g) {
            this.$f = a;
            this.Dr = b;
            this.hk = g
        }
        b.prototype = {
            ds: function(a, b, g) {
                this.co() && (f.verifyValue(b, 1, "Unexpected item position"), this.$f.DB(this.hk, g))
            },
            Wf: function(a, b) {
                this.co() && this.$f.EB(a, b, this.hk)
            },
            onItemUpdate: function(a) {
                if (this.co()) return f.verifyValue(a.lj(), 1, "Unexpected item position"), a = a.Sd, this.$f.kB(a.length - 2), a = this.sv(a), this.$f.update(a, !1, !0)
            },
            co: function() {
                return this.$f.lr(this.Dr,
                    this.hk)
            },
            sv: function(a) {
                var b = this.$f,
                    g = this.Dr,
                    e = [];
                e[0] = b.jd;
                e[1] = g;
                e.Mc = [];
                for (var g = b.Tq() + 2, f = 2, k = 2; k < g; k++) k == b.keyCode + 1 ? e[k] = this.hk : k == b.fb + 1 ? e[k] = "UPDATE" : k <= b.ma.wb + 1 ? e[k] = d.Ue : (e[k] = a[f], a.Ao[f] ? e[k] = d.Ue : e.Mc.push(k - 1), f++);
                return e
            }
        };
        b.prototype.onSubscriptionError = b.prototype.Wf;
        b.prototype.onItemUpdate = b.prototype.onItemUpdate;
        b.prototype.onItemLostUpdates = b.prototype.ds;
        return b
    });
    define("lscAZ", ["LoggerManager", "IllegalArgumentException", "lscAe"], function(d, f, b) {
        function a(a, b, c, d, f) {
            this.Ay = b;
            this.zy = a;
            this.qu = d;
            this.ma = c;
            this.Sd = f
        }
        var c = d.getLoggerProxy(b.Ok);
        a.prototype = {
            Bm: function() {
                return this.zy
            },
            lj: function() {
                return this.Ay
            },
            getValue: function(a) {
                a = this.ei(a);
                return (a = this.Sd[a]) && a.QC ? a.value : a
            },
            Cr: function(a) {
                a = this.ei(a);
                return !this.Sd.Ao[a]
            },
            py: function() {
                return this.qu
            },
            forEachChangedField: function(a) {
                for (var b = this.Sd.Mc, f = 0; f < b.length; f++) {
                    var k = this.ma.getName(b[f]),
                        h = this.Sd[b[f] + 1];
                    try {
                        a(k, b[f], h)
                    } catch (l) {
                        c.logErrorExc(l, d.resolve(402))
                    }
                }
            },
            Eq: function(a) {
                for (var b = 2; b < this.Sd.length; b++) {
                    var f = b - 1,
                        k = this.ma.getName(f),
                        h = this.Sd[b];
                    try {
                        a(k, f, h)
                    } catch (l) {
                        c.logErrorExc(l, d.resolve(403))
                    }
                }
            },
            ei: function(a) {
                a = isNaN(a) ? this.ma.oe(a) : a;
                if (null == a) throw new f("the specified field does not exist");
                if (0 >= a || a > this.ma.ym() + 1) throw new f("the specified field position is out of bounds");
                return a + 1
            },
            cx: function() {
                return this.Sd.length - 2
            },
            Kw: function(a) {
                return this.ma.getName(a)
            }
        };
        a.prototype.getItemName = a.prototype.Bm;
        a.prototype.getItemPos = a.prototype.lj;
        a.prototype.getValue = a.prototype.getValue;
        a.prototype.isValueChanged = a.prototype.Cr;
        a.prototype.isSnapshot = a.prototype.py;
        a.prototype.forEachChangedField = a.prototype.forEachChangedField;
        a.prototype.forEachField = a.prototype.Eq;
        return a
    });
    define("lscZ", [], function() {
        function d() {
            this.ac = null;
            this.wb = 0
        }
        d.prototype = {
            st: function(d) {
                this.ac = d
            },
            ym: function() {
                return this.ac ? this.wb + this.ac.wb : this.wb
            },
            Ld: function(d) {
                this.wb = d
            }
        };
        return d
    });
    define("lsca", ["Inheritance", "lscZ"], function(d, f) {
        function b(a) {
            this._callSuperConstructor(b);
            this.list = a;
            for (var c = {}, g = 0; g < a.length; g++) c[a[g]] = g + 1;
            this.Vs = c;
            this.wb = a.length
        }
        b.prototype = {
            Ld: function() {},
            um: function() {
                return this.list.join(" ")
            },
            oe: function(a) {
                return this.Vs[a] ? this.Vs[a] : this.ac ? (a = this.ac.oe(a), null !== a ? a + this.wb : null) : null
            },
            getName: function(a) {
                return a > this.wb && this.ac ? this.ac.getName(a - this.wb) : this.list[a - 1] || null
            },
            Vc: function() {
                return this.list
            }
        };
        d(b, f);
        return b
    });
    define("lscb", ["Inheritance", "lscZ"], function(d, f) {
        function b(a) {
            this._callSuperConstructor(b);
            this.name = a
        }
        b.prototype = {
            um: function() {
                return this.name
            },
            oe: function(a) {
                return this.ac ? (a = this.ac.oe(a), null !== a ? a + this.wb : null) : null
            },
            getName: function(a) {
                return this.ac ? this.ac.getName(a - this.wb) : null
            },
            Vc: function() {
                return this.name
            }
        };
        d(b, f);
        return b
    });
    define("Matrix", [], function() {
        function d(d) {
            this.$ = d || {}
        }
        d.prototype = {
            insert: function(d, b, a) {
                b in this.$ || (this.$[b] = {});
                this.$[b][a] = d
            },
            get: function(d, b) {
                return d in this.$ && b in this.$[d] ? this.$[d][b] : null
            },
            del: function(d, b) {
                if (!(!d in this.$)) {
                    b in this.$[d] && delete this.$[d][b];
                    for (var a in this.$[d]) return;
                    delete this.$[d]
                }
            },
            insertRow: function(d, b) {
                this.$[b] = d
            },
            getRow: function(d) {
                return d in this.$ ? this.$[d] : null
            },
            delRow: function(d) {
                d in this.$ && delete this.$[d]
            },
            getEntireMatrix: function() {
                return this.$
            },
            isEmpty: function() {
                for (var d in this.$) return !1;
                return !0
            },
            forEachElement: function(d) {
                for (var b in this.$) this.forEachElementInRow(b, d)
            },
            forEachRow: function(d) {
                for (var b in this.$) d(b)
            },
            forEachElementInRow: function(d, b) {
                var a = this.$[d],
                    c;
                for (c in a) b(a[c], d, c)
            }
        };
        d.prototype.insert = d.prototype.insert;
        d.prototype.get = d.prototype.get;
        d.prototype.del = d.prototype.del;
        d.prototype.insertRow = d.prototype.insertRow;
        d.prototype.getRow = d.prototype.getRow;
        d.prototype.delRow = d.prototype.delRow;
        d.prototype.getEntireMatrix =
            d.prototype.getEntireMatrix;
        d.prototype.forEachElement = d.prototype.forEachElement;
        d.prototype.forEachElementInRow = d.prototype.forEachElementInRow;
        d.prototype.forEachRow = d.prototype.forEachRow;
        d.prototype.isEmpty = d.prototype.isEmpty;
        return d
    });
    define("Subscription", "lscAa lscAZ lsca lscb Inheritance Setter Matrix Executor lscAe EventDispatcher IllegalArgumentException IllegalStateException LoggerManager lscAj Assertions Helpers".split(" "), function(d, f, b, a, c, g, e, p, k, h, l, m, t, n, r, u) {
        function q(a, b, c) {
            this._callSuperConstructor(q);
            a = (new String(a)).toUpperCase();
            if (!a || !C[a]) throw new l("The given value is not a valid subscription mode. Admitted values are MERGE, DISTINCT, RAW, COMMAND");
            this.pd = a;
            this.ma = this.Sc = this.Mb = this.Ub = this.Cf = this.Df = null;
            this.tc = "RAW" === a ? null : "yes";
            this.jk = this.jd = this.Ni = this.vi = this.fp = this.Eg = this.Fe = this.mb = null;
            this.ue = new e;
            this.bd = new e;
            this.g = null;
            this.ab = 1;
            this.VB = 0;
            this.od = null;
            this.lk = this.Sj = 0;
            this.behavior = this.pd == k.ug ? 2 : 1;
            this.Bo = this.keyCode = this.fb = null;
            this.Od = new e;
            this.Zh = this.Le = this.Nd = null;
            this.PB = k.Vk;
            if (b) {
                if (!c || !u.isArray(c)) throw new l("Please specify a valid field list");
                u.isArray(b) ? this.Uh(b) : this.Uh([b]);
                this.tk(c)
            } else if (c) throw new l("Please specify a valid item or item list");
        }

        function v(a) {
            for (var b = 0; b < a.length; b++) {
                if (!a[b]) throw new l("A field name cannot be empty");
                if (-1 < a[b].indexOf(" ")) throw new l("A field name cannot contain spaces");
            }
        }

        function z(a, b) {
            return a - b
        }
        var C = {
                COMMAND: !0,
                RAW: !0,
                MERGE: !0,
                DISTINCT: !0
            },
            B = k.Ue,
            w = t.getLoggerProxy(k.ap);
        q.prototype = {
            toString: function() {
                return ["[|Subscription", this.ab, this.VB, this.od, this.jd, "]"].join("|")
            },
            Pp: function() {
                this.jd = null;
                this.ue = new e;
                this.bd = new e;
                this.ma.Ld(0);
                this.Ub.Ld(0);
                3 == this.behavior && (this.ma.st(null),
                    this.Od = new e);
                w.logDebug(t.resolve(408), this)
            },
            kz: function(a, b, c) {
                this.xb();
                if (!this.Ub) throw new l("Invalid Subscription, please specify an item list or item group");
                if (!this.ma) throw new l("Invalid Subscription, please specify a field list or field schema");
                this.ab = 5;
                this.od = a;
                this.g = c;
                this.Sj++;
                r.verifyValue(this.Sj, 1, "Wrong count while adding");
                w.logInfo(t.resolve(405), this);
                return !0
            },
            Mz: function() {
                this.ab = 2;
                w.logDebug(t.resolve(409), this)
            },
            Pz: function(a) {
                this.jd = a;
                this.ab = 3;
                w.logDebug(t.resolve(410),
                    this)
            },
            Bz: function() {
                var a = this.Af();
                this.ab = 5;
                this.Pp();
                a && this.as();
                w.logDebug(t.resolve(411), this)
            },
            Fz: function() {
                this.Xx();
                var a = this.Af();
                this.ab = 1;
                this.od = null;
                delete this.jk;
                3 == this.behavior && this.pA();
                this.Pp();
                this.Sj--;
                r.verifyValue(this.Sj, 0, "Wrong count while removing");
                a && this.as();
                this.g = null;
                w.logDebug(t.resolve(412), this)
            },
            Kz: function(a, b, c, g) {
                this.ab = 4;
                this.lk++;
                r.verifyValue(this.lk, 1, "Wrong count starting push");
                w.logInfo(t.resolve(406), this);
                3 == this.behavior && this.ma.st(this.Zh);
                this.Sc && 1 != this.behavior && this.mB(b, a);
                this.Ub.Ld(c);
                this.ma.Ld(g);
                this.dispatchEvent("onSubscription")
            },
            as: function() {
                this.lk--;
                r.verifyValue(this.lk, 0, "Wrong count ending push");
                w.logInfo(t.resolve(407), this);
                this.dispatchEvent("onUnsubscription")
            },
            pA: function() {
                var a = this;
                this.Od.forEachElement(function(b, c, g) {
                    a.Ln(c, g)
                })
            },
            lA: function() {
                var a = this;
                this.Od.forEachElementInRow(function(b, c, g) {
                    a.Ln(c, g)
                })
            },
            kx: function() {
                this.ij();
                return this.jk
            },
            Jq: function() {
                if (null != this.mb) {
                    var a = this.mb;
                    return {
                        LS_requested_max_frequency: "unlimited" ==
                            a ? 0 : a
                    }
                }
                return {}
            },
            ij: function() {
                var a = {
                    LS_mode: this.pd,
                    LS_id: encodeURIComponent(this.Ub.um()),
                    LS_schema: encodeURIComponent(this.ma.um())
                };
                null != this.Ni && (a.LS_data_adapter = encodeURIComponent(this.Ni));
                null != this.vi && (a.LS_selector = encodeURIComponent(this.vi));
                null != this.Eg && (a.LS_start = this.Eg);
                null != this.fp && (a.LS_end = this.fp);
                null != this.tc && (a.LS_snapshot = "yes" === this.tc ? "true" : "no" === this.tc ? "false" : this.tc);
                n.ra(a, this.Jq());
                if (null != this.Fe) {
                    var b = this.Fe;
                    if ("unlimited" == b || 0 < b) a.LS_requested_buffer_size =
                        b
                }
                w.logDebug(t.resolve(413), this);
                return this.jk = a
            },
            jB: function() {
                if (this.pd == k.ug && null != this.Mb && (this.fb = this.Mb.oe("command"), this.keyCode = this.Mb.oe("key"), !this.fb || !this.keyCode)) throw new l("A field list for a COMMAND subscription must contain the key and command fields");
            },
            mB: function(a, b) {
                w.logDebug(t.resolve(414), this, a, b);
                this.fb = a;
                this.keyCode = b
            },
            xb: function() {
                if (this.Bd()) throw new m("Cannot modify an active Subscription, please unsubscribe before applying any change");
            },
            Xx: function() {
                if (!this.Bd()) throw new m("Subscription is not active");
            },
            Rn: function() {
                if (this.pd != k.ug) throw new m("Second level field list is only available on COMMAND Subscriptions");
            },
            Nl: function() {
                if (this.pd != k.ug) throw new m("This method can only be used on COMMAND subscriptions");
            },
            gy: function() {
                return 1 == this.ab
            },
            ry: function() {
                return 2 == this.ab
            },
            Br: function() {
                return 3 == this.ab
            },
            Af: function() {
                return 4 == this.ab
            },
            iy: function() {
                return 5 == this.ab
            },
            Bd: function() {
                return 1 != this.ab
            },
            Qm: function() {
                return this.Af()
            },
            Uh: function(a) {
                this.xb();
                if (!u.isArray(a)) throw new l(" Please specifiy a valid array");
                for (var c = 0; c < a.length; c++)
                    if (a[c]) {
                        if (-1 < a[c].indexOf(" ")) throw new l("An item name cannot contain spaces");
                        if (!isNaN(a[c])) throw new l("An item name cannot be a number");
                    } else throw new l("An item name cannot be empty");
                this.Df = null == a ? null : new b(a);
                this.Cf = null;
                this.Ub = this.Df
            },
            Uw: function() {
                if (!this.Df) {
                    if (this.Cf) throw new m("This Subscription was initiated using an item group, use getItemGroup instead of using getItems");
                    throw new m("The  item list/item group of this Subscription was not initiated");
                }
                return this.Df.Vc()
            },
            mt: function(b) {
                this.xb();
                this.Df = null;
                this.Ub = this.Cf = null == b ? null : new a(b)
            },
            Tw: function() {
                if (!this.Cf) {
                    if (this.Df) throw new m("This Subscription was initiated using an item list, use getItems instead of using getItemGroup");
                    throw new m("The  item list/item group of this Subscription was not initiated");
                }
                return this.Cf.Vc()
            },
            tk: function(a) {
                this.xb();
                if (!u.isArray(a)) throw new l(" Please specifiy a valid array");
                v(a);
                this.Mb = null == a ? null : new b(a);
                this.Sc = null;
                this.ma = this.Mb;
                this.jB()
            },
            Oq: function() {
                if (!this.Mb) {
                    if (this.Sc) throw new m("This Subscription was initiated using a field schema, use getFieldSchema instead of using getFields");
                    throw new m("The field list/field schema of this Subscription was not initiated");
                }
                return this.Mb.Vc()
            },
            Xn: function(b) {
                this.xb();
                this.Mb = null;
                this.ma = this.Sc = null == b ? null : new a(b)
            },
            Lw: function() {
                if (!this.Sc) {
                    if (this.Mb) throw new m("This Subscription was initiated using a field list, use getFields instead of using getFieldSchema");
                    throw new m("The field list/field schema of this Subscription was not initiated");
                }
                return this.Sc.Vc()
            },
            nj: function() {
                return this.pd
            },
            Sh: function(a) {
                this.xb();
                this.Ni = a;
                w.logDebug(t.resolve(415), this, a)
            },
            Iw: function() {
                return this.Ni
            },
            xk: function(a) {
                this.xb();
                this.vi = a;
                w.logDebug(t.resolve(416), this, a)
            },
            ox: function() {
                return this.vi
            },
            Vh: function(a) {
                a && (a = new String(a), a = a.toLowerCase());
                var b = this.mb;
                if (this.Bd()) {
                    if (!a && 0 != a) throw new m("Can't change the frequency from/to 'unfiltered' or to null while the Subscription is active");
                    if ("unfiltered" == a || "unfiltered" == this.mb) throw new m("Can't change the frequency from/to 'unfiltered' or to null while the Subscription is active");
                }
                if (a || 0 == a)
                    if ("unfiltered" == a || "unlimited" == a) this.mb = a;
                    else try {
                        this.mb = this.checkPositiveNumber(a, !1, !0)
                    } catch (c) {
                        throw new l("The given value is not valid for this setting; use null, 'unlimited', 'unfiltered' or a positive number instead");
                    } else this.mb = null;
                if ((this.ry() || this.Br() || this.Af()) && String(b) != String(this.mb) && (this.g.ld(this, this.Jq()), 3 == this.behavior)) {
                    var g = this;
                    this.Od.forEachElement(function(a) {
                        r.verifyOk(g.Af(), "Table not pushing");
                        a.Vh(g.mb)
                    })
                }
                w.logDebug(t.resolve(417), this,
                    this.mb)
            },
            mx: function() {
                return this.mb
            },
            wk: function(a) {
                this.xb();
                if (a || 0 == a)
                    if (a = new String(a), a = a.toLowerCase(), "unlimited" == a) this.Fe = a;
                    else try {
                        this.Fe = this.checkPositiveNumber(a)
                    } catch (b) {
                        throw new l("The given value is not valid for this setting; use null, 'unlimited' or a positive number instead");
                    } else this.Fe = null;
                w.logDebug(t.resolve(418), this, this.Fe)
            },
            lx: function() {
                return this.Fe
            },
            $n: function(a) {
                this.xb();
                if (a || 0 == a)
                    if (a = new String(a), a = a.toLowerCase(), "no" == a) this.tc = a;
                    else {
                        if (this.pd ==
                            k.Wk) throw new m("Snapshot is not permitted if RAW was specified as mode");
                        if ("yes" == a) this.tc = a;
                        else {
                            if (isNaN(a)) throw new l("The given value is not valid for this setting; use null, 'yes', 'no' or a positive number instead");
                            if (this.pd != k.Sk) throw new m("Numeric values are only allowed when the subscription mode is DISTINCT");
                            try {
                                this.tc = this.checkPositiveNumber(a)
                            } catch (b) {
                                throw new l("The given value is not valid for this setting; use null, 'yes', 'no' or a positive number instead");
                            }
                        }
                    }
                else this.tc =
                    null;
                w.logDebug(t.resolve(419), this, this.tc)
            },
            nx: function() {
                return this.tc
            },
            MA: function(a) {
                this.xb();
                this.Rn();
                if (!u.isArray(a)) throw new l(" Please specifiy a valid array");
                v(a);
                this.Nd = null == a ? null : new b(a);
                this.Le = null;
                this.Zh = this.Nd;
                this.ys()
            },
            yw: function() {
                if (!this.Nd) {
                    if (this.Le) throw new m("The second level of this Subscription was initiated using a field schema, use getCommandSecondLevelFieldSchema instead of using getCommandSecondLevelFields");
                    throw new m("The second level of this Subscription was not initiated");
                }
                return this.Nd.Vc()
            },
            LA: function(b) {
                this.xb();
                this.Rn();
                this.Nd = null;
                this.Zh = this.Le = null == b ? null : new a(b);
                this.ys()
            },
            xw: function() {
                if (!this.Le) {
                    if (this.Nd) throw new m("The second level of this Subscription was initiated using a field list, use getCommandSecondLevelFields instead of using getCommandSecondLevelFieldSchema");
                    throw new m("The second level of this Subscription was not initiated");
                }
                return this.Le.Vc()
            },
            KA: function(a) {
                this.xb();
                this.Rn();
                this.Bo = a;
                w.logDebug(t.resolve(420), this, a)
            },
            ww: function() {
                return this.Bo
            },
            getValue: function(a, b) {
                return this.ue.get(this.Bt(a), this.At(b))
            },
            zw: function(a, b, c) {
                this.Nl();
                return this.bd.get(this.Bt(a) + " " + b, this.At(c, !0))
            },
            Zq: function() {
                this.Nl();
                if (!this.Sc && this.Mb) throw new m("This Subscription was initiated using a field list, key field is always 'key'");
                if (null == this.keyCode) throw new m("The position of the key field is currently unknown");
                return this.keyCode
            },
            Kq: function() {
                this.Nl();
                if (!this.Sc && this.Mb) throw new m("This Subscription was initiated using a field list, command field is always 'command'");
                if (null == this.fb) throw new m("The position of the command field is currently unknown");
                return this.fb
            },
            At: function(a, b) {
                var c = this.ei(a, this.ma, b);
                if (null === c) throw new l("the specified field does not exist");
                if (!1 === c) throw new l("the specified field position is out of bounds");
                return c
            },
            Bt: function(a) {
                a = this.ei(a, this.Ub);
                if (null === a) throw new l("the specified item does not exist");
                if (!1 === a) throw new l("the specified item position is out of bounds");
                return a
            },
            ei: function(a, b, c) {
                a = isNaN(a) ? b.oe(a) :
                    a;
                return null == a ? null : 0 >= a || a > (c ? b.ym() : b.wb) ? !1 : a
            },
            ys: function() {
                this.behavior = null == this.Zh ? 2 : 3
            },
            Rv: function(a) {
                this.dispatchEvent("onEndOfSnapshot", [this.Ub.getName(a), a])
            },
            lv: function(a) {
                var b = this.Ub.getName(a);
                2 == this.behavior ? this.bd = new e : 3 == this.behavior && (this.bd = new e, this.lA(a));
                this.dispatchEvent("onClearSnapshot", [b, a])
            },
            Fy: function(a, b) {
                this.dispatchEvent("onItemLostUpdates", [this.Ub.getName(a), a, b])
            },
            DB: function(a, b) {
                this.dispatchEvent("onCommandSecondLevelItemLostUpdates", [b, a])
            },
            EA: function(a, b) {
                this.dispatchEvent("onSubscriptionError", [a, b])
            },
            EB: function(a, b, c) {
                this.dispatchEvent("onCommandSecondLevelSubscriptionError", [a, b, c])
            },
            update: function(a, b, c) {
                r.verifyValue(4, this.ab, "Wrong table phase");
                var g = a[1],
                    e = new String(g);
                1 != this.behavior && (e = this.Sz(a, g, c));
                3 != this.behavior || c || this.Jx(a);
                1 == this.behavior ? this.Ft(this.ue, g, a, !0) : this.Ft(this.bd, e, a, !0);
                a = new f(this.Ub.getName(g), g, this.ma, b, a);
                this.dispatchEvent("onItemUpdate", [a]);
                "DELETE" == this.bd.get(e, this.fb) && this.bd.delRow(e)
            },
            Ft: function(a, b, c, g) {
                var e = c.length - 2,
                    d = 1,
                    f = 2;
                for (c.Ao = {}; d <= e; d++, f++) c[f] !== B ? a.insert(c[f], b, d) : g && (c[f] = a.get(b, d), c.Ao[f] = !0)
            },
            Sz: function(a, b, c) {
                var g;
                if ("undefined" == typeof a[this.keyCode + 1] || "undefined" == typeof a[this.fb + 1]) return w.logWarn(t.resolve(404)), null;
                g = a[this.keyCode + 1] == B ? b + " " + this.ue.get(b, this.keyCode) : b + " " + a[this.keyCode + 1];
                if (c) a[this.keyCode + 1] = B, a[this.fb + 1] == this.bd.get(g, this.fb) ? a[this.fb + 1] = B : (a.Mc.push(this.fb), a.Mc.sort(z));
                else {
                    a.Mc = [];
                    for (c = 2; c < a.length; c++) a[c] &&
                        a[c] == B ? a[c] = this.ue.get(b, c - 1) : this.ue.insert(a[c], b, c - 1), a[c] == this.bd.get(g, c - 1) ? a[c] = B : a.Mc.push(c - 1);
                    if (3 == this.behavior && (b = this.Tq() + 2, b > a.length))
                        for (c = a.length; c < b; c++) a[c] = B
                }
                return g
            },
            Jx: function(a) {
                var b = a[1],
                    c = a[this.keyCode + 1] == B ? this.ue.get(b, this.keyCode) : a[this.keyCode + 1];
                a = a[this.fb + 1];
                var g = this.lr(b, c);
                "DELETE" == a ? g && this.Ln(b, c) : g || this.Iu(b, c)
            },
            Gy: function() {
                this.wt = !0
            },
            lr: function(a, b) {
                return null !== this.Od.get(a, b)
            },
            Ln: function(a, b) {
                this.g.Hs(this.Od.get(a, b));
                this.Od.del(a,
                    b)
            },
            Iu: function(a, b) {
                var c = new q(this.PB);
                c.Gy();
                this.Od.insert(c, a, b);
                try {
                    c.Uh([b])
                } catch (g) {
                    this.dispatchEvent("onCommandSecondLevelSubscriptionError", [14, "The received key value is not a valid name for an Item", b]);
                    return
                }
                this.Nd ? c.tk(this.Nd.Vc()) : c.Xn(this.Le.Vc());
                c.Sh(this.Bo);
                c.$n("yes");
                c.mb = this.mb;
                var e = new d(this, a, b);
                c.addListener(e);
                this.g.pp(c)
            },
            kB: function(a) {
                this.Zh.Ld(a)
            },
            Tq: function() {
                return this.ma.ym()
            },
            addListener: function(a) {
                this._callSuperMethod(q, "addListener", [a])
            },
            removeListener: function(a) {
                this._callSuperMethod(q,
                    "removeListener", [a])
            },
            getListeners: function() {
                return this._callSuperMethod(q, "getListeners")
            }
        };
        q.prototype.isActive = q.prototype.Bd;
        q.prototype.isSubscribed = q.prototype.Qm;
        q.prototype.setItems = q.prototype.Uh;
        q.prototype.getItems = q.prototype.Uw;
        q.prototype.setItemGroup = q.prototype.mt;
        q.prototype.getItemGroup = q.prototype.Tw;
        q.prototype.setFields = q.prototype.tk;
        q.prototype.getFields = q.prototype.Oq;
        q.prototype.setFieldSchema = q.prototype.Xn;
        q.prototype.getFieldSchema = q.prototype.Lw;
        q.prototype.getMode =
            q.prototype.nj;
        q.prototype.setDataAdapter = q.prototype.Sh;
        q.prototype.getDataAdapter = q.prototype.Iw;
        q.prototype.setSelector = q.prototype.xk;
        q.prototype.getSelector = q.prototype.ox;
        q.prototype.setRequestedMaxFrequency = q.prototype.Vh;
        q.prototype.getRequestedMaxFrequency = q.prototype.mx;
        q.prototype.setRequestedBufferSize = q.prototype.wk;
        q.prototype.getRequestedBufferSize = q.prototype.lx;
        q.prototype.setRequestedSnapshot = q.prototype.$n;
        q.prototype.getRequestedSnapshot = q.prototype.nx;
        q.prototype.setCommandSecondLevelFields =
            q.prototype.MA;
        q.prototype.getCommandSecondLevelFields = q.prototype.yw;
        q.prototype.setCommandSecondLevelFieldSchema = q.prototype.LA;
        q.prototype.getCommandSecondLevelFieldSchema = q.prototype.xw;
        q.prototype.setCommandSecondLevelDataAdapter = q.prototype.KA;
        q.prototype.getCommandSecondLevelDataAdapter = q.prototype.ww;
        q.prototype.getValue = q.prototype.getValue;
        q.prototype.getCommandValue = q.prototype.zw;
        q.prototype.getKeyPosition = q.prototype.Zq;
        q.prototype.getCommandPosition = q.prototype.Kq;
        q.prototype.addListener =
            q.prototype.addListener;
        q.prototype.removeListener = q.prototype.removeListener;
        q.prototype.getListeners = q.prototype.getListeners;
        c(q, h, !1, !0);
        c(q, g, !0, !0);
        return q
    });
    define("Cell", ["Environment"], function(d) {
        function f(a, b) {
            this.h = a;
            this.na = !0;
            this.Yi = 0;
            b || (b = this.Bx());
            if (b)
                if (0 == b.toLowerCase().indexOf("style.")) {
                    var c = b.slice(6);
                    this.qg = e(c);
                    this.gg = p(c)
                } else this.qg = t(b), this.gg = n(b);
            else a.nodeName.toLowerCase() in u ? (this.qg = k, this.gg = h) : (this.qg = l, this.gg = m);
            this.Ng = q++;
            this.kd = 0;
            this.uc = this.vc = this.te = null;
            this.Tx = this.gg(!0);
            this.Rx = this.h.className;
            this.Sx = this.yq()
        }

        function b(b, c) {
            if (!1 === f.Ik) return a(b, c);
            if (!0 === f.Ik) return b.getAttribute(c);
            var d =
                a(b, c);
            if (d) return f.Ik = !1, d;
            if (d = b.getAttribute(c)) f.Ik = !0;
            return d
        }

        function a(a, b) {
            return a.dataset ? a.dataset[b] ? a.dataset[b] : a.getAttribute("data-" + b) : a.getAttribute("data-" + b)
        }

        function c(a, b) {
            if (!a) return b;
            for (var c in b) a[c] || null === a[c] || "" === a[c] || (a[c] = b[c]);
            return a
        }

        function g(a) {
            return (a = b(a, "source")) && "lightstreamer" == a.toLowerCase()
        }

        function e(a) {
            return function(b) {
                this.h.style[a] = "\u00a0" === b ? null : b
            }
        }

        function p(a) {
            return function() {
                return this.h.style[a] || ""
            }
        }

        function k(a) {
            this.h.value =
                a && "\u00a0" !== a ? a : ""
        }

        function h() {
            return this.h.value
        }

        function l(a, b) {
            b ? this.h.innerHTML = a : 1 != this.h.childNodes.length || 3 != this.h.firstChild.nodeType ? (null != this.h.firstChild && (this.h.innerHTML = ""), this.h.appendChild(document.createTextNode(a))) : this.h.firstChild.nodeValue = a
        }

        function m(a) {
            return a ? this.h.innerHTML : this.h.firstChild ? this.h.firstChild.nodeValue : ""
        }

        function t(a) {
            return "value" === a ? k : function(b) {
                b && "\u00a0" !== b ? this.h.setAttribute(a, b) : this.h.removeAttribute(a)
            }
        }

        function n(a) {
            return "value" ===
                a ? h : function() {
                    return this.h.getAttribute(a)
                }
        }
        d.browserDocumentOrDie();
        var r = {
                extra: !0,
                "first-level": !0,
                "second-level": !0
            },
            u = {
                input: !0,
                textarea: !0
            },
            q = 0;
        f.wC = 1;
        f.ii = 2;
        f.Rt = "first-level";
        f.bu = "second-level";
        f.Ik = null;
        f.mj = function(a, b) {
            var c = [];
            b || (b = ["*"]);
            for (var d = 0; d < b.length; d++)
                for (var e = a.getElementsByTagName(b[d]), h = 0; h < e.length; h++) g(e[h]) && c.push(new f(e[h]));
            return c
        };
        f.It = g;
        f.Cd = function(a) {
            for (var b = null; null != a && a != document;) b = a, a = a.parentNode;
            return null == a ? null != b && "HTML" == b.nodeName ?
                !0 : !1 : !0
        };
        f.prototype = {
            Qn: function(a, b) {
                this.qg(a.gg(), b);
                this.te = a.te;
                this.vc = a.vc;
                this.uc = a.uc;
                this.kd = a.kd;
                this.rk(a.yq());
                this.Do(a.h.className);
                this.Yi = a.Yi
            },
            gh: function() {
                return this.h
            },
            yq: function() {
                var a = {},
                    b;
                for (b in this.h.style) a[b] = this.h.style[b];
                return a
            },
            Do: function(a) {
                null !== a && this.h.className != a && (this.h.className = a)
            },
            rk: function(a) {
                if (a)
                    for (var b in a) {
                        "CLASS" == b && this.Do(a[b]);
                        try {
                            null !== a[b] && (this.h.style[b] = a[b])
                        } catch (c) {}
                    }
            },
            ae: function(a, b) {
                a == this.kd && (1 == b ? (this.rk(this.vc),
                    this.vc = null) : (this.rk(this.uc), this.uc = null))
            },
            be: function(a, b) {
                a == this.kd && (this.qg(this.te, b), this.te = null, this.ae(a, 1))
            },
            vB: function() {
                this.kd++;
                return this.kd
            },
            sf: function() {
                var a = b(this.h, "field");
                return a ? a : null
            },
            Pb: function() {
                var a = b(this.h, "replica");
                return a ? a : null
            },
            Nq: function() {
                var a = b(this.h, "fieldtype");
                if (!a) return "first-level";
                a = a.toLowerCase();
                return r[a] ? a : "first-level"
            },
            ir: function() {
                return b(this.h, "grid")
            },
            getRow: function() {
                var a = b(this.h, "item");
                a || (a = b(this.h, "row"));
                return a
            },
            Bx: function() {
                return b(this.h, "update")
            },
            Jm: function() {
                return ++this.Yi
            },
            wm: function() {
                return this.Yi
            },
            zr: function(a) {
                return a.h === this.h
            },
            Cd: function() {
                return f.Cd(this.h)
            },
            rr: function() {
                return this.h.id ? document.getElementById(this.h.id) === this.h : this.Cd(this.h)
            },
            Zn: function(a) {
                this.te = "" === a ? "\u00a0" : a
            },
            Gg: function(a, b, c) {
                this.vc || (this.vc = {});
                this.uc || (this.uc = {});
                this.vc[c] = a || "";
                this.uc[c] = b || ""
            },
            bx: function(a) {
                a && (this.vc = c(this.vc, a));
                return this.vc
            },
            ax: function(a) {
                a && (this.uc = c(this.uc, a));
                return this.uc
            },
            clean: function() {
                this.qg(this.Tx, !0);
                this.Do(this.Rx);
                this.rk(this.Sx)
            }
        };
        return f
    });
    define("CellMatrix", ["Matrix", "Inheritance", "Cell"], function(d, f, b) {
        function a(b) {
            this._callSuperConstructor(a, [b])
        }

        function c(a, c) {
            var d = new b(document.createElement("p"));
            d.Qn(a, c);
            var g = a.Pb();
            d.Pb = function() {
                return g
            };
            return d
        }

        function g(a) {
            if (a.na) a.clean();
            else
                for (var b = 0; b < a.length; b++) a[b].clean()
        }
        a.jg = function(a, b, d) {
            var f = {},
                l;
            for (l in a) f[l] = !0;
            if (b)
                for (l in b) f[l] = !0;
            else b = {};
            for (var m in f)
                if (a[m])
                    if (b[m])
                        if (b[m].na && a[m].na) b[m].Qn(a[m], d);
                        else {
                            f = a[m].na ? [a[m]] : a[m];
                            b[m].na && (b[m] = [b[m]]);
                            l = [].concat(b[m]);
                            for (var t = 0; t < f.length; t++) {
                                for (var n = !1, r = 0; r < l.length; r++)
                                    if (l[r].Pb() === f[t].Pb()) {
                                        l[r].Qn(f[t], d);
                                        n = !0;
                                        l.splice(r, 1);
                                        break
                                    } n || b[m].push(c(f[t], d))
                            }
                            g(l)
                        }
            else {
                f = b;
                l = m;
                t = a[m];
                n = d;
                if (t.na) t = c(t, n);
                else {
                    for (var r = [], u = 0; u < t.length; u++) r[u] = c(t[u], n);
                    t = r
                }
                f[l] = t
            } else g(b[m]);
            return b
        };
        a.prototype = {
            Lu: function(a) {
                var b = this.qf(a.getRow(), a.sf());
                if (!b) return !1;
                if (b.na) return b.zr(a);
                for (var c = 0; c < b.length; c++)
                    if (b[c].zr(a)) return !0;
                return !1
            },
            addCell: function(a, b, c) {
                b = b || a.getRow();
                c = c || a.sf();
                var d = this.qf(b, c);
                d ? d.na ? this.insert([d, a], b, c) : d.push(a) : this.insert(a, b, c)
            },
            gw: function(a) {
                var b = this;
                this.forEachElement(function(c, d, g) {
                    b.pm(c, d, g, a)
                })
            },
            Dq: function(a, b) {
                var c = this;
                this.forEachElementInRow(a, function(a, d, e) {
                    c.pm(a, d, e, b)
                })
            },
            hw: function(a, b, c) {
                var d = this.get(a, b);
                d && this.pm(d, a, b, c)
            },
            pm: function(a, b, c, d) {
                if (a.na) d(a, b, c);
                else
                    for (var g = 0; g < a.length; g++) d(a[g], b, c, a[g].Pb())
            },
            qf: function(a, b, c) {
                if (c) {
                    if (a = this.get(a, b))
                        if (!a.na)
                            for (b = 0; b < a.length; b++) {
                                if (a[b].Pb() ==
                                    c) return a[b]
                            } else if (a.Pb() == c) return a;
                    return null
                }
                return this.get(a, b)
            },
            Xu: function() {
                var a = this.getEntireMatrix(),
                    b;
                for (b in a) {
                    var c = a[b],
                        d = !1,
                        g = void 0;
                    for (g in c) {
                        var f;
                        f = c[g];
                        if (f.na) f = f.rr();
                        else {
                            for (var t = !1, n = 0; n < f.length;) f[n].rr() ? (t = !0, n++) : f.splice(n, 1);
                            f = t
                        }
                        f ? d = !0 : delete c[g]
                    }
                    d || delete a[b]
                }
            }
        };
        f(a, d, !1, !0);
        return a
    });
    define("ColorConverter", ["Environment", "LoggerManager", "BrowserDetection", "IFrameHandler"], function(d, f, b, a) {
        function c(a) {
            0 == a.indexOf("#") && (a = a.substring(1, a.length));
            if (3 == a.length) a = a.charAt(0) + a.charAt(0) + a.charAt(1) + a.charAt(1) + a.charAt(2) + a.charAt(2);
            else if (6 != a.length) return m.warn("A hexadecimal color value must be 3 or 6 character long. An invalid value was specified, will be ignored"), null;
            var b = a.substring(2, 4),
                c = a.substring(4, 6);
            a = e(a.substring(0, 2));
            b = e(b);
            c = e(c);
            return null == a || null ==
                b || null == c ? null : [a, b, c]
        }

        function g(a) {
            if (0 <= a && 9 >= a) return new Number(a);
            a = a.toUpperCase();
            if (t[a]) return t[a];
            m.warn("A hexadecimal number must contain numbers between 0 and 9 and letters between A and F. An invalid value was specified, will be ignored");
            return null
        }

        function e(a) {
            var b = 0,
                c = 0,
                d;
            for (d = a.length; 1 <= d; d--) {
                var e = g(a.substring(d - 1, d));
                if (null == e) return null;
                var f;
                for (f = 1; f <= c; f++) e *= 16;
                c++;
                b += e
            }
            return b
        }

        function p(a) {
            if (a.indexOf("%") == a.length - 1) {
                a = parseFloat(a.substring(0, a.length - 1));
                if (100 < a || 0 > a) return m.warn("A RGB element must be a number \x3e\x3d0 and \x3c\x3d255 or a percentile \x3e\x3d0 and \x3c\x3d100. An invalid value was specified, will be ignored"), null;
                a *= 2.55
            }
            return a
        }

        function k(a, b) {
            return a && "" != a ? b ? a != b ? !0 : !1 : !0 : !1
        }

        function h(a) {
            var b = document.createElement("DIV");
            b.style.backgroundColor = a;
            var c = q.kh(b, n, a);
            if (null == c) return null;
            if (255 == c[0] && 255 == c[1] && 255 == c[2] && "WHITE" != a.toUpperCase()) {
                var d = document.getElementsByTagName("BODY")[0];
                d && (d.appendChild(b), c =
                    q.kh(b, n, a), d.removeChild(b))
            }
            r[a] = c;
            return r[a]
        }

        function l(d) {
            var e = "";
            if (r[d]) return r[d];
            if (b.isProbablyIE()) try {
                if (u = a.getFrameWindow("weswit__ColorFrame", !0)) u.document.bgColor = d, e = u.document.bgColor
            } catch (g) {
                e = null
            } else return h(d);
            if (!e || e == d) {
                var f = document.bgColor;
                document.bgColor = d;
                e = document.bgColor;
                document.bgColor = f
            }
            if (!e || e == d) return h(d);
            r[d] = c(e);
            return r[d]
        }
        d.browserDocumentOrDie();
        var m = f.getLoggerProxy("lightstreamer.grids"),
            t = {
                A: 10,
                B: 11,
                C: 12,
                D: 13,
                E: 14,
                F: 15
            },
            n = "backgroundColor",
            r = {},
            u = null,
            q = {
                yo: function(a) {
                    if (0 == a.indexOf("rgb")) a: {
                        var b, d;
                        if (0 == a.indexOf("rgb(")) b = 4,
                        d = ")";
                        else if (0 == a.indexOf("rgba(")) b = 5,
                        d = ",";
                        else {
                            m.warn("A RGB color value must be in the form 'rgb(x, y, z)' or 'rgba(x, y, z, a)'. An invalid value was specified, will be ignored");
                            a = null;
                            break a
                        }
                        a = a.substring(b, a.length);
                        var e = a.indexOf(",");b = p(a.substring(0, e));
                        var g = a.indexOf(",", e + 1),
                            e = p(a.substring(e + 1, g));a = p(a.substring(g + 1, a.indexOf(d, g + 1)));a = null == b || null == e || null == a ? null : [b, e, a]
                    }
                    else a = 0 == a.indexOf("#") ?
                        c(a) : l(a);
                    return a
                },
                kh: function(a, b, c) {
                    if (null == a) return [255, 255, 255];
                    var d = "";
                    try {
                        if (window.getComputedStyle || document.defaultView && document.defaultView.getComputedStyle) {
                            var e = document.defaultView.getComputedStyle(a, null);
                            if (e) var g = b == n ? "background-color" : b,
                                d = e.getPropertyValue(g)
                        }
                    } catch (f) {}
                    try {
                        !k(d, c) && a.currentStyle && (g = "background-color" == b ? n : b, d = a.currentStyle[g])
                    } catch (f) {}
                    try {
                        if (!k(d, c))
                            if (e = "background-color" == b ? n : b, "" != a.style[e]) d = a.style[e];
                            else return [255, 255, 255]
                    } catch (f) {}
                    return "transparent" ==
                        d && a.parentNode ? this.kh(a.parentNode, b) : "transparent" == d ? [255, 255, 255] : k(d, c) ? this.yo(d) : [255, 255, 255]
                }
            };
        return q
    });
    define("FadersHandler", ["ColorConverter", "Executor", "Helpers", "Cell", "Environment"], function(d, f, b, a, c) {
        function g(a, b, c, d, e, g, f) {
            this.Xc(a, b, c, d, e, g, f)
        }

        function e() {
            this.length = 0;
            this.us = {}
        }

        function p(a) {
            this.ud = a;
            this.hj = new e;
            this.Aq = 0;
            this.lf = {};
            this.Zi = !1;
            this.ed = {}
        }

        function k(a) {
            return function() {
                a.style.backgroundColor = "transparent"
            }
        }
        c.browserDocumentOrDie();
        p.prototype = {
            Cm: function(a, b, c, d, e, f) {
                e = this.Sw(e);
                var k = a.Jm();
                if (k) {
                    var q = this.hj.get();
                    if (null == q) return this.lf[this.Aq] = new g(a,
                        b, c, d, e, k, f), this.Aq++;
                    this.lf[q].Xc(a, b, c, d, e, k, f);
                    return q
                }
            },
            Sw: function(a) {
                a /= this.ud;
                return 1 < a ? a : 1
            },
            Vm: function(a) {
                var b = this.lf[a],
                    c = b.Lc.wm();
                if (!c) this.Dk(b.Lc);
                else if (!(b.a < c)) {
                    var c = this.ed[b.Lc.Ng],
                        e = this.lf[c];
                    e && (e.jr || (b.jr ? e.kf && f.executeTask(e.kf) : (b.za = e.za, b.Fa < e.Fa && (b.Fa = e.Fa))), this.hj.put(c));
                    this.ed[b.Lc.Ng] = a;
                    b.jf && (b.ng = d.kh(b.Lc.gh(), "backgroundColor"));
                    b.$g && (b.jo = d.kh(b.Lc.gh(), "color"));
                    this.Zi || this.$v(this.ud)
                }
            },
            Dk: function(a) {
                var b = this.ed[a.Ng];
                if (b || 0 == b) delete this.ed[a.Ng],
                    this.hj.put(b)
            },
            Mv: function(a) {
                var c = b.getTimeStamp(),
                    d = 0;
                a && (d = c - (a + this.ud));
                a = !1;
                for (var e in this.ed) {
                    var g = this.ed[e],
                        r = this.lf[g];
                    if (r.za > r.Fa) this.hj.put(g), delete this.ed[e], r.kf && f.addPackedTimedTask(r.kf, 0);
                    else {
                        g = r.Lc.gh();
                        if (!g) {
                            this.Dk(r.Lc);
                            continue
                        }
                        if ("transparent" == r.jf) try {
                            g.style.backgroundColor = "rgba(" + r.ng[0] + "," + r.ng[1] + "," + r.ng[2] + "," + this.ke(100, 0, r.Fa, r.za) / 100 + ")"
                        } catch (q) {
                            var u = (r.Fa - r.za) * this.ud;
                            f.addTimedTask(k(g), u);
                            r.kf && f.addPackedTimedTask(r.kf, u);
                            this.Dk(r.Lc);
                            continue
                        } else r.jf &&
                            (g.style.backgroundColor = "rgb(" + this.ke(r.ng[0], r.jf[0], r.Fa, r.za) + "," + this.ke(r.ng[1], r.jf[1], r.Fa, r.za) + "," + this.ke(r.ng[2], r.jf[2], r.Fa, r.za) + ")");
                        r.$g && (g.style.color = "rgb(" + this.ke(r.jo[0], r.$g[0], r.Fa, r.za) + "," + this.ke(r.jo[1], r.$g[1], r.Fa, r.za) + "," + this.ke(r.jo[2], r.$g[2], r.Fa, r.za) + ")");
                        a = !0
                    }
                    r.za++
                }
                a ? (e = b.getTimeStamp(), c = e - c + d, c > this.ud && (d = c / this.ud, c = Math.floor(d), d -= c, this.gA(c), c = this.ud * d), this.Nr(this.ud - c, e)) : this.Zi = !1
            },
            Nr: function(a, b) {
                f.addTimedTask(this.Mv, a, this, [b])
            },
            gA: function(a) {
                for (var b in this.ed) {
                    var c =
                        this.lf[this.ed[b]];
                    c.za > c.Fa || (c.za = c.za + a < c.Fa ? c.za + a : c.Fa)
                }
            },
            $v: function(a) {
                1 != this.Zi && (this.Zi = !0, this.Nr(a))
            },
            ke: function(a, b, c, d) {
                a = new Number(a);
                b = new Number(b);
                return Math.ceil(a + 1 / c * d * (b - a))
            }
        };
        e.prototype = {
            put: function(a) {
                this.us[this.length] = a;
                this.length++
            },
            get: function() {
                if (0 >= this.length) return null;
                this.length--;
                return this.us[this.length]
            }
        };
        g.prototype = {
            Xc: function(a, b, c, e, g, f, k) {
                this.kf = k ? k : null;
                this.jr = b;
                this.Lc = a;
                this.jf = "" === c || "transparent" == c ? "transparent" : c ? d.yo(c) : null;
                this.$g =
                    e ? d.yo(e) : null;
                this.Fa = g;
                this.a = f;
                this.za = 0
            }
        };
        return p
    });
    define("LightstreamerConstants", [], function() {
        return {
            CONNECTING: "CONNECTING",
            Ra: "CONNECTED:",
            xg: "STREAM-SENSING",
            Bg: "WS-STREAMING",
            Xd: "HTTP-STREAMING",
            yg: "STALLED",
            Zd: "WS-POLLING",
            ec: "HTTP-POLLING",
            Db: "DISCONNECTED",
            Ag: "DISCONNECTED:WILL-RETRY",
            zg: "DISCONNECTED:TRYING-RECOVERY",
            pi: "WS",
            Qe: "HTTP",
            Wk: "RAW",
            Sk: "DISTINCT",
            ug: "COMMAND",
            Vk: "MERGE"
        }
    });
    define("DoubleKeyMatrix", ["Inheritance", "Matrix"], function(d, f) {
        function b() {
            this._callSuperConstructor(b);
            this.Lh = {}
        }
        b.prototype = {
            insert: function(a, c, d) {
                "undefined" == typeof this.Lh[d] && (this.Lh[d] = c, this._callSuperMethod(b, "insert", [a, c, d]))
            },
            del: function(a, c) {
                this._callSuperMethod(b, "del", [a, c]);
                delete this.Lh[c]
            },
            delReverse: function(a) {
                var b = this.Lh[a];
                "undefined" != typeof b && this.del(b, a)
            },
            delRow: function(a) {
                var c = this.getRow(a),
                    d;
                for (d in c) delete this.Lh[d];
                this._callSuperMethod(b, "delRow", [a])
            }
        };
        b.prototype.insert = b.prototype.insert;
        b.prototype.del = b.prototype.del;
        b.prototype.delReverse = b.prototype.delReverse;
        b.prototype.delRow = b.prototype.delRow;
        d(b, f);
        return b
    });
    define("AbstractWidget", "Inheritance Matrix LoggerManager Setter EventDispatcher IllegalStateException LightstreamerConstants DoubleKeyMatrix".split(" "), function(d, f, b, a, c, g, e, p) {
        function k(a) {
            this._callSuperConstructor(k);
            this.kind = "ITEM_IS_KEY";
            this.Ol = this.Aj = null;
            this.kd = 0;
            this.nm = null;
            this.values = new f;
            this.parsed = !1;
            this.id = a;
            this.useSynchEvents(!0);
            this.Rp = this.Qp = !1;
            this.xi = 0;
            this.If = null;
            this.rm = !1;
            this.Rd = null;
            this.Ek = [];
            this.Nb = [];
            this.bh = {};
            this.Tc = this.bj = 0;
            this.zj = new p
        }
        var h = b.getLoggerProxy("lightstreamer.grids");
        k.Vo = "ITEM_IS_KEY";
        k.du = "UPDATE_IS_KEY";
        k.prototype = {
            ha: function() {
                return this.id
            },
            Dl: function() {
                if (!this.parsed) throw new g("Please parse html before calling this method");
            },
            onItemUpdate: function(a) {
                var b = a.Bm(),
                    c = a.lj();
                this.kd++;
                var c = null == b ? c : b,
                    b = this.yy() ? c : this.xa() ? this.kd : c + " " + a.getValue(this.Aj),
                    d = {};
                this.xa() ? a.Eq(this.Qq(d)) : a.forEachChangedField(this.Qq(d));
                this.Er() && "DELETE" == d[this.Ol] ? this.removeRow(b) : (this.updateRow(b, d), this.zj.insert(!0, c, b))
            },
            onClearSnapshot: function(a, b) {
                var c =
                    null == a ? b : a,
                    d = this.zj.getRow(c);
                this.zj.delRow(c);
                for (var e in d) this.removeRow(e)
            },
            onSubscription: function() {
                0 == this.xi && this.Qp && this.clean();
                this.Er() && !this.Aj && (this.Aj = this.If.Zq(), this.Ol = this.If.Kq());
                this.xi++
            },
            onUnsubscription: function() {
                this.xi--;
                0 == this.xi && this.Rp && this.clean()
            },
            onListenStart: function(a) {
                this.If || (this.If = a, this.rm || this.Np());
                if (a.Qm()) this.onSubscription()
            },
            onListenEnd: function(a) {
                if (a.Qm()) this.onUnsubscription()
            },
            Np: function() {
                if (this.If) {
                    var a = this.If;
                    if (a.nj() ==
                        e.Vk || a.nj() == e.Wk) this.kind = "ITEM_IS_KEY";
                    else if (a.nj() == e.Sk) this.kind = "UPDATE_IS_KEY";
                    else {
                        this.kind = "KEY_IS_KEY";
                        try {
                            a.Oq(), this.Aj = "key", this.Ol = "command"
                        } catch (b) {}
                    }
                } else this.kind = "ITEM_IS_KEY"
            },
            Qq: function(a) {
                var b = this;
                return function(c, d, e) {
                    null === b.nm && (b.nm = null == c);
                    a[b.nm ? d : c] = e
                }
            },
            yy: function() {
                return "ITEM_IS_KEY" == this.kind
            },
            xa: function() {
                return "UPDATE_IS_KEY" == this.kind
            },
            Er: function() {
                return "KEY_IS_KEY" == this.kind
            },
            cr: function() {
                return this.Tc >= this.Nb.length ? null : this.Nb[this.Tc]
            },
            Js: function(a) {
                var b = this.bh[a];
                delete this.bh[a];
                this.Nb[b] = null;
                this.bj++;
                if (b == this.Tc) {
                    for (; null === this.Nb[this.Tc] && this.Tc < this.Nb.length;) this.Tc++;
                    if (this.Tc >= this.Nb.length) {
                        this.Nb = [];
                        this.bh = {};
                        this.Tc = this.bj = 0;
                        return
                    }
                }
                if (100 <= this.bj)
                    for (this.bh = {}, a = this.Nb, this.Nb = [], b = this.bj = this.Tc = 0; b < a.length; b++) null !== a[b] && this.Mr(a[b])
            },
            Mr: function(a) {
                this.bh[a] = this.Nb.length;
                this.Nb.push(a)
            },
            removeRow: function(a) {
                this.Dl();
                if (this.Rd) this.Dv(a);
                else if (this.values.getRow(a)) {
                    h.isDebugLogEnabled() &&
                        h.logDebug(b.resolve(465), a, this);
                    this.Rd = {};
                    var c = null;
                    try {
                        this.removeRowExecution(a), this.values.delRow(a), this.zj.delReverse(a), this.xa() && this.Js(a)
                    } catch (d) {
                        c = d
                    }
                    this.Rd = null;
                    this.jq();
                    if (null !== c) throw c;
                } else h.logWarn(b.resolve(463), a, this)
            },
            Dt: function(a, c) {
                h.isDebugLogEnabled() && h.logDebug(b.resolve(466), this);
                this.Ek.push({
                    type: 2,
                    key: a,
                    hz: c
                })
            },
            Dv: function(a) {
                h.isDebugLogEnabled() && h.logDebug(b.resolve(467), this);
                this.Ek.push({
                    type: 1,
                    key: a
                })
            },
            jq: function() {
                for (; 0 < this.Ek.length;) {
                    var a = this.Ek.shift();
                    1 == a.type ? this.removeRow(a.key) : this.updateRow(a.key, a.hz)
                }
            },
            updateRow: function(a, c) {
                this.Dl();
                if (this.Rd) a == this.Rd ? this.mergeUpdate(a, c) : this.Dt(a, c);
                else {
                    this.Rd = a;
                    var d = null;
                    try {
                        if (this.updateRowExecution(a, c), this.values.getRow(a)) {
                            h.isDebugLogEnabled() && h.logDebug(b.resolve(469), a, this);
                            for (var e in c) this.values.insert(c[e], a, e)
                        } else h.isDebugLogEnabled() && h.logDebug(b.resolve(468), a, this), this.xa() && this.Mr(a), this.values.insertRow(c, a)
                    } catch (g) {
                        d = g
                    }
                    this.Rd = null;
                    this.jq();
                    if (null !== d) throw d;
                }
            },
            clean: function() {
                h.logInfo(b.resolve(464), this);
                var a = [];
                this.values.forEachRow(function(b) {
                    a.push(b)
                });
                for (var c = 0; c < a.length; c++) this.removeRow(a[c])
            },
            getValue: function(a, b) {
                return this.values.get(a, b)
            },
            setAutoCleanBehavior: function(a, b) {
                this.Qp = this.checkBool(a);
                this.Rp = this.checkBool(b)
            },
            parseHtml: function() {},
            updateRowExecution: function() {},
            removeRowExecution: function() {},
            mergeUpdate: function() {}
        };
        k.prototype.onItemUpdate = k.prototype.onItemUpdate;
        k.prototype.onClearSnapshot = k.prototype.onClearSnapshot;
        k.prototype.onSubscription = k.prototype.onSubscription;
        k.prototype.onUnsubscription = k.prototype.onUnsubscription;
        k.prototype.onListenStart = k.prototype.onListenStart;
        k.prototype.onListenEnd = k.prototype.onListenEnd;
        k.prototype.removeRow = k.prototype.removeRow;
        k.prototype.updateRow = k.prototype.updateRow;
        k.prototype.clean = k.prototype.clean;
        k.prototype.getValue = k.prototype.getValue;
        k.prototype.setAutoCleanBehavior = k.prototype.setAutoCleanBehavior;
        k.prototype.parseHtml = k.prototype.parseHtml;
        k.prototype.updateRowExecution =
            k.prototype.updateRowExecution;
        k.prototype.removeRowExecution = k.prototype.removeRowExecution;
        k.prototype.mergeUpdate = k.prototype.mergeUpdate;
        d(k, c, !1, !0);
        d(k, a, !0, !0);
        return k
    });
    define("AbstractGrid", "Inheritance CellMatrix Executor Cell Helpers FadersHandler AbstractWidget IllegalArgumentException IllegalStateException LoggerManager Environment".split(" "), function(d, f, b, a, c, g, e, p, k, h, l) {
        function m() {
            this._callSuperConstructor(m, arguments);
            this.Ga = !1;
            this.bi = t;
            this.Ic = !1;
            this.v = null;
            this.Ml = this.Rj = this.Xg = !1;
            this.Rc = new g(50);
            this.Wg = this.Vg = null;
            this.j = this.l = 0;
            this.P = new f
        }
        l.browserDocumentOrDie();
        var t = ["div", "span", "input"],
            n = h.getLoggerProxy("lightstreamer.grids");
        m.prototype = {
            mergeUpdate: function(a, b) {
                n.isDebugLogEnabled() && n.logDebug(h.resolve(471), this);
                for (var c in b) this.Wg[c] = b[c];
                this.om(this.Vg, b)
            },
            om: function(a, b) {
                for (var c in b) this.P.hw(a, c, function(d) {
                    n.isDebugLogEnabled() && n.logDebug(h.resolve(472), a, c);
                    var e = b[c];
                    d.Zn(null === e ? "" : e)
                })
            },
            qe: function(a, b) {
                return null != a && null != b || a == b ? this.Xg ? a > b : a < b : null == a ? !this.Xg : this.Xg
            },
            setHtmlInterpretationEnabled: function(a) {
                this.Ga = this.checkBool(a)
            },
            isHtmlInterpretationEnabled: function() {
                return this.Ga
            },
            setNodeTypes: function(a) {
                if (a && 0 < a.length) this.bi = a;
                else throw new p("The given array is not valid or empty");
            },
            getNodeTypes: function() {
                return this.bi
            },
            setAddOnTop: function(a) {
                null != this.v && n.logWarn(h.resolve(470));
                this.Ic = this.checkBool(a)
            },
            isAddOnTop: function() {
                return this.Ic
            },
            setSort: function(a, b, c, d) {
                a ? (this.v = a, this.Xg = this.checkBool(b, !0), this.Rj = this.checkBool(c, !0), this.Ml = this.checkBool(d, !0), this.zk()) : this.v = null
            },
            getSortField: function() {
                return this.v
            },
            isDescendingSort: function() {
                return null ===
                    this.v ? null : this.Xg
            },
            isNumericSort: function() {
                return null === this.v ? null : this.Rj
            },
            isCommaAsDecimalSeparator: function() {
                return null !== this.v && this.Rj ? this.Ml : null
            },
            extractFieldList: function() {
                return this.zq(a.Rt)
            },
            extractCommandSecondLevelFieldList: function() {
                return this.zq(a.bu)
            },
            parseHtml: function() {},
            forceSubscriptionInterpretation: function(a) {
                if (0 < this.l) throw new k("This method can only be called while the grid is empty.");
                if (a) {
                    if (a != e.du && a != e.Vo) throw new p("The given value is not valid, use UPDATE_IS_KEY or ITEM_IS_KEY.");
                    this.kind = a;
                    this.rm = !0
                } else this.rm = !1, this.Np()
            },
            zq: function(a) {
                a = this.Pl(a);
                var b = [],
                    c;
                for (c in a) b.push(c);
                return b
            },
            jb: function(a) {
                return this.Rj ? c.getNumber(a, this.Ml) : null === a ? a : (new String(a)).toUpperCase()
            },
            Jt: function(c, d, e) {
                e = e || c;
                var g = d.Vp,
                    f = g + d.nr,
                    h = f + d.vf,
                    k = d.tj,
                    l = d.Ll,
                    n = [];
                c = this.P.getRow(c);
                for (var t in c)
                    for (var m = -1, p = c[t], F = 0; p && (p.na || F < p.length); F++) {
                        var x = p.na ? p : p[F],
                            p = p.na ? null : p;
                        null === x.Pb() && m++;
                        var A = this.hr ? this.hr(x, e, t, x.Pb(), m) : x;
                        if (null != x.te) {
                            var E = x.vB(),
                                G = x.ax(l),
                                I = x.bx(k);
                            if (I) {
                                var M = !1,
                                    K = !1,
                                    x = !1,
                                    N = null,
                                    J = null,
                                    P = null,
                                    O = null;
                                I && (I.backgroundColor && (M = !0, N = I.backgroundColor, J = G.backgroundColor), I.color && (M = !0, P = I.color, O = G.color));
                                M && (0 < g ? (G = b.packTask(A.be, A, [E, this.Ga]), G = this.Rc.Cm(A, !1, N, P, g, G), this.Rc.Vm(G), K = !0) : this.Rc.Dk(A), 0 < d.vf && (x = b.packTask(A.ae, A, [E, a.ii]), G = this.Rc.Cm(A, !0, J, O, d.vf, x), b.addTimedTask(this.Rc.Vm, f, this.Rc, [G]), x = !0));
                                K || (0 < g ? b.addTimedTask(A.be, g, A, [E, this.Ga]) : (J = b.packTask(A.be, A, [E, this.Ga]), n.push(J)));
                                x || b.addTimedTask(A.ae,
                                    h, A, [E, a.ii])
                            } else 0 < g ? b.addTimedTask(A.be, g, A, [E, this.Ga]) : (J = b.packTask(A.be, A, [E, this.Ga]), n.push(J)), G && (0 < d.vf ? (J = G.backgroundColor, O = G.color, x = b.packTask(A.ae, A, [E, a.ii]), G = this.Rc.Cm(A, !0, J, O, d.vf, x), b.addTimedTask(this.Rc.Vm, f, this.Rc, [G])) : b.addTimedTask(A.ae, h, A, [E, a.ii]))
                        }
                    }
                for (d = 0; d < n.length; d++) b.executeTask(n[d])
            },
            updateRowExecution: function() {},
            removeRowExecution: function() {},
            zk: function() {},
            Pl: function() {}
        };
        m.prototype.setHtmlInterpretationEnabled = m.prototype.setHtmlInterpretationEnabled;
        m.prototype.isHtmlInterpretationEnabled = m.prototype.isHtmlInterpretationEnabled;
        m.prototype.setNodeTypes = m.prototype.setNodeTypes;
        m.prototype.getNodeTypes = m.prototype.getNodeTypes;
        m.prototype.setAddOnTop = m.prototype.setAddOnTop;
        m.prototype.isAddOnTop = m.prototype.isAddOnTop;
        m.prototype.setSort = m.prototype.setSort;
        m.prototype.getSortField = m.prototype.getSortField;
        m.prototype.isDescendingSort = m.prototype.isDescendingSort;
        m.prototype.isNumericSort = m.prototype.isNumericSort;
        m.prototype.isCommaAsDecimalSeparator =
            m.prototype.isCommaAsDecimalSeparator;
        m.prototype.extractFieldList = m.prototype.extractFieldList;
        m.prototype.extractCommandSecondLevelFieldList = m.prototype.extractCommandSecondLevelFieldList;
        m.prototype.parseHtml = m.prototype.parseHtml;
        m.prototype.forceSubscriptionInterpretation = m.prototype.forceSubscriptionInterpretation;
        m.prototype.updateRowExecution = m.prototype.updateRowExecution;
        m.prototype.removeRowExecution = m.prototype.removeRowExecution;
        d(m, e);
        return m
    });
    define("AbstractParent", [], function() {
        function d() {}
        d.prototype = {
            Xc: function() {
                this.length = 0;
                this.Xa = {};
                this.ps || (this.map = {})
            }
        };
        return d
    });
    define("VisibleParent", ["AbstractParent", "Inheritance"], function(d, f) {
        function b(a, c, d) {
            this._callSuperConstructor(b);
            this.td = a;
            this.di = c;
            this.jz = d;
            this.ps = !0;
            this.pg = this.di;
            this.Xc()
        }
        b.prototype = {
            removeChild: function(a) {
                if (!(0 >= this.length)) {
                    this.length--;
                    delete this.Xa[a.ha()];
                    var b = a.element();
                    b == this.pg && (this.pg = b.nextSibling);
                    this.td.removeChild(b);
                    a.vk(null)
                }
            },
            insertBefore: function(a, b) {
                b != a && a && (b ? null == this.Xa[b.ha()] ? this.appendChild(a, !0) : (this.qh(a), this.td.insertBefore(a.element(), b.element())) :
                    this.appendChild(a, !0))
            },
            appendChild: function(a, b) {
                if (a) {
                    this.qh(a);
                    var d = a.element();
                    b ? (this.pg || (this.pg = d), this.di ? this.td.insertBefore(d, this.di) : this.td.appendChild(d)) : (this.td.insertBefore(d, this.pg), this.pg = d)
                }
            },
            qh: function(a) {
                a.yj(this) || (this.length++, this.Xa[a.ha()] = a, a.Sm(), a.vk(this))
            },
            Ob: function(a) {
                if (this.length <= a) return null;
                a += this.jz;
                a = this.td.childNodes[a].getAttribute("id");
                return this.getElementById(a)
            },
            getElementById: function(a) {
                return this.Xa[a]
            },
            clean: function() {
                this.td &&
                    delete this.td;
                this.di && delete this.di;
                for (var a in this.Xa) this.Xa[a].clean()
            }
        };
        f(b, d);
        return b
    });
    define("InvisibleParent", ["AbstractParent", "Inheritance"], function(d, f) {
        function b() {
            this._callSuperConstructor(b);
            this.ps = !1;
            this.Xc()
        }
        b.prototype = {
            removeChild: function(a) {
                if (!(0 >= this.length)) {
                    this.length--;
                    var b;
                    for (b = this.Xa[a.ha()]; b < this.length; b++) this.map[b] = this.map[b + 1], this.Xa[this.map[b].ha()] = b;
                    this.Xa[a.ha()] = null;
                    this.map[this.length] = null;
                    a.vk(null)
                }
            },
            insertBefore: function(a, b) {
                if (b != a && a)
                    if (b)
                        if (null == this.Xa[b.ha()]) this.appendChild(a, !0);
                        else {
                            a.Sm();
                            for (var d = this.Xa[b.ha()], e =
                                    this.length; e >= d + 1; e--) this.map[e] = this.map[e - 1], this.Xa[this.map[e].ha()] = e;
                            this.qh(a, d)
                        }
                else this.appendChild(a, !0)
            },
            appendChild: function(a, b) {
                a && (a.Sm(), b || 0 == this.length ? this.qh(a, this.length) : this.insertBefore(a, this.map[0]))
            },
            qh: function(a, b) {
                this.length++;
                this.Xa[a.ha()] = b;
                this.map[b] = a;
                a.vk(this)
            },
            Ob: function(a) {
                return this.map[a]
            },
            getElementById: function(a) {
                return this.map[this.Xa[a]]
            },
            clean: function() {
                for (var a = 0; a < this.length; a++) this.map[a].clean()
            }
        };
        f(b, d);
        return b
    });
    define("DynaElement", ["Cell"], function(d) {
        function f(b, a) {
            this.key = b;
            this.xn = a;
            this.node = this.Nf = null;
            this.id = "hc6|" + a.ha() + "|" + b
        }
        f.prototype = {
            vk: function(b) {
                this.Nf = b
            },
            Sm: function() {
                this.Nf && this.Nf.removeChild(this)
            },
            yj: function(b) {
                return this.Nf == b
            },
            getKey: function() {
                return this.key
            },
            ha: function() {
                return this.id
            },
            element: function() {
                if (null != this.node) return this.node;
                this.node = this.xn.zx();
                this.node.setAttribute("id", this.id);
                for (var b = d.mj(this.node, this.xn.getNodeTypes()), a = 0; a < b.length; a++) {
                    var c =
                        b[a],
                        g = c.sf();
                    g && this.xn.wz(c, this.key, g)
                }
                return this.node
            },
            clean: function() {
                this.node && delete this.node
            }
        };
        return f
    });
    define("VisualUpdate", ["LoggerManager", "Inheritance", "Setter", "IllegalArgumentException"], function(d, f, b, a) {
        function c(a, b, c) {
            this.xl = a;
            this.Fo = b;
            this.key = c;
            this.vf = this.Vp = 0;
            this.nr = 1200;
            this.Ll = this.tj = null
        }
        var g = d.getLoggerProxy("lightstreamer.grids");
        c.prototype = {
            getCellValue: function(b, c) {
                var d = this.xl.qf(this.key, b, c);
                if (!d) throw new a("No cell defined for this field");
                d.na || (d = d[0]);
                return d.te || d.gg()
            },
            setCellValue: function(b, c, d) {
                b = this.xl.qf(this.key, b, d);
                if (!b) throw new a("No cell defined for this field");
                if (b.na) b.Zn(c);
                else
                    for (d = 0; d < b.length; d++) b[d].Zn(c)
            },
            getChangedFieldValue: function(a) {
                return this.Fo[a] || null
            },
            setHotTime: function(a) {
                this.nr = this.checkPositiveNumber(a, !0)
            },
            setColdToHotTime: function(a) {
                this.Vp = this.checkPositiveNumber(a, !0)
            },
            setHotToColdTime: function(a) {
                this.vf = this.checkPositiveNumber(a, !0)
            },
            Gg: function(b, c, d, g, f) {
                b = this.xl.qf(this.key, b, f);
                if (!b) throw new a("No cell defined for this field");
                if (b.na) b.Gg(c, d, g);
                else
                    for (f = 0; f < b.length; f++) b[f].Gg(c, d, g)
            },
            tp: function(a, b, c) {
                this.tj ||
                    (this.tj = {}, this.Ll = {});
                this.tj[c] = a || "";
                this.Ll[c] = b || ""
            },
            setAttribute: function(a, b, c) {
                this.tp(a, b, c)
            },
            setStyle: function(a, b) {
                this.tp(a, b, "CLASS")
            },
            setCellAttribute: function(a, b, c, d, g) {
                this.Gg(a, b, c, d, g)
            },
            setCellStyle: function(a, b, c, d) {
                this.Gg(a, b, c, "CLASS", d)
            },
            forEachChangedField: function(a) {
                for (var b in this.Fo) try {
                    a(b, this.Fo[b])
                } catch (c) {
                    g.logError(d.resolve(507), c)
                }
            }
        };
        c.prototype.getCellValue = c.prototype.getCellValue;
        c.prototype.setCellValue = c.prototype.setCellValue;
        c.prototype.getChangedFieldValue =
            c.prototype.getChangedFieldValue;
        c.prototype.setHotTime = c.prototype.setHotTime;
        c.prototype.setColdToHotTime = c.prototype.setColdToHotTime;
        c.prototype.setHotToColdTime = c.prototype.setHotToColdTime;
        c.prototype.setAttribute = c.prototype.setAttribute;
        c.prototype.setStyle = c.prototype.setStyle;
        c.prototype.setCellAttribute = c.prototype.setCellAttribute;
        c.prototype.setCellStyle = c.prototype.setCellStyle;
        c.prototype.forEachChangedField = c.prototype.forEachChangedField;
        f(c, b, !0, !0);
        return c
    });
    define("DynaGrid", "Inheritance AbstractGrid Cell VisibleParent InvisibleParent DynaElement BrowserDetection VisualUpdate IllegalArgumentException IllegalStateException LoggerManager ASSERT Environment".split(" "), function(d, f, b, a, c, g, e, p, k, h, l, m, t) {
        function n(a, b) {
            this._callSuperConstructor(n, [a]);
            this.dd = 1;
            this.Ug = 0;
            this.qd = null;
            this.ce = "OFF";
            this.qr();
            (b = this.checkBool(b, !0)) && this.parseHtml()
        }
        t.browserDocumentOrDie();
        var r = l.getLoggerProxy("lightstreamer.grids");
        n.prototype = {
            toString: function() {
                return ["[",
                    this.id, this.l, this.Ug, "]"
                ].join("|")
            },
            setMaxDynaRows: function(a) {
                this.j = a && "unlimited" != (new String(a)).toLowerCase() ? this.checkPositiveNumber(a, !0) : 0;
                this.xa() ? this.Hr() : (this.rl(), this.zk(), this.Kp(1))
            },
            getMaxDynaRows: function() {
                return 0 == this.j ? "unlimited" : this.j
            },
            goToPage: function(a) {
                if (this.xa()) throw new h("This grid is configured to no support pagination");
                if (0 == this.j) throw new h("Can't switch pages while 'no-page mode' is used");
                a = this.checkPositiveNumber(a);
                this.Kp(a)
            },
            getCurrentPages: function() {
                return 0 ==
                    this.j ? 1 : this.Ug
            },
            setAutoScroll: function(a, b) {
                if (!a) throw new k("The given value is not a valid scroll type. Admitted values are OFF, ELEMENT, PAGE");
                a = (new String(a)).toUpperCase();
                if ("ELEMENT" == a)
                    if (b) this.qd = b;
                    else throw new k("Please specify an element id in order to use ELEMENT autoscroll");
                else if ("PAGE" != a && "OFF" != a) throw new k("The given value is not a valid scroll type. Admitted values are OFF, ELEMENT, PAGE");
                this.ce = a;
                this.cA()
            },
            parseHtml: function() {
                this.parsed = !0;
                var d = this.Jl;
                if (d) {
                    if (b.Cd(d)) return !0;
                    this.qr()
                }
                d = document.getElementById(this.id);
                if (!this.XB(d)) return !1;
                this.uo = d.cloneNode(!0);
                this.uo.removeAttribute("id");
                this.Jl = d;
                var e = d.parentNode;
                d.style.display = "none";
                for (var g = e.childNodes, f = 0, h = 0, k = null, f = 0; f < g.length; f++)
                    if (g[f] == d) {
                        g[f + 1] && (k = g[f + 1]);
                        h = f + 1;
                        break
                    } this.ba = new a(e, k, h);
                this.wc = new c;
                this.kb = new c;
                return !0
            },
            Pl: function(a) {
                for (var c = b.mj(this.Jl, this.bi), d = {}, e = 0; e < c.length; e++)
                    if (c[e].Nq() == a) {
                        var g = c[e].sf();
                        g && (d[g] = !0)
                    } return d
            },
            XB: function(a) {
                if (!a) throw new k("No template defined");
                if (!b.It(a)) throw new k("The template defined for the grid does not define the 'data-source' attribute");
                var c = [];
                a = b.mj(a, this.bi);
                for (var d = 0; d < a.length; d++) a[d].sf() && c.push(a[d]);
                if (0 >= c.length) throw new k("No valid cells defined for grid");
                return !0
            },
            cA: function() {
                if (!("ELEMENT" != this.ce || this.qd && this.qd.appendChild)) {
                    var a = document.getElementById(this.qd);
                    a ? this.qd = a : (r.logError(l.resolve(508), this), this.ce = "OFF")
                }
            },
            qr: function() {
                this.kb = this.wc = this.ba = this.uo = this.Jl = null;
                this.Ki = {}
            },
            zx: function() {
                return this.uo.cloneNode(!0)
            },
            wz: function(a, b, c) {
                this.P.addCell(a, b, c)
            },
            clean: function() {
                this._callSuperMethod(n, "clean")
            },
            oC: function() {
                if ("OFF" == this.ce) return !1;
                if (this.xa()) {
                    var a = "ELEMENT" == this.ce ? this.qd : document.body;
                    return this.Ic ? 0 == a.scrollTop : e.isProbablyOldOpera() ? !0 : 1 >= Math.abs(a.clientHeight + a.scrollTop - a.scrollHeight)
                }
                return !0
            },
            $w: function(a) {
                var b = "PAGE" == this.ce ? document.body : this.qd;
                return this.xa() ? this.Ic ? 0 : b.scrollHeight - b.clientHeight : a.offsetTop - b.offsetTop
            },
            Hv: function(a) {
                r.isDebugLogEnabled() && r.logDebug(l.resolve(510),
                    this, a);
                "PAGE" == this.ce ? window.scrollTo(0, a) : this.qd.scrollTop = a
            },
            zk: function() {
                for (var a = this.v, b = new c, d = 1; 0 < this.l;) {
                    var e = this.ih(d);
                    if (e)
                        if (null == a) b.appendChild(e, !0), this.l--;
                        else {
                            var g = e.getKey();
                            if ("" == g) this.l--, d++;
                            else {
                                for (var g = this.jb(this.values.get(g, this.v)), f = 0, h = b.length - 1; f < h;) {
                                    var k = Math.floor((f + h) / 2),
                                        m = b.Ob(k);
                                    (m = this.jb(this.values.get(m.getKey(), this.v))) || r.logWarn(l.resolve(509), this);
                                    this.qe(g, m) ? h = k - 1 : f = k + 1
                                }
                                m = b.Ob(f);
                                f == h ? (f = this.jb(this.values.get(m.getKey(), this.v)),
                                    this.qe(g, f) ? b.insertBefore(e, m) : (g = b.Ob(h + 1)) ? b.insertBefore(e, g) : b.appendChild(e, !0)) : m ? b.insertBefore(e, m) : b.appendChild(e, !0);
                                this.l--
                            }
                        }
                    else this.l--, d++
                }
                for (; 0 < b.length;) this.l++, a = b.Ob(0), this.l <= this.j * (this.dd - 1) ? this.kb.appendChild(a, !0) : 0 >= this.j || this.l <= this.j * this.dd ? this.ba.appendChild(a, !0) : this.wc.appendChild(a, !0)
            },
            Kp: function(a) {
                if (!(0 >= this.l)) {
                    if (this.dd >= a)
                        for (; this.Yh(this.kb, this.ba, (a - 1) * this.j);) this.Yh(this.ba, this.wc, this.j);
                    else
                        for (; this.vd(this.ba, this.kb, (a - 1) * this.j,
                                !1);) this.vd(this.wc, this.ba, this.j, !1);
                    this.dd = a
                }
            },
            rl: function() {
                r.isDebugLogEnabled() && r.logDebug(l.resolve(511), this);
                var a = 0,
                    a = 0 >= this.j ? 1 : Math.ceil(this.l / this.j);
                this.Ug != a && (this.Ug = a, this.dispatchEvent("onCurrentPagesChanged", [this.Ug]));
                return a
            },
            removeRowExecution: function(a) {
                var b = this.Ki[a];
                if (b) {
                    this.l--;
                    this.rl();
                    var c = !1,
                        d = this.kb,
                        e = this.wc;
                    this.dispatchEvent("onVisualUpdate", [a, null, b.element()]);
                    this.xa() && this.Ic && null == this.v && (c = this.Ic, d = this.wc, e = this.kb);
                    b.yj(this.ba) ? (this.ba.removeChild(b),
                        this.vd(e, this.ba, this.j, c)) : b.yj(e) ? e.removeChild(b) : (this.kb.removeChild(b), this.vd(this.ba, d, this.j * (this.dd - 1), c) && this.vd(e, this.ba, this.j, c));
                    this.P.delRow(a);
                    delete this.Ki[a]
                }
            },
            updateRowExecution: function(a, b) {
                var c = !1,
                    d = this.Ki[a];
                d || (d = new g(a, this), this.Ki[a] = d, d.element());
                m.verifyOk(d);
                this.om(a, b);
                var e = this.am(a, b, d),
                    f = this.oC(),
                    h = !this.values.getRow(a),
                    k = null != this.v ? this.jb(this.values.get(a, this.v)) : null,
                    l = null != this.v ? this.jb(b[this.v]) : null,
                    n = k == l || !b[this.v] && null !== b[this.v];
                null != this.v && 0 == n ? (k = this.tl(d, k, l), this.Ux(k, d), h && (this.l++, c = !0)) : h && (this.xp(d, !this.Ic), this.l++, c = !0);
                this.Jt(a, e);
                this.Rd = null;
                h && this.xa() && this.Hr();
                f && d.yj(this.ba) && (d = this.$w(d.element()), this.Hv(d));
                c && this.rl()
            },
            am: function(a, b, c) {
                this.Vg = a;
                this.Wg = b;
                b = new p(this.P, b, a);
                this.dispatchEvent("onVisualUpdate", [a, b, c.element()]);
                this.Wg = this.Vg = null;
                return b
            },
            tl: function(a, b, c) {
                for (var d = 1, e = this.l, g = -1; d < e;) {
                    var g = Math.floor((d + e) / 2),
                        f = null;
                    g <= this.l && (f = this.ih(g), f = f == a ? b : this.jb(this.values.get(f.getKey(),
                        this.v)));
                    this.qe(c, f) ? e = g - 1 : d = g + 1
                }
                return d == e ? (f = this.ih(d), a = this.jb(this.values.get(f.getKey(), this.v)), this.qe(c, a) ? d : d + 1) : d
            },
            ih: function(a) {
                if (a > this.l || 0 >= a) return null;
                if (a <= this.kb.length) return this.kb.Ob(a - 1);
                a -= this.kb.length;
                if (a <= this.ba.length) return this.ba.Ob(a - 1);
                a -= this.ba.length;
                return this.wc.Ob(a - 1)
            },
            xp: function(a, b) {
                var c = b ? this.kb : this.wc,
                    d = b ? this.wc : this.kb;
                if (0 < d.length || this.ba.length == this.j && 0 < this.j) return d.appendChild(a, b), d;
                if (0 < this.ba.length || c.length == this.j * (this.dd -
                        1)) return this.ba.appendChild(a, b), this.ba;
                c.appendChild(a, b);
                return c
            },
            Ux: function(a, b) {
                if (!(a > this.l + 1 || 0 >= a) && b != this.ih(a)) {
                    var c = b.Nf,
                        d, e = this.ba,
                        g = this.wc,
                        f = this.kb,
                        h = this.ih(a);
                    null == h ? d = this.xp(b, !0) : (d = h.Nf, d.insertBefore(b, h));
                    d == e ? c && c != g ? c == f && this.vd(e, f, this.j * (this.dd - 1), !1) : this.Yh(e, g, this.j) : d == f ? c != f && this.Yh(f, e, this.j * (this.dd - 1)) && this.Yh(e, g, this.j) : d == g && (c == f && this.vd(e, f, this.j * (this.dd - 1), !1), this.vd(g, e, this.j, !1))
                }
            },
            vd: function(a, b, c, d) {
                return 0 >= this.j ? !1 : b.length < c &&
                    0 < a.length ? (a = a.Ob(0), b.appendChild(a, !d), !0) : !1
            },
            Yh: function(a, b, c) {
                return 0 >= this.j ? !1 : a.length > c ? (a = a.Ob(a.length - 1), b.insertBefore(a, b.Ob(0)), !0) : !1
            },
            Hr: function() {
                for (; 0 < this.j && this.l > this.j;) this.removeRow(this.cr())
            },
            addListener: function(a) {
                this._callSuperMethod(n, "addListener", [a])
            },
            removeListener: function(a) {
                this._callSuperMethod(n, "removeListener", [a])
            },
            getListeners: function() {
                return this._callSuperMethod(n, "getListeners")
            }
        };
        n.prototype.setMaxDynaRows = n.prototype.setMaxDynaRows;
        n.prototype.getMaxDynaRows =
            n.prototype.getMaxDynaRows;
        n.prototype.goToPage = n.prototype.goToPage;
        n.prototype.getCurrentPages = n.prototype.getCurrentPages;
        n.prototype.setAutoScroll = n.prototype.setAutoScroll;
        n.prototype.parseHtml = n.prototype.parseHtml;
        n.prototype.clean = n.prototype.clean;
        n.prototype.addListener = n.prototype.addListener;
        n.prototype.removeListener = n.prototype.removeListener;
        n.prototype.getListeners = n.prototype.getListeners;
        n.prototype.updateRowExecution = n.prototype.updateRowExecution;
        n.prototype.removeRowExecution =
            n.prototype.removeRowExecution;
        d(n, f);
        return n
    });
    define("SlidingCell", [], function() {
        function d(b, a, c, d, e) {
            this.Uz = b;
            this.key = a;
            this.cw = c;
            this.ad = d || null;
            this.Sr = e;
            this.Ng = "s" + f++
        }
        var f = 0;
        d.prototype = {
            fh: function() {
                var b = this.Uz.uw(this.key, this.cw, this.ad);
                if (!b) return null;
                if (b.na) {
                    if (this.ad === b.Pb() && 0 >= this.Sr) return b
                } else
                    for (var a = -1, c = 0; c < b.length; c++) {
                        var d = b[c].Pb();
                        null === d && a++;
                        if (this.ad === d && this.Sr == a) return b[c]
                    }
                return null
            },
            Jm: function() {
                var b = this.fh();
                return b ? b.Jm() : null
            },
            wm: function() {
                var b = this.fh();
                return b ? b.wm() : null
            },
            gh: function() {
                var b =
                    this.fh();
                return b ? b.gh() : null
            },
            ae: function(b, a) {
                var c = this.fh();
                c && c.ae(b, a)
            },
            be: function(b, a) {
                var c = this.fh();
                c && c.be(b, a)
            }
        };
        return d
    });
    define("DoubleKeyMap", ["IllegalArgumentException"], function(d) {
        function f() {
            this.map = {};
            this.Mh = {}
        }

        function b(a) {
            return null !== a && "undefined" != typeof a
        }

        function a(a, c, d) {
            var f = a[d];
            b(f) && (delete a[d], delete c[f])
        }

        function c(a, b) {
            for (var c in a) b(c, a[c])
        }
        f.prototype = {
            set: function(a, c) {
                var f = this.map,
                    k = this.Mh;
                if (!b(a) || !b(c)) throw new d("values can't be null nor missing");
                var h = f[a],
                    l = k[c];
                b(h) ? h !== c && (b(l) ? (f[l] = h, f[a] = c, k[c] = a, k[h] = l) : (delete k[f[a]], f[a] = c, k[c] = a)) : b(l) ? (delete f[k[c]], k[c] = a, f[a] =
                    c) : (f[a] = c, k[c] = a)
            },
            remove: function(b) {
                a(this.map, this.Mh, b)
            },
            removeReverse: function(b) {
                a(this.Mh, this.map, b)
            },
            get: function(a) {
                return this.map[a]
            },
            getReverse: function(a) {
                return this.Mh[a]
            },
            exist: function(a) {
                return "undefined" != typeof this.get(a)
            },
            existReverse: function(a) {
                return "undefined" != typeof this.getReverse(a)
            },
            forEach: function(a) {
                c(this.map, a)
            },
            forEachReverse: function(a) {
                c(this.Mh, a)
            }
        };
        f.prototype.set = f.prototype.set;
        f.prototype.remove = f.prototype.remove;
        f.prototype.removeReverse = f.prototype.removeReverse;
        f.prototype.get = f.prototype.get;
        f.prototype.getReverse = f.prototype.getReverse;
        f.prototype.exist = f.prototype.exist;
        f.prototype.existReverse = f.prototype.existReverse;
        f.prototype.forEach = f.prototype.forEach;
        f.prototype.forEachReverse = f.prototype.forEachReverse;
        return f
    });
    define("StaticGrid", "Inheritance AbstractGrid VisualUpdate Cell SlidingCell CellMatrix IllegalArgumentException IllegalStateException Helpers ASSERT LoggerManager DoubleKeyMap Environment".split(" "), function(d, f, b, a, c, g, e, p, k, h, l, m, t) {
        function n(a, b, c, d) {
            this._callSuperConstructor(n, [a]);
            this.vq = !1;
            this.Ws = null;
            this.setRootNode(c || document);
            this.to = [];
            d && this.addCell(d);
            this.T = new m;
            this.bc = null;
            (b = this.checkBool(b, !0)) && this.parseHtml()
        }

        function r(a, b, c) {
            var d = a[b];
            a[b] = a[c];
            a[c] = d
        }
        t.browserDocumentOrDie();
        var u = l.getLoggerProxy("lightstreamer.grids");
        n.prototype = {
            toString: function() {
                return ["[", this.id, "]"].join("|")
            },
            addCell: function(b) {
                if (!b) throw new e("The given cell is null or undefined");
                if (k.isArray(b))
                    for (var c = 0; c < b.length; c++) this.addCell(b[c]);
                else {
                    b = new a(b);
                    c = b.ir();
                    if (!c || c != this.id) throw new e("The cell does not belong to the Grid");
                    this.vq = !0;
                    this.to.push(b)
                }
            },
            setRootNode: function(a) {
                if (a && a.getElementsByTagName) this.Ws = a;
                else throw new e("The given root element is not valid");
            },
            extractItemList: function() {
                this.Dl();
                if (!1 === this.bc) throw new p("Can\u0092t extract schema from cells declared with the data-row property; use data-item instead.");
                var a = this.pv(),
                    b = [],
                    c;
                for (c in a) b.push(c);
                return b
            },
            parseHtml: function() {
                this.parsed = !0;
                this.P.Xu();
                var b;
                this.vq ? (b = this.to, this.to = []) : b = a.mj(this.Ws, this.bi);
                for (var c = 0; c < b.length; c++) {
                    var d = b[c].ir();
                    if (d && d == this.id && (d = b[c].getRow())) {
                        isNaN(d) || (d = Number(d));
                        if (null === this.bc) this.bc = isNaN(d);
                        else if (this.bc != isNaN(d)) throw p("Can\u0092t mix data-item and data-row declarations on the same grid");
                        this.bc || (this.j = d > this.j ? d : this.j);
                        b[c].sf() && (this.P.Lu(b[c]) || this.P.addCell(b[c]))
                    }
                }
                if (this.P.isEmpty()) throw new p("Please specify at least one cell");
            },
            Pl: function(a) {
                var b = {};
                this.P.gw(function(c, d, e) {
                    c.Nq() == a && (b[e] = !0)
                });
                return b
            },
            pv: function() {
                var a = {};
                this.P.forEachRow(function(b) {
                    a[b] = !0
                });
                return a
            },
            updateRowExecution: function(a, b) {
                var c = !this.values.getRow(a),
                    d;
                if (this.bc) d = a;
                else {
                    d = null != this.v ? this.jb(this.values.get(a, this.v)) : null;
                    var e = null != this.v ? this.jb(b[this.v]) : null,
                        f = d ==
                        e || "undefined" == typeof b[this.v];
                    d = null != this.v && 0 == f ? this.tl(a, d, e) : c ? this.Ic ? 1 : this.xa() ? this.l == this.j ? this.l : this.l + 1 : this.l + 1 : this.T.get(a);
                    this.xa() && this.j == this.l && c && null != this.v && (c = this.Zs(this.cr()), c < d && d--, this.T.set(a, c), this.l++, c = !1);
                    this.T.existReverse(d) && this.T.getReverse(d) != a && this.Kr(d, a);
                    this.T.set(a, d)
                }
                c && this.l++;
                !this.xa() && d > this.j && !this.P.getRow(d) && (c = this.P.getRow(d - 1), c = g.jg(c, null, this.Ga), this.P.insertRow(c, d));
                this.om(d, b);
                c = this.am(a, d, b);
                this.Jt(d, c, a)
            },
            am: function(a,
                c, d) {
                this.Vg = c;
                this.Wg = d;
                d = new b(this.P, d, c);
                this.dispatchEvent("onVisualUpdate", [a, d, c]);
                this.Wg = this.Vg = null;
                return d
            },
            hr: function(a, b, d, e, f) {
                return this.bc ? a : new c(this, b, d, e, f)
            },
            uw: function(a, b, c) {
                a = this.T.get(a);
                return this.P.qf(a, b, c)
            },
            removeRowExecution: function(a) {
                var b = this.bc ? a : this.T.get(a);
                this.dispatchEvent("onVisualUpdate", [a, null, b]);
                this.bc || (b != this.l && (this.Kr(this.l, a), b = this.T.get(a)), h.verifyValue(this.l, b) || u.logError(l.resolve(512)));
                this.P.Dq(b, function(a) {
                    a.clean()
                });
                this.l--;
                this.bc || this.T.remove(a)
            },
            Zs: function(a) {
                var b = this.T.get(a);
                this.T.remove(a);
                this.l--;
                this.values.delRow(a);
                this.xa() && this.Js(a);
                return b
            },
            Kr: function(a, b) {
                var c = this.T.get(b);
                if (a != c) {
                    var d = c ? g.jg(this.P.getRow(c), null, this.Ga) : null,
                        e = c ? this.T.getReverse(c) : null,
                        f, k, l;
                    c ? c > a ? (k = c - 1, l = a, f = -1) : (k = c + 1, l = a, f = 1) : null != this.v || this.Ic ? (l = a, k = this.l, f = -1) : (k = 1, l = a, f = 1);
                    for (var m = k; m - f != l; m += f) {
                        var n = m - f,
                            p = this.P.getRow(m),
                            r = this.P.getRow(n);
                        r || this.xa() || (r = {}, this.P.insertRow(r, n), h.verifyNotOk(c));
                        r ? (g.jg(p, r, this.Ga), p = this.T.getReverse(m), this.T.set(p, n)) : (h.verifyOk(this.xa()), h.verifyValue(m, k), p = this.T.getReverse(m), this.Zs(p))
                    }
                    d ? (g.jg(d, this.P.getRow(a), this.Ga), this.T.set(e, a)) : this.P.Dq(a, function(a) {
                        a.clean()
                    })
                }
            },
            tl: function(a, b, c) {
                for (var d = 1, e = this.l, f = -1; d < e;) {
                    var f = Math.floor((d + e) / 2),
                        g = null;
                    f <= this.l && (g = this.T.getReverse(f), g = g == a ? b : this.jb(this.values.get(g, this.v)));
                    this.qe(c, g) ? e = f - 1 : d = f + 1
                }
                return d == e ? (g = this.T.getReverse(d), a = this.jb(this.values.get(g, this.v)), this.qe(c,
                    a) ? d : d + 1) : d
            },
            Yz: function(a, b, c, d) {
                var e = this.jb(this.values.get(a[d], this.v));
                r(a, c, d);
                for (d = b; b < c; b++) {
                    var f = this.jb(this.values.get(a[b], this.v));
                    this.qe(e, f) || (r(a, b, d), d++)
                }
                r(a, d, c);
                return d
            },
            Hn: function(a, b, c) {
                if (b < c) {
                    var d = this.Yz(a, b, c, Math.round(b + (c - b) / 2));
                    this.Hn(a, b, d - 1);
                    this.Hn(a, d + 1, c)
                }
            },
            zk: function() {
                if (!this.bc) {
                    var a = {};
                    this.T.forEachReverse(function(b, c) {
                        a[b] = c
                    });
                    this.Hn(a, 1, this.l);
                    var b = {},
                        c = new m,
                        d;
                    for (d in a) {
                        c.set(a[d], d);
                        var e = this.T.getReverse(d);
                        if (a[d] != e) {
                            var f = this.P.getRow(d);
                            b[e] = g.jg(f, null, this.Ga);
                            e = a[d];
                            e = b[e] ? b[e] : this.P.getRow(this.T.get(e));
                            g.jg(e, f, this.Ga)
                        }
                    }
                    this.T = c
                }
            },
            addListener: function(a) {
                this._callSuperMethod(n, "addListener", [a])
            },
            removeListener: function(a) {
                this._callSuperMethod(n, "removeListener", [a])
            },
            getListeners: function() {
                return this._callSuperMethod(n, "getListeners")
            }
        };
        n.prototype.addCell = n.prototype.addCell;
        n.prototype.setRootNode = n.prototype.setRootNode;
        n.prototype.extractItemList = n.prototype.extractItemList;
        n.prototype.parseHtml = n.prototype.parseHtml;
        n.prototype.addListener = n.prototype.addListener;
        n.prototype.removeListener = n.prototype.removeListener;
        n.prototype.getListeners = n.prototype.getListeners;
        n.prototype.updateRowExecution = n.prototype.updateRowExecution;
        n.prototype.removeRowExecution = n.prototype.removeRowExecution;
        d(n, f);
        return n
    });
    define("lscx", ["LoggerManager", "lscAe"], function(d, f) {
        function b(a, b) {
            this.L = a;
            this.$h = b
        }
        var a = d.getLoggerProxy(f.Uo);
        b.prototype = {
            onItemUpdate: function(b) {
                var g = {};
                g.length = b.cx();
                for (var e = 1; e <= g.length; e++) {
                    g[e + "_old"] = b.getValue(e);
                    b.Cr(e) ? g[e] = b.getValue(e) : g[e] = f.Ue;
                    var p = b.Kw(e);
                    null != p && (g[p + "_pos"] = e)
                }
                e = b.lj();
                b = b.Bm();
                try {
                    this.L.flashObj.onItemUpdate(this.$h, e, g, b)
                } catch (k) {
                    a.logWarn(d.resolve(421), k)
                }
            },
            ds: function(b, g, e) {
                try {
                    this.L.flashObj.onLostUpdates(this.$h, g, e,
                        b)
                } catch (f) {
                    a.logWarn(d.resolve(422), f)
                }
            },
            onEndOfSnapshot: function() {
                try {
                    this.L.flashObj.onEndOfSnapshot(this.$h)
                } catch (b) {
                    a.logWarn(d.resolve(423), b)
                }
            },
            onClearSnapshot: function() {
                try {
                    this.L.flashObj.onClearSnapshot(this.$h)
                } catch (b) {
                    a.logWarn(d.resolve(424), b)
                }
            },
            onSubscription: function() {
                try {
                    this.L.flashObj.onStart(this.$h)
                } catch (b) {
                    a.logWarn(d.resolve(425), b)
                }
            }
        };
        return b
    });
    define("FlashBridge", "LoggerManager EnvironmentStatus lscx Global Subscription Environment Helpers IllegalArgumentException lscAe Executor".split(" "), function(d, f, b, a, c, g, e, p, k, h) {
        function l(a, b, c) {
            this.Be = this.flashObj = null;
            this.Rf = a;
            this.u = {};
            this.hl = {};
            this.Yr = !1;
            this.Xr = c;
            n[a] = this;
            f.isLoaded() && this.es();
            if (!b || !b.subscribe) throw new p("A LightstreamerClient instance is need for a FlashBridge to feed real-time data to a Flash object");
            this.aB(b)
        }
        g.browserDocumentOrDie();
        var m = d.getLoggerProxy(k.Uo);
        l.prototype = {
            es: function() {
                -1 != navigator.appName.indexOf("Microsoft") ? (this.flashObj = eval("window." + this.Rf), this.flashObj.onStatusChange || this.or()) : this.flashObj = eval("window.document." + this.Rf);
                this.flashObj ? this.Ei() : m.logError(d.resolve(426), this.Rf)
            },
            Ei: function(a) {
                if (this.Be)
                    if (this.flashObj)
                        if (t[this.Rf]) {
                            if (!this.flashObj.onStatusChange && (-1 != navigator.appName.indexOf("Microsoft") && this.or(), !this.av())) {
                                m.logWarn(d.resolve(428), this, a);
                                a = a ? 3E3 < 2 * a ? 3E3 : 2 * a : 50;
                                h.addTimedTask(this.Ei, a, this, [a]);
                                return
                            }
                            m.logWarn(d.resolve(429), this);
                            if (!this.Yr) {
                                try {
                                    this.flashObj.onReady()
                                } catch (b) {
                                    m.logWarn(d.resolve(430), b)
                                }
                                this.Fp(this.Be.Rb());
                                if (this.Xr) try {
                                    this.Xr(this.flashObj)
                                } catch (b) {}
                                this.Yr = !0
                            }
                        } else m.logDebug(d.resolve(435), this);
                else m.logDebug(d.resolve(434), this);
                else m.logDebug(d.resolve(433), this)
            },
            or: function() {
                if (this.flashObj.length)
                    for (var a = 0; a < this.flashObj.length; a++)
                        if (this.flashObj[a].onStatusChange) {
                            this.flashObj = this.flashObj[a];
                            break
                        }
            },
            av: function() {
                return this.flashObj.onStatusChange &&
                    this.flashObj.onReady
            },
            Fp: function(a) {
                if (this.flashObj)
                    if (t[this.Rf])
                        if (this.flashObj.onStatusChange) try {
                            this.flashObj.onStatusChange(a)
                        } catch (b) {
                            m.logWarn(d.resolve(431), b)
                        } else m.logDebug(d.resolve(438), this);
                        else m.logDebug(d.resolve(437), this);
                else m.logDebug(d.resolve(436), this)
            },
            aB: function(a) {
                this.Be = a;
                var b = this;
                a.addListener({
                    onStatusChange: function(a) {
                        b.Fp(a)
                    }
                });
                this.Ei()
            },
            Ow: function() {
                return this.flashObj ? this.flashObj : null
            },
            xv: function(a, b, g, f) {
                m.logDebug(d.resolve(439));
                this.u[f] = new c(g);
                e.isArray(a) ? this.u[f].Uh(a) : this.u[f].mt(a);
                e.isArray(b) ? this.u[f].tk(b) : this.u[f].Xn(b)
            },
            Me: function(a, c) {
                m.logDebug(d.resolve(440));
                if (this.flashObj)
                    if (this.Be)
                        if (this.u[a]) {
                            var g = new b(n[this.Rf], c);
                            this.u[a].addListener(g);
                            this.hl[c] = this.u[a];
                            this.Be.subscribe(this.u[a])
                        } else m.logDebug(d.resolve(442));
                else m.logDebug(d.resolve(441));
                else m.logError(d.resolve(427))
            },
            Qd: function(a) {
                m.logDebug(d.resolve(443));
                this.Be ? (this.Be.unsubscribe(this.hl[a]), delete this.hl[a]) : m.logDebug(d.resolve(444))
            },
            $A: function() {},
            qB: function(a, b) {
                this.u[a] ? this.u[a].$n(!0 === b ? "yes" : !1 === b ? "no" : b) : m.logDebug(d.resolve(445))
            },
            Vh: function(a, b) {
                this.u[a] ? this.u[a].Vh(b) : m.logDebug(d.resolve(446))
            },
            wk: function(a, b) {
                this.u[a] ? this.u[a].wk(b) : m.logDebug(d.resolve(447))
            },
            xk: function(a, b) {
                this.u[a] ? this.u[a].xk(b) : m.logDebug(d.resolve(448))
            },
            Sh: function(a, b) {
                this.u[a] ? this.u[a].Sh(b) : m.logDebug(d.resolve(449))
            }
        };
        var t = {},
            n = {};
        l.bridges = n;
        l.flashIsReady = function(a) {
            t[a] = !0;
            m.logInfo(d.resolve(432), a);
            null != n[a] && n[a].Ei()
        };
        l.prototype.createTable = l.prototype.xv;
        l.prototype.subscribeTable = l.prototype.Me;
        l.prototype.unsubscribeTable = l.prototype.Qd;
        l.prototype.setItemsRange = l.prototype.$A;
        l.prototype.setSnapshotRequired = l.prototype.qB;
        l.prototype.setRequestedMaxFrequency = l.prototype.Vh;
        l.prototype.setRequestedBufferSize = l.prototype.wk;
        l.prototype.setSelector = l.prototype.xk;
        l.prototype.setDataAdapter = l.prototype.Sh;
        a.FlashBridge = l;
        l.prototype.getFlashObject = l.prototype.Ow;
        f.addOnloadHandler(function() {
            for (var a in n) n[a].es()
        });
        return l
    });
    define("ChartLine", ["LoggerManager", "Setter", "Inheritance", "Cell", "IllegalArgumentException"], function(d, f, b, a, c) {
        function g(a, b, c, g) {
            this.parent = b;
            this.tC = g;
            this.Ym = this.Bn = "black";
            this.Cj = this.ag = 1;
            this.Nk = this.dc = this.Cb = null;
            this.Qf = 0;
            this.La = null;
            this.Lk = [];
            this.Lo = [];
            this.labels = [];
            this.$u = p++;
            e.logDebug(d.resolve(473), this)
        }
        var e = d.getLoggerProxy("lightstreamer.charts"),
            p = 0;
        g.prototype = {
            toString: function() {
                return ["[|ChartLine", this.parent, "]"].join("|")
            },
            ha: function() {
                return this.$u
            },
            Qv: function() {
                e.logDebug(d.resolve(474),
                    this);
                this.Lo = [];
                this.Lk = []
            },
            isEmpty: function() {
                return 0 >= this.Lk.length
            },
            reset: function() {
                this.Qv();
                this.parent.Hl(this)
            },
            Mn: function() {
                e.logDebug(d.resolve(475), this);
                var a = this.Lk,
                    b = this.Lo;
                for (this.reset(); 0 < a.length;)(1 < a.length && a[1] >= this.parent.bb || a[0] >= this.parent.bb) && this.rp(a[0], b[0]), a.shift(), b.shift();
                e.logDebug(d.resolve(476), this)
            },
            rp: function(a, b) {
                this.Lk.push(a);
                this.Lo.push(b);
                this.parent.Pv(a, b, this)
            },
            Di: function() {
                this.Nk = (this.dc - this.Cb) / this.parent.screenY;
                e.logDebug(d.resolve(477),
                    this, this.Nk)
            },
            Rm: function() {
                return null !== this.dc
            },
            isPointInRange: function(a) {
                return a < this.dc && a > this.Cb
            },
            Ah: function() {
                this.Pg();
                var a = "",
                    b = -1;
                if (!(0 >= this.Qf)) {
                    0 < this.Qf && (a = this.La ? this.La(this.Cb) : this.Cb, b = this.qj(this.Cb), this.labels[this.labels.length] = this.parent.df(this.Fl, a, b, "Y"));
                    1 < this.Qf && (a = this.La ? this.La(this.dc) : this.dc, b = this.qj(this.dc), this.labels[this.labels.length] = this.parent.df(this.Fl, a, b, "Y"));
                    if (2 < this.Qf)
                        for (var c = this.Qf - 1, g = (this.dc - this.Cb) / c, f = this.Cb, n = 1; n < c; n++) f +=
                            g, a = this.La ? this.La(f) : f, b = this.qj(f), this.labels[this.labels.length] = this.parent.df(this.Fl, a, b, "Y");
                    e.logDebug(d.resolve(478), this)
                }
            },
            qj: function(a) {
                return Math.round((new Number(a) - this.Cb) / this.Nk)
            },
            Pg: function() {
                for (var b = 0; b < this.labels.length; b++) this.labels[b] && a.Cd(this.labels[b]) && this.labels[b].parentNode.removeChild(this.labels[b]);
                this.labels = [];
                e.logDebug(d.resolve(479), this)
            },
            yB: function(a, b, c) {
                this.Qf = this.checkPositiveNumber(a, !0);
                this.Fl = b;
                this.La = c || null;
                e.logDebug(d.resolve(480),
                    this);
                null != this.Nk && this.parent && this.parent.O && this.Ah()
            },
            setStyle: function(a, b, c, g) {
                this.Bn = a;
                this.Ym = b;
                this.ag = this.checkPositiveNumber(c);
                this.Cj = this.checkPositiveNumber(g);
                e.logDebug(d.resolve(481), this)
            },
            xs: function(a, b) {
                this.dc = Number(b);
                this.Cb = Number(a);
                if (isNaN(this.dc) || isNaN(this.Cb)) throw new c("Min and max must be numbers");
                if (this.Cb > this.dc) throw new c("The maximum value must be greater than the minimum value");
                this.parent && null != this.parent.screenY && this.parent.O && (this.Di(), this.Ah(),
                    this.isEmpty() || this.Mn());
                e.logDebug(d.resolve(482), this)
            },
            Fx: function() {
                return this.tC
            }
        };
        g.prototype.setYLabels = g.prototype.yB;
        g.prototype.setStyle = g.prototype.setStyle;
        g.prototype.positionYAxis = g.prototype.xs;
        g.prototype.getYField = g.prototype.Fx;
        b(g, f, "O");
        return g
    });
    define("ChartPainter", ["Cell", "ASSERT"], function(d) {
        function f(a, b) {
            this.eb = a;
            this.Vb = this.hb = null;
            this.O = b;
            this.Ce = []
        }

        function b(a, b) {
            this.eb = a;
            this.Vb = this.hb = null;
            this.O = b;
            this.rd = this.mc = null
        }

        function a(a) {
            var b = !1;
            if (!a) try {
                document.createElement("canvas").getContext && (b = !0)
            } catch (d) {}
            this.hC = b;
            this.Ba;
            this.Dd = {}
        }
        a.prototype = {
            OA: function(a) {
                this.Ba = document.createElement("div");
                this.Ba.style.position = "absolute";
                this.Ba.style.overflow = "hidden";
                a.appendChild(this.Ba)
            },
            clean: function() {
                this.Ba &&
                    d.Cd(this.Ba) && this.Ba.parentNode.removeChild(this.Ba)
            },
            Ld: function(a, b) {
                this.Ba.style.width = a + "px";
                this.Ba.style.height = b + "px";
                this.Jg = b;
                this.Mu = a
            },
            cB: function(a, b) {
                this.Ba.style.top = b + "px";
                this.Ba.style.left = a + "px"
            },
            IA: function(a) {
                this.Ba.className = a
            },
            Gu: function(a) {
                this.Dd[a.ha()] = this.hC ? new b(a, this) : new f(a, this)
            },
            mA: function(a) {
                a = a.ha();
                this.Dd[a] && (this.Dd[a].remove(), delete this.Dd[a])
            },
            Hl: function(a) {
                a = a.ha();
                this.Dd[a] && this.Dd[a].clear()
            },
            Wz: function(a, b, d) {
                var f = a.ha();
                this.Dd[f] || this.Gu(a);
                this.Dd[f].oq(b, d)
            }
        };
        b.prototype = {
            Nx: function() {
                if (!this.rd) {
                    var a = document.createElement("canvas");
                    a.style.position = "absolute";
                    a.style.overflow = "hidden";
                    var b = a.getContext("2d");
                    this.O.Ba.appendChild(a);
                    this.rd = a;
                    this.mc = b
                }
                this.rd.width = this.O.Mu;
                this.rd.height = this.O.Jg
            },
            oq: function(a, b) {
                b = this.O.Jg - b;
                null === this.hb ? this.Nx() : (this.mc.beginPath(), this.mc.strokeStyle = this.eb.Ym, this.mc.lineWidth = this.eb.Cj, this.mc.moveTo(this.hb, this.Vb), this.mc.lineTo(a, b), this.mc.stroke());
                this.cm(a, b)
            },
            cm: function(a,
                b) {
                this.hb = a;
                this.Vb = b;
                var d = Math.round(this.eb.ag / 2);
                this.mc.fillStyle = this.eb.Bn;
                this.mc.fillRect(a - d, b - d, this.eb.ag, this.eb.ag)
            },
            clear: function() {
                this.Vb = this.hb = null;
                this.mc.clearRect(0, 0, this.rd.width, this.rd.height)
            },
            remove: function() {
                this.Vb = this.hb = null;
                this.O.Ba.removeChild(this.rd);
                this.rd = null
            }
        };
        f.prototype = {
            oq: function(a, b) {
                if (null !== this.hb) {
                    var d = a - this.hb,
                        f = b - this.Vb,
                        k = Math.abs(d),
                        h = Math.abs(f),
                        l = null,
                        m = 0,
                        t = 0,
                        n = 0;
                    k >= h ? (n = f / d, m = d, t = 0 <= d ? 1 : -1) : (n = d / f, m = f, t = 0 <= f ? 1 : -1);
                    var f = d = 0,
                        r = null,
                        u = null,
                        q = !0,
                        v = !0;
                    k < h && (v = !1);
                    for (k = 0; k != m; k += t) {
                        var z = h = 0,
                            C = 0,
                            B = 0,
                            w = !1;
                        k + t == m && (q = w = !0);
                        l = document.createElement("div");
                        w ? (l.style.backgroundColor = this.eb.Bn, l.style.width = this.eb.ag + "px", l.style.height = this.eb.ag + "px") : (l.style.backgroundColor = this.eb.Ym, l.style.width = this.eb.Cj + "px", l.style.height = this.eb.Cj + "px");
                        l.style.position = "absolute";
                        l.style.fontSize = "0px";
                        this.O.Ba.appendChild(l);
                        this.Ce.push(l);
                        q && (q = !1, r = Math.ceil(l.offsetWidth / 2), u = Math.ceil(l.offsetHeight / 2), d = l.offsetWidth, f = l.offsetHeight);
                        C = d;
                        B = f;
                        if (v) {
                            if (h = Math.round(k + this.hb), z = Math.round(this.O.Jg - (n * k + this.Vb)), !w) {
                                for (w = 0; k + t != m - t && z == Math.round(this.O.Jg - (n * (k + t) + this.Vb));) k += t, w++;
                                w *= r;
                                C = d + w;
                                0 > t && (h -= w)
                            }
                        } else if (h = Math.round(n * k + this.hb), z = Math.round(this.O.Jg - (k + this.Vb)), !w) {
                            for (w = 0; k + t != m - t && h == Math.round(n * (k + t) + this.hb);) k += t, w++;
                            w *= u;
                            B = f + w;
                            0 < t && (z -= w)
                        }
                        h -= Math.floor(r / 2);
                        z -= Math.floor(u / 2);
                        l.style.left = h + "px";
                        l.style.top = z + "px";
                        l.style.width = C + "px";
                        l.style.height = B + "px"
                    }
                }
                this.cm(a, b)
            },
            cm: function(a, b) {
                this.hb = a;
                this.Vb =
                    b
            },
            clear: function() {
                if (this.Ce[0] && d.Cd(this.Ce[0]))
                    for (var a = 0; a < this.Ce.length; a++) this.Ce[a].parentNode.removeChild(this.Ce[a]);
                this.Ce = [];
                this.Vb = this.hb = null
            },
            remove: function() {
                this.clear()
            }
        };
        return a
    });
    define("Chart", "AbstractWidget Cell LoggerManager Inheritance Helpers Environment ChartLine ChartPainter IllegalStateException IllegalArgumentException".split(" "), function(d, f, b, a, c, g, e, p, k, h) {
        function l(a) {
            this._callSuperConstructor(l, arguments);
            this.bf = document.createElement("div");
            this.bf.style.position = "relative";
            this.bf.style.overflow = "visible";
            this.yp = "";
            this.offsetX = this.offsetY = 0;
            this.screenY = this.screenX = null;
            this.labels = [];
            this.La = null;
            this.Pf = 0;
            this.Nt = this.Mk = this.qb = this.bb = this.Jo =
                null;
            this.Z = {};
            this.Mo = {};
            this.jw = !1;
            this.O = null;
            this.parseHtml()
        }
        g.browserDocumentOrDie();
        var m = b.getLoggerProxy("lightstreamer.charts");
        l.prototype = {
            toString: function() {
                return ["[|Chart", this.id, "]"].join("|")
            },
            Px: function() {
                this.O = new p(this.jw);
                this.O.OA(this.bf);
                this.Xp()
            },
            Xp: function() {
                this.O && (this.O.Ld(this.screenX, this.screenY), this.O.cB(this.offsetX, this.offsetY), this.O.IA(this.yp), m.logDebug(b.resolve(488)))
            },
            ht: function(a, c) {
                if (!this.O)
                    if (a && a.appendChild) {
                        a.appendChild(this.bf);
                        null ==
                            this.screenX && (this.screenX = a.offsetWidth);
                        null == this.screenY && (this.screenY = a.offsetHeight);
                        this.Px();
                        null != this.qb && (this.ql(), this.Yj());
                        for (var d in this.Z)
                            for (var e in this.Z[d]) {
                                var g = this.Z[d][e];
                                g && g.Rm() && (g.Di(), g.Ah())
                            }
                        m.logInfo(b.resolve(485), this, a)
                    } else c || m.logError(b.resolve(483), this)
            },
            df: function(a, c, d, e) {
                m.logDebug(b.resolve(489), this);
                var g = document.createElement("div");
                null != a && (g.className = a);
                g.style.position = "absolute";
                g.appendChild(document.createTextNode(c));
                this.bf.appendChild(g);
                a = g.offsetWidth;
                "X" == e.toUpperCase() ? (g.style.top = this.screenY + 5 + this.offsetY + "px", g.style.left = d - g.offsetWidth / 2 + this.offsetX + "px") : "Y" == e.toUpperCase() && (g.style.left = this.offsetX - a + "px", g.style.top = this.screenY - d - g.offsetHeight / 2 + this.offsetY + "px");
                return g
            },
            Hl: function(a) {
                this.O.Hl(a)
            },
            Pv: function(a, c, d) {
                m.isDebugLogEnabled() && m.logDebug(b.resolve(490), this);
                a = this.pj(a);
                c = d.qj(c);
                m.isDebugLogEnabled() && m.logDebug(b.resolve(491), a, c);
                this.O.Wz(d, a, c);
                m.isDebugLogEnabled() && m.logDebug(b.resolve(492))
            },
            rA: function() {
                m.logDebug(b.resolve(493));
                for (var a in this.Z)
                    for (var c in this.Z[a]) {
                        var d = this.Z[a][c];
                        d && !d.isEmpty() && d.Mn()
                    }
            },
            ql: function() {
                this.Mk = (this.qb - this.bb) / this.screenX;
                m.isDebugLogEnabled() && m.logDebug(b.resolve(494), this, this.Mk)
            },
            Yj: function() {
                this.Pg();
                var a = "",
                    c = -1;
                if (!(0 >= this.Pf)) {
                    0 < this.Pf && (a = this.La ? this.La(this.bb) : this.bb, c = this.pj(this.bb), this.labels[this.labels.length] = this.df(this.El, a, c, "X"));
                    1 < this.Pf && (a = this.La ? this.La(this.qb) : this.qb, c = this.pj(this.qb), this.labels[this.labels.length] =
                        this.df(this.El, a, c, "X"));
                    if (2 < this.Pf)
                        for (var d = this.Pf - 1, e = (this.qb - this.bb) / d, g = this.bb, f = 1; f < d; f++) g += e, a = this.La ? this.La(g) : g, c = this.pj(g), this.labels[this.labels.length] = this.df(this.El, a, c, "X");
                    m.logDebug(b.resolve(495), this)
                }
            },
            pj: function(a) {
                return Math.round((new Number(a) - this.bb) / this.Mk)
            },
            Pg: function() {
                for (var a = 0; a < this.labels.length; a++) this.labels[a] && f.Cd(this.labels[a]) && this.labels[a].parentNode.removeChild(this.labels[a]);
                this.labels = [];
                m.logDebug(b.resolve(496), this)
            },
            onListenStart: function(a) {
                this._callSuperMethod(l,
                    "onListenStart", [a]);
                this.xa() && (this.kind = d.Vo)
            },
            rs: function(a, b, d, e) {
                b = null === b[d] || "undefined" == typeof b[d] ? this.values.get(a, d) : b[d];
                b = e ? e(b, a) : b;
                return null === b ? null : c.getNumber(b)
            },
            mergeUpdate: function(a, b) {
                this.Dt(a, b)
            },
            updateRowExecution: function(a, c) {
                var d = this.rs(a, c, this.Jo, this.Nt);
                if (null !== d && !(isNaN(d) || null !== d && d < this.bb)) {
                    d > this.qb && this.dispatchEvent("onXOverflow", [a, d, this.bb, this.qb]);
                    for (var g in this.Z) {
                        var f = this.rs(a, c, g, this.Mo[g]);
                        if (!isNaN(f)) {
                            var h = this.Z[g][a];
                            if (null ==
                                d || null == f) h && null == d && null == f ? (m.logInfo(b.resolve(486), this, h), h.reset()) : m.logDebug(b.resolve(497), this, h);
                            else {
                                if (!h) {
                                    h = new e(a, this, this.Jo, g);
                                    this.dispatchEvent("onNewLine", [a, h, d, f]);
                                    if (!h.Rm()) {
                                        m.logError(b.resolve(484), this);
                                        break
                                    }
                                    h.Di();
                                    h.Ah();
                                    this.Z[g][a] = h
                                }
                                h.isPointInRange(f) || this.dispatchEvent("onYOverflow", [a, h, f, h.Cb, h.dc]);
                                h.rp(d, f)
                            }
                        }
                    }
                }
            },
            removeRowExecution: function(a) {
                for (var b in this.Z) this.hq(a, b)
            },
            hq: function(a, c) {
                if (this.Z[c]) {
                    var d = this.Z[c][a];
                    d.reset();
                    d.Pg();
                    this.O.mA(d);
                    delete this.Z[c][a];
                    this.dispatchEvent("onRemovedLine", [a, d]);
                    m.logDebug(b.resolve(498), this, a, c)
                }
            },
            clean: function() {
                this._callSuperMethod(l, "clean");
                this.Pg();
                this.O && this.O.clean();
                delete this.O;
                this.ht(this.bf.parentNode, !0);
                m.logDebug(b.resolve(499), this)
            },
            parseHtml: function() {
                m.logInfo(b.resolve(487), this);
                var a = document.getElementById(this.id);
                if (a) {
                    if (!f.It(a)) throw new k("A DOM element must be provided as an anchor for the chart");
                    this.ht(a);
                    this.parsed = !0
                }
            },
            configureArea: function(a, b, c, d,
                e) {
                a && (this.yp = a);
                d && (this.offsetY = this.checkPositiveNumber(d, !0));
                e && (this.offsetX = this.checkPositiveNumber(e, !0));
                b && (this.screenY = this.checkPositiveNumber(b, !0));
                c && (this.screenX = this.checkPositiveNumber(c, !0));
                this.Xp();
                if (c || b) {
                    c && null != this.qb && (this.ql(), this.Yj());
                    for (var g in this.Z)
                        for (var f in this.Z[g])(a = this.Z[g][f]) && a.Rm() && null != this.qb && (b && (a.Di(), a.Ah()), a && !a.isEmpty() && a.Mn())
                }
            },
            setXAxis: function(a, c) {
                this.Jo = a;
                this.Nt = c;
                this.clean();
                m.logDebug(b.resolve(500), a, this)
            },
            addYAxis: function(a,
                d) {
                if (c.isArray(a)) {
                    m.logDebug(b.resolve(501), this);
                    for (var e = 0; e < a.length; e++) c.isArray(d) ? this.addYAxis(a[e], d[e]) : this.addYAxis(a[e], d)
                } else this.Z[a] || (this.Z[a] = {}), this.Mo[a] = d, m.logDebug(b.resolve(502), a, this)
            },
            removeYAxis: function(a) {
                if (c.isArray(a)) {
                    m.logDebug(b.resolve(503), this);
                    for (var d = 0; d < a.length; d++) this.removeYAxis(a[d])
                } else if (this.Z[a]) {
                    for (d in this.Z[a]) this.hq(d, a);
                    delete this.Z[a];
                    delete this.Mo[a];
                    m.logDebug(b.resolve(504), a, this)
                }
            },
            positionXAxis: function(a, c) {
                this.qb = Number(c);
                this.bb = Number(a);
                if (isNaN(this.qb) || isNaN(this.bb)) throw new h("Min and max must be numbers");
                if (this.bb > this.qb) throw new h("The maximum value must be greater than the minimum value");
                null != this.screenX && (this.ql(), this.Yj());
                this.rA();
                m.logDebug(b.resolve(505), this)
            },
            setXLabels: function(a, c, d) {
                this.Pf = this.checkPositiveNumber(a, !0);
                this.El = c;
                this.La = d || null;
                null != this.Mk && this.Yj();
                m.logDebug(b.resolve(506), this)
            },
            addListener: function(a) {
                this._callSuperMethod(l, "addListener", [a])
            },
            removeListener: function(a) {
                this._callSuperMethod(l,
                    "removeListener", [a])
            },
            getListeners: function() {
                return this._callSuperMethod(l, "getListeners")
            }
        };
        l.prototype.parseHtml = l.prototype.parseHtml;
        l.prototype.configureArea = l.prototype.configureArea;
        l.prototype.setXAxis = l.prototype.setXAxis;
        l.prototype.addYAxis = l.prototype.addYAxis;
        l.prototype.removeYAxis = l.prototype.removeYAxis;
        l.prototype.positionXAxis = l.prototype.positionXAxis;
        l.prototype.setXLabels = l.prototype.setXLabels;
        l.prototype.addListener = l.prototype.addListener;
        l.prototype.removeListener = l.prototype.removeListener;
        l.prototype.getListeners = l.prototype.getListeners;
        l.prototype.clean = l.prototype.clean;
        l.prototype.onListenStart = l.prototype.onListenStart;
        l.prototype.updateRowExecution = l.prototype.updateRowExecution;
        l.prototype.removeRowExecution = l.prototype.removeRowExecution;
        a(l, d);
        return l
    });
    define("SimpleChartListener", ["List"], function(d) {
        function f(b, a) {
            this.sC = b || 60;
            a = (a || 20) / 100;
            this.Ty = 1 + a;
            this.By = 1 - a;
            this.Fm = new d;
            this.Mf;
            this.Jf
        }
        f.prototype = {
            onListenStart: function(b) {
                this.Lp = b
            },
            onYOverflow: function(b, a, c, d, e) {
                b = (e - d) / 2;
                c > e ? (e += b, c > e && (e = c), this.Jf = e, this.Eo(d, e)) : c < d && (d -= b, c < d && (d = c), this.Mf = d, this.Eo(d, e))
            },
            onXOverflow: function(b, a, c, d) {
                a > d && (b = (d + c) / 2, this.Lp.positionXAxis(b, b + (d - c)))
            },
            onNewLine: function(b, a, c, d) {
                this.Lp.positionXAxis(c, c + this.sC);
                b = d * this.By;
                d *= this.Ty;
                this.Fm.add(a);
                this.Mf = null !== this.Mf && this.Mf <= b ? this.Mf : b;
                this.Jf = null !== this.Jf && this.Jf >= d ? this.Jf : d;
                this.Eo(this.Mf, this.Jf)
            },
            onRemovedLine: function(b, a) {
                this.Fm.remove(a)
            },
            Eo: function(b, a) {
                this.Fm.forEach(function(c) {
                    c.xs(b, a)
                })
            }
        };
        f.prototype.onListenStart = f.prototype.onListenStart;
        f.prototype.onYOverflow = f.prototype.onYOverflow;
        f.prototype.onXOverflow = f.prototype.onXOverflow;
        f.prototype.onNewLine = f.prototype.onNewLine;
        f.prototype.onRemovedLine = f.prototype.onRemovedLine;
        return f
    });
    define("StatusWidget", "Environment IllegalArgumentException Helpers LightstreamerConstants Executor BrowserDetection".split(" "), function(d, f, b, a, c, g) {
        function e(a, d, e, g) {
            if (!t) {
                this.ready = !1;
                this.Yc = this.pl = null;
                a = a || "left";
                if (!v[a]) throw new f("The given value is not valid. Admitted values are no, left and right");
                g = g || "closed";
                if (!z[g]) throw new f("The given value is not valid. Admitted values are open, closed and dyna");
                var k = e ? d : "auto";
                e = e ? "auto" : d;
                this.ob = l("div");
                d = l("div");
                this.nb = l("div");
                h(this.ob, {
                    zIndex: "99999"
                });
                h(d, {
                    width: "42px",
                    height: "42px",
                    opacity: "0.95",
                    filter: "alpha(opacity\x3d95)",
                    backgroundColor: "#135656",
                    zIndex: "99999",
                    position: "relative"
                });
                h(this.nb, {
                    width: "245px",
                    height: "42px",
                    backgroundColor: "#ECE981",
                    fontFamily: "'Open Sans',Arial,sans-serif",
                    fontSize: "11px",
                    color: "#3E5B3E",
                    position: "absolute",
                    zIndex: "99998",
                    visibility: "hidden",
                    opacity: "0",
                    filter: "alpha(opacity\x3d0)",
                    transition: "all 0.5s",
                    MozTransition: "all 0.5s",
                    "-webkit-transition": "all 0.5s",
                    OTransition: "all 0.5s",
                    "-ms-transition": "all 0.5s"
                });
                "no" == a ? (h(this.ob, {
                    position: "absolute"
                }), h(d, {
                    borderRadius: "4px",
                    "float": "left"
                }), h(this.nb, {
                    borderTopRightRadius: "4px",
                    borderBottomRightRadius: "4px",
                    left: "38px"
                })) : (h(this.ob, {
                    position: "fixed",
                    top: k,
                    bottom: e
                }), "left" == a ? (h(this.ob, {
                    left: "0px"
                }), h(d, {
                    borderTopRightRadius: "4px",
                    borderBottomRightRadius: "4px",
                    "float": "left"
                }), h(this.nb, {
                    borderTopRightRadius: "4px",
                    borderBottomRightRadius: "4px",
                    left: "38px"
                })) : (h(this.ob, {
                    right: "0px"
                }), h(d, {
                    borderTopLeftRadius: "4px",
                    borderBottomLeftRadius: "4px",
                    "float": "right"
                }), h(this.nb, {
                    borderTopLeftRadius: "4px",
                    borderBottomLeftRadius: "4px",
                    right: "38px"
                })));
                this.ob.appendChild(d);
                this.ob.appendChild(this.nb);
                a = l("div");
                h(a, {
                    position: "absolute",
                    top: "2px",
                    left: "5px",
                    width: "32px",
                    height: "32px"
                });
                d.appendChild(a);
                this.Ox(a);
                this.dC = new m(d, 1);
                this.OB = new m(d, 2);
                this.Iy = new m(d, 3);
                this.Zl = l("div");
                h(this.Zl, {
                    position: "absolute",
                    top: "7px",
                    left: "13px"
                });
                this.nb.appendChild(this.Zl);
                this.statusText = l("div");
                h(this.statusText, {
                    position: "absolute",
                    top: "21px",
                    left: "13px"
                });
                this.nb.appendChild(this.statusText);
                this.Bb(w, w, w, "Ready", "DATA STREAMING STATUS", this.Sb);
                this.fl();
                this.je = 2;
                this.pinned = !1;
                "closed" != g && (this.Wj(!0), "dyna" == g ? c.addTimedTask(this.ar(), 1E3) : this.pinned = !0);
                g = this.Ax();
                b.addEvent(this.nb, "transitionend", g);
                b.addEvent(this.nb, "webkitTransitionEnd", g);
                b.addEvent(this.nb, "MSTransitionEnd", g);
                b.addEvent(this.nb, "oTransitionEnd", g);
                b.addEvent(this.ob, "click", this.vw());
                b.addEvent(this.ob, "mouseover", this.Zw());
                b.addEvent(this.ob, "mouseout", this.ar())
            }
        }

        function p(a) {
            var b = l("img");
            b.src = a;
            h(b, {
                display: "none"
            });
            return b
        }

        function k() {
            for (var a = {}, b = 0; b < arguments.length; b++) a[arguments[b]] = !0;
            return a
        }

        function h(a, b) {
            for (var c in b) a.style[c] = b[c]
        }

        function l(a) {
            a = document.createElement(a);
            h(a, {
                backgroundColor: "transparent"
            });
            return a
        }

        function m(a, b) {
            this.Wm = l("div");
            h(this.Wm, {
                position: "absolute",
                bottom: "3px",
                left: 5 + 11 * (b - 1) + "px",
                width: "10px",
                height: "3px",
                borderRadius: "2px",
                backgroundColor: w
            });
            a.appendChild(this.Wm)
        }
        d.browserDocumentOrDie();
        var t =
            g.isProbablyIE(6, !0),
            n = p("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABGdBTUEAALGPC/xhBQAAAAlwSFlzAAALDwAACw8BkvkDpQAAABl0RVh0U29mdHdhcmUAUGFpbnQuTkVUIHYzLjUuN6eEncwAAAQDSURBVFhH7ZZtaJVlGMet1IpcgZHVF6XQCAJBxVkUEeGG7KzlS8xe9PiyM888vnBg7gyXExbOkmDH3M7mmmVDK9nOKJ2bw41UfJ3tKCgOF80PRUUvREQQZNvd7/9wP3US5vN4Zh8CBz/uc3au+3/9n+u5X64xY279/Z8r0Hn+zXGQDWGogRbohuNwFNqhCabftOdEbAK8BltgLzRbkozH4ApchSE4CE/dlOQITYZqWAUTXdGSd0smQR6UQR20RHatPrz+/chJPidhJ1TAQph8w2ZIlmXL+wvjLAkgNAPegjdgAUyDh+BReAZC0AAXYRiM5U/GJpjgywgJp8KXYCDOxBzotWIhifz0fVUWPAshSyljHbRA8+XByo8/ORk719xTumff0Q1P+EqsIBLeCZdtcrOlrfQz92miuyM9iEfhNPwOG+HedHG+T4IF0AQ/goFhuARvQ/Z1zZC40E2++1iFWdawzCljuLHIdJ2NSkiCotjrqYgZB/Ohy5r4gzGlio04l+RVroGK1mJTWFuIgbBZmSgw3Z+vd5MPInKbl4FrKnMfc8Z7ziH5q66B2L4ikx/PN8HEYrOiLs/s7FzuGvjUUyjTAJKPh/Mykegucwzkx+eZxe/kmlB9wFz8olwmzmSq72seyR+GlEys2xPEQMDk1TxnCuLPm5KmfHNhoHwIE4/5Ess0yO6GzQf6qn+NNC81gZocx4R4qXau2d6x5Pi2jkV3Z6rve55Ov/bU1opNyVXfvLB97t8mZOSVhrzv4l3RGDH3+BbMNFBro3p/JLhwR06/WwmNMrW5LfzDwdTWTelHdaZ5POd19K65q7Zz6YlFO/6phl7PGl6TXhcmKvX6PIVGE8ACfDzVXzZU3BhwFqYqoYWqBWu3cJ8W8mhyeM7FRN+5/jJTlAg4W1RbVVtWW9ea0Fb2Png8M40QgIEOHcm17UHnkAomXnYM6PByDzIdar70ERrrK9AGEX87fC0Dh3rXcky/6NwXOrY3thSnG6gaUZfJy+Ew/Ay6JFohF+7wMkPMOvdS6jwTvRpuDDkGdHHpAkurQOH1DIxFZB7o2vzKFWT8FuqhAB645kK5n/9VwW/W/Iq1763usn3CMFf3kbTkAze0Gw71ls/+6MiG5IFTsUsDVyqTJPgQNKrJULOhxkNVywZnm5G4yCY/y5hLQjWoqoCamWlelXR+V5tk2yW1TW4LpXbqAtTbJE8zPgIPwlSYD2rLtsFM6ZBwJqh9i8O/mhS/RqYgpgbydWiENjWYNJrdfG6FBMQgICOuqE4/UMOqxnWKr2ReQQg9Cert1WKr1R4E9fut8IFFrbla9CWQ5aXp+3fEpsMuUG+vRSV6bHKVtwTmwH93yPh2eytwFBX4C/nwkj6r2tmsAAAAAElFTkSuQmCC"),
            r = p("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABGdBTUEAALGPC/xhBQAAAAlwSFlzAAALDgAACw4BQL7hQQAAABp0RVh0U29mdHdhcmUAUGFpbnQuTkVUIHYzLjUuMTAw9HKhAAAD00lEQVRYR+2WWWhUVxzG1bq0aBQsbi+KoiIIgpbGFsW3SmlB1AcfVEQxLi9CFjohZt/IIlRCJqNmAnGIEsjEENCEyczEKCpGM9rEYqlQ81BpCy2IlEJBTa6/73JOSYV4rxP7UHDgx5lkzvm+7557lv+0ae8//+cZGBgYmAWZcAy+hQ5IwA24BpchDBve2XMiNg/2QRVcgIihk/Y6jMILGIMr8Pk7MUdoOVTDUVhoRaurqxfDV/ANBKGjpqYmXldXd4vvnXAWTsJuWP7WYTDLMNP7jPYTCSC0EWqhAnbBGlgKq2ArZMEZ+B7GwTG8pA3DPF9BMFwNP4EDpxn4BdwxYlkSGR0dzYBtkGXIow1CB0SGh4fbe3p67kej0bbu7u71vozVCcM58KMxd5qbm6/ap6mvr08ing234W8ogPkTxfl7MeyCMPwBDozDQzgFmW8Mg/Eea97V1eWUlpa601hZWenE43EJSVAc8Xoq+syCnRAzIZ7T3tOMTToW83IbIBgMOgUFBW6A4uJiJ5FIWPPHiEz3CvDazCxgzGzPMZjvtQEaGhqcvLw817yoqMhpa2uzAbo9hdLtgPls+E4h2tvb3QC5ublOfn6+U1JS4qRSKYUYTFff1zjMl8E9hWDhuSGys7PdIBUVFc7Q0NAYIdb6Eku3k9kNJclk8s/a2lonJyfHDSE0G62trTdaWlo+Slff9zidfv39/Sebmpp+sTNhgxQWFv7GugjQZ65vwXQ7am2Ew+EDgUDgBxtArUKFQqHfCVk08ahO18dzXCwW+zASidwkyD+vRK+HO8DR6yJEsV6fp9BUOrAA1w0ODo6VlZW5C9POhBas2cIpLeSpeHiOJUSKEO4ZoUWpIHod2romhLay98Hj6TRJBwL06EhmN7iHlIIogA4ve5DpUPOlj9BMXx1NJ/rPgCcK0NfX55rruNax3djYODFA+aS6DD4IcXgKuiSisB0+8ApDnxP2UmJRvqiqqnID6OLSBTZhBva8KcBMRL4EXZs/W0HaXyEEO2DRaxfKx/yvHP4y4Q9xSMVMnTDO1Y23W0OIR2+1G7hqPyV9Z29v78ORkZFODC6CWhUZKjZUeGjWMsHdZhgfNuZ3abdjqAJV5ipm1njNpPu7yiRTLqlssiWUyqkHEDImW2hXwhJYDTtBZVkdbJIOhptA5dtp+FeR4jfICsRUQBbCObikApNCM8H3KDRBAL5WECuK2UJQwarCdYUvM69OCH0Gqu1VYqvUfgyq96Nw3qDSXCX6fsjw0vT9O2IboAVU29tP0phreo/DZvjvDhnfad93nMIMvAIArtySMI7UCwAAAABJRU5ErkJggg\x3d\x3d"),
            u = p("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABGdBTUEAALGPC/xhBQAAAAlwSFlzAAALDgAACw4BQL7hQQAAABp0RVh0U29mdHdhcmUAUGFpbnQuTkVUIHYzLjUuMTAw9HKhAAAECElEQVRYR+2WX2hbZRjGp9uq4qqguOnNhrKJIAycWJWJdw5RkM2LXaiIYnXeCMLYwLkJFQeK4G5mVOqFQ0VoK+iyxJg2bZrEpK3LRpqky9iyLq3705b9UcSBs/38PWffGWfV5JxOxxC8+PGlzTnv++T9vvf9nnmhUGje1eSqJtcP/28LqE3tWwgtsAE+gA7ohjQkIQztsLLeNs+5AgRbBM/CO/AF7LJ0sfbDETgP07AHHm50xgILINBS2A6vwC1u0P6R/sXwBGyCndCRGknFMwdSP/C5Cz6GLfA0LJ0txlcAyZptec+y3q8ABLoP3oW3YR2sgNvhLngEWuEjKMIMGMsfrO2wyBXSUAAJl8NhMLCDFx+DQRusVUHO/fZjMzwKrZaNrDuhA3ad+XnoqyMncvsqP2U/P3Qse2/gCpDwOqjY5CZfzfa6vyZTSfUQ/HXIwTl4A27yBufvxbAO2mEKDMxAGd6HloZtSOL1bvLK8QGTKCUulLHcZ8YmMgqkgOJlv0HGMwthLcSsiN9Z86pY3S0geZsrYKCaNPFi3BHQV4qa8cmMm7xKkGv8BMyqzM280+R7Bkj+jCsgd6jPRAtRqhA3vcWIKdd6XQHfzCX53z3bqAJNCNgvEaXxrCMgWthj4sNhqhAxp87mJGLgiglQYJLfAXmJSB9MICBiIoVvWXezHVFz6kxuGhF3/xMRQeaAuuGt0cn8L6lKAgFhR4T4vrjbFGo96f212A2XK8JXgBtY0+/oVH7LYDV5TBVwRWjtLkVOFMYym3nmxrkKCSzAI6QpP5p6PjYcHvGKkKihav8kIrd6R7WfoDkLuChkInV9sZbIxIa91QgbbZO2CxHbNMyumAA7hu+ZOp2dTpYjzsG8cEAjzoG1LbxXB/lfuQ3rBaEL9iLCaU21qFpVLavWtSLUyhcHT+C7wK907vcIiGgkF48mnCGVKHU7AjS83EGmoVYv3iVngEALgia2W3At74xLQG0iTRW+c8a1xvbA4aRXQFtdAbz8AsThNOiS6IQ1MN9PDM+85l5KtZOZ87qoJEAXly4wTwXWNxKwgCCPg67NMc8td5zPIXgKbpt1odzK/9rgVyv+xfSBVMz6hBmu7j5P8oONuuEvbVibyD2AcegaPZkrYya6SPAlaJXJkNmQ8VDVWsBpMxK/ZJMPsa4hoQyqKiAzsyJQF8gmWbsk2+RaKNmpYQjZJKtZ74QlsBzWgmzZe7DK3h+rSCr7tgMuMSmBbkMCLQMZyDfhE/haBhOj2c3nTvgQNsOTEuId1SSUYZVxXeZ3ftzv/TzhQwSTt5fFltWugvx+J3xmkTWXRX8OmoMm9hVAsJXwKcjb61CJHptc5X0VHoS6QyaImMu+C4IED/LM/wL+BDxNDVItZyFPAAAAAElFTkSuQmCC"),
            q = !1,
            v = k("no", "left", "right"),
            z = k("dyna", "open", "closed");
        e.prototype = {
            getDomNode: function() {
                return this.ob
            },
            Ox: function(a) {
                this.Sb = r.cloneNode(!0);
                a.appendChild(this.Sb);
                if (!q && 32 != this.Sb.height && g.isProbablyIE(7)) {
                    a.removeChild(this.Sb);
                    var b = l("div");
                    h(b, {
                        textAlign: "center",
                        textOverflow: "ellipsis",
                        fontFamily: "Arial, Helvetica, sans-serif",
                        fontSize: "10px",
                        color: "#333333",
                        verticalAlign: "middle",
                        paddingTop: "3px",
                        width: "32px",
                        height: "32px",
                        display: "none"
                    });
                    b.innerHTML = "Net\x3cbr/\x3eState";
                    r = n = u =
                        b;
                    q = !0;
                    this.Sb = r.cloneNode(!0);
                    a.appendChild(this.Sb)
                }
                this.uf = n.cloneNode(!0);
                a.appendChild(this.uf);
                this.Xm = u.cloneNode(!0);
                a.appendChild(this.Xm)
            },
            fl: function() {
                if (!this.ready) {
                    var a = document.getElementsByTagName("body");
                    if (a && 0 != a.length) a[0].appendChild(this.ob), this.ready = !0;
                    else {
                        var c = this;
                        b.addEvent(document, "DOMContentLoaded", function() {
                            document.getElementsByTagName("body")[0].appendChild(c.ob);
                            c.ready = !0;
                            if (c.pl) c.onStatusChange(c.pl);
                            0 == c.je ? c.Wj() : c.Kl()
                        })
                    }
                }
            },
            onListenStart: function(a) {
                t ||
                    (this.onStatusChange(a.Rb()), this.Yc = a)
            },
            onListenEnd: function() {
                t || (this.Bb(w, w, w, "Ready", "DATA STREAMING STATUS"), this.Yc = null)
            },
            Bb: function(a, b, c, d, e, f) {
                this.dC.yl(a);
                this.OB.yl(b);
                this.Iy.yl(c);
                this.statusText.innerHTML = d;
                this.Zl.innerHTML = e;
                this.Gt(f, !0)
            },
            Gt: function(a, b) {
                b && this.JB();
                this.Kt && (this.Kt.style.display = "none");
                a.style.display = "";
                this.Kt = a
            },
            JB: function() {
                this.ml && (this.ll = !1, c.stopRepetitiveTask(this.ml), this.ml = null)
            },
            io: function() {
                this.ml = c.addRepetitiveTask(this.Iv, 500, this)
            },
            Iv: function() {
                this.Gt(this.ll ? this.Sb : this.uf);
                this.ll = !this.ll
            },
            onStatusChange: function(b) {
                if (!this.ready || t) this.pl = b;
                else {
                    var c = this.Yc && (this.Yc.zf && this.Yc.zf() || this.Yc.qv && this.Yc.qv.zf()),
                        d = c ? C : B,
                        c = c ? "DATA STREAMING STATUS" : "DATA STREAMING STATUS (attached)";
                    if (b == a.Db) this.Bb(w, w, w, "Disconnected", "DATA STREAMING STATUS", this.Sb);
                    else if (b == a.CONNECTING) this.Bb(w, w, d, "Connecting...", c, this.Sb), this.io();
                    else if (0 == b.indexOf(a.Ra)) {
                        var e = this.Yc && 0 == this.Yc.Sl.gr().indexOf("https") ? "S in " :
                            " in ";
                        b == a.Ra + a.xg ? (this.Bb(B, B, d, "Stream-sensing...", c, this.Sb), this.io()) : b == a.Ra + a.Bg ? this.Bb(C, C, d, "Connected over WS" + e + "streaming mode", c, this.uf) : b == a.Ra + a.Xd ? this.Bb(B, C, d, "Connected over HTTP" + e + "streaming mode", c, this.uf) : b == a.Ra + a.Zd ? this.Bb(C, B, d, "Connected over WS" + e + "polling mode", c, this.uf) : b == a.Ra + a.ec && this.Bb(B, B, d, "Connected over HTTP" + e + "polling mode", c, this.uf)
                    } else b == a.yg ? this.Bb(w, w, d, "Stalled", c, this.Xm) : b == a.zg ? (this.Bb(w, w, d, "Recovering...", c, this.Xm), this.io()) : this.Bb(w,
                        w, d, "Disconnected (will retry)", c, this.Sb)
                }
            },
            Wj: function() {
                0 != this.je && 1 != this.je && (this.je = 1, h(this.nb, {
                    visibility: "",
                    opacity: "1",
                    filter: "alpha(opacity\x3d100)"
                }))
            },
            Kl: function() {
                2 != this.je && 3 != this.je && (this.je = 3, h(this.nb, {
                    visibility: "hidden",
                    opacity: "0",
                    filter: "alpha(opacity\x3d0)"
                }), this.pinned = !1)
            },
            Zw: function() {
                var a = this;
                return function() {
                    a.Wj()
                }
            },
            ar: function() {
                var a = this;
                return function() {
                    a.pinned || a.Kl()
                }
            },
            vw: function() {
                var a = this;
                return function() {
                    a.mv()
                }
            },
            mv: function() {
                this.pinned ? this.Kl() :
                    (this.pinned = !0, this.Wj())
            },
            Ax: function() {
                return function() {}
            }
        };
        var C = "#709F70",
            B = "#ECE981",
            w = "#135656";
        m.prototype.yl = function(a) {
            h(this.Wm, {
                backgroundColor: a
            })
        };
        e.prototype.onStatusChange = e.prototype.onStatusChange;
        e.prototype.onListenStart = e.prototype.onListenStart;
        e.prototype.onListenEnd = e.prototype.onListenEnd;
        e.prototype.getDomNode = e.prototype.getDomNode;
        return e
    });
    define("SimpleLogLevels", [], function() {
        var d = {
                FATAL: 5,
                ERROR: 4,
                WARN: 3,
                INFO: 2,
                DEBUG: 1
            },
            f = {
                priority: function(b) {
                    return d[b] || 0
                }
            };
        f.priority = f.priority;
        return f
    });
    define("SimpleLogger", ["SimpleLogLevels"], function(d) {
        function f(b, a) {
            this.sh = b;
            this.Mg = a;
            this.Lf = "DEBUG"
        }
        f.prototype = {
            fatal: function(b) {
                this.isFatalEnabled() && this.sh.dispatchLog(this.Mg, "FATAL", b)
            },
            isFatalEnabled: function() {
                return d.priority("FATAL") >= d.priority(this.Lf)
            },
            error: function(b) {
                this.isErrorEnabled() && this.sh.dispatchLog(this.Mg, "ERROR", b)
            },
            isErrorEnabled: function() {
                return d.priority("ERROR") >= d.priority(this.Lf)
            },
            warn: function(b) {
                this.isWarnEnabled() && this.sh.dispatchLog(this.Mg, "WARN",
                    b)
            },
            isWarnEnabled: function() {
                return d.priority("WARN") >= d.priority(this.Lf)
            },
            info: function(b) {
                this.isInfoEnabled() && this.sh.dispatchLog(this.Mg, "INFO", b)
            },
            isInfoEnabled: function() {
                return d.priority("INFO") >= d.priority(this.Lf)
            },
            debug: function(b) {
                this.isDebugEnabled() && this.sh.dispatchLog(this.Mg, "DEBUG", b)
            },
            isDebugEnabled: function() {
                return d.priority("DEBUG") >= d.priority(this.Lf)
            },
            setLevel: function(b) {
                this.Lf = d.priority(b) ? b : "DEBUG"
            }
        };
        f.prototype.fatal = f.prototype.fatal;
        f.prototype.isFatalEnabled =
            f.prototype.isFatalEnabled;
        f.prototype.error = f.prototype.error;
        f.prototype.isErrorEnabled = f.prototype.isErrorEnabled;
        f.prototype.warn = f.prototype.warn;
        f.prototype.isWarnEnabled = f.prototype.isWarnEnabled;
        f.prototype.info = f.prototype.info;
        f.prototype.isInfoEnabled = f.prototype.isInfoEnabled;
        f.prototype.debug = f.prototype.debug;
        f.prototype.isDebugEnabled = f.prototype.isDebugEnabled;
        f.prototype.setLevel = f.prototype.setLevel;
        return f
    });
    define("SimpleLoggerProvider", ["SimpleLogger", "SimpleLogLevels"], function(d, f) {
        function b() {
            this.Ta = [];
            this.Hf = {}
        }
        b.prototype = {
            Kj: function() {
                var a = 100,
                    b = 0;
                if (0 < this.Ta.length) {
                    for (var d = 0; d < this.Ta.length; d++) f.priority(this.Ta[d].getLevel()) < a && (a = f.priority(this.Ta[d].getLevel()), b = d);
                    return this.Ta[b].getLevel()
                }
                return null
            },
            Yn: function(a) {
                for (var b in this.Hf) this.Hf[b].setLevel(a)
            },
            bv: function(a, b) {
                var d = [];
                if ("*" === a.getCategoryFilter()) return !0;
                for (var d = a.getCategoryFilter().split(" "), e =
                        0; e < d.length; e++)
                    if (d[e] == b) return !0;
                return !1
            },
            addLoggerAppender: function(a) {
                a && a.log && a.getLevel && (this.Ta.push(a), a.setLoggerProvider && a.setLoggerProvider(this));
                this.Yn(this.Kj())
            },
            removeLoggerAppender: function(a) {
                for (var b = 0; b < this.Ta.length; b++)
                    if (this.Ta[b] === a) {
                        this.Ta.splice(b, 1);
                        this.Yn(this.Kj());
                        break
                    }
            },
            Fq: function() {
                this.Yn(this.Kj())
            },
            getLogger: function(a) {
                this.Hf[a] || (this.Hf[a] = new d(this, a), 0 < this.Ta.length && this.Hf[a].setLevel(this.Kj()));
                return this.Hf[a]
            },
            dispatchLog: function(a,
                b, d) {
                var e;
                e = "undefined" != typeof window ? window.name + " " : "";
                var p = 0,
                    k = new Date,
                    p = k.getHours();
                10 > p && (e += "0");
                e = e + p + ":";
                p = k.getMinutes();
                10 > p && (e += "0");
                e += p;
                e += ":";
                p = k.getSeconds();
                10 > p && (e += "0");
                e += p;
                e += ",";
                e += k.getMilliseconds();
                p = f.priority(b);
                for (k = 0; k < this.Ta.length; k++) f.priority(this.Ta[k].getLevel()) <= p && this.bv(this.Ta[k], a) && this.Ta[k].log(a, b, d, e)
            }
        };
        b.prototype.addLoggerAppender = b.prototype.addLoggerAppender;
        b.prototype.removeLoggerAppender = b.prototype.removeLoggerAppender;
        b.prototype.getLogger =
            b.prototype.getLogger;
        b.prototype.dispatchLog = b.prototype.dispatchLog;
        return b
    });
    define("SimpleLogAppender", ["SimpleLogLevels"], function(d) {
        function f(b, a) {
            this.cn = d.priority(b) ? b : "INFO";
            this.Jp = a || "*";
            this.dn = null
        }
        f.prototype = {
            setLoggerProvider: function(b) {
                b && b.getLogger && b.Fq && (this.dn = b)
            },
            log: function() {},
            composeLine: function(b, a, c, d) {
                return b + " | " + a + " | " + d + " | " + c
            },
            getLevel: function() {
                return this.cn
            },
            setLevel: function(b) {
                this.cn = b = d.priority(b) ? b : "INFO";
                null != this.dn && this.dn.Fq()
            },
            getCategoryFilter: function() {
                return this.Jp
            },
            setCategoryFilter: function(b) {
                this.Jp = b || "*"
            }
        };
        f.prototype.log = f.prototype.log;
        f.prototype.setLoggerProvider = f.prototype.setLoggerProvider;
        f.prototype.composeLine = f.prototype.composeLine;
        f.prototype.getLevel = f.prototype.getLevel;
        f.prototype.setLevel = f.prototype.setLevel;
        f.prototype.getCategoryFilter = f.prototype.getCategoryFilter;
        f.prototype.setCategoryFilter = f.prototype.setCategoryFilter;
        return f
    });
    define("BufferAppender", ["Inheritance", "SimpleLogAppender", "SimpleLogLevels"], function(d, f, b) {
        function a(b, d, e) {
            this._callSuperConstructor(a, [b, d]);
            this.mr = !e || 0 > e ? 0 : e;
            this.first = 0;
            this.Ff = -1;
            this.buffer = {}
        }
        a.prototype = {
            reset: function() {
                this.first = 0;
                this.Ff = -1;
                this.buffer = {}
            },
            extractLog: function(a) {
                a = this.getLog(null, a);
                this.reset();
                return a
            },
            getLog: function(a, d, e) {
                var f = "";
                a ? (a = this.Ff - a + 1, a < this.first && (a = this.first)) : a = this.first;
                d = d || "\n";
                for (e = b.priority(e || "DEBUG"); a <= this.Ff;) b.priority(this.buffer[a].level) >=
                    e && (f += this.buffer[a].Qy), f += d, a++;
                return f
            },
            log: function(a, b, d, f) {
                var k = ++this.Ff;
                0 != this.mr && k >= this.mr && (this.buffer[this.first] = null, this.first++);
                d = this.composeLine(a, b, d, f);
                this.buffer[k] = {
                    level: b,
                    Qy: d
                }
            },
            getLength: function() {
                return this.Ff - this.first + 1
            }
        };
        a.prototype.reset = a.prototype.reset;
        a.prototype.getLog = a.prototype.getLog;
        a.prototype.extractLog = a.prototype.extractLog;
        a.prototype.log = a.prototype.log;
        a.prototype.getLength = a.prototype.getLength;
        d(a, f);
        return a
    });
    define("AlertAppender", ["Inheritance", "SimpleLogAppender", "BufferAppender", "Executor", "Environment"], function(d, f, b, a, c) {
        function g(a, c, d) {
            this._callSuperConstructor(g, [a, c]);
            this.vp = !d || 0 > d ? 5 : d;
            this.el = 0;
            this.buffer = new b(a, c)
        }
        c.browserDocumentOrDie();
        g.prototype = {
            BB: function(a) {
                alert(a)
            },
            log: function(c, d, g, f) {
                this.el++;
                this.buffer.log(c, d, g, f);
                this.el >= this.vp && (this.el = 0, a.addTimedTask(this.BB, 0, this, [this.buffer.getLog(this.vp, "\n", "", !1, this.cn)]), this.buffer = new b)
            }
        };
        g.prototype.log = g.prototype.log;
        d(g, f);
        return g
    });
    define("ConsoleAppender", ["Inheritance", "SimpleLogAppender", "IllegalStateException"], function(d, f, b) {
        function a(c, d) {
            if ("undefined" == typeof console) throw new b("This appender can't work if a console is not available. Enable the Browser console if possible or change appender.");
            this._callSuperConstructor(a, [c, d])
        }
        a.prototype = {
            log: function(a, b, d, f) {
                d = this.composeLine(a, b, d, f);
                switch (b) {
                    case "DEBUG":
                        if (console.debug) {
                            console.debug(d);
                            return
                        }
                        break;
                    case "INFO":
                        if (console.info) {
                            console.info(d);
                            return
                        }
                        break;
                    case "WARN":
                        if (console.warn) {
                            console.warn(d);
                            return
                        }
                        default:
                            if (console.error) {
                                console.error(d);
                                return
                            }
                }
                console.log(d)
            }
        };
        a.prototype.log = a.prototype.log;
        d(a, f);
        return a
    });
    define("DOMAppender", ["Inheritance", "SimpleLogAppender", "IllegalArgumentException", "Environment"], function(d, f, b, a) {
        function c(a, d, f) {
            this._callSuperConstructor(c, [a, d]);
            if (!f) throw new b("a DOMElement instance is necessary for a DOMAppender to work.");
            this.Ec = f;
            this.Ga = this.gn = !1
        }
        a.browserDocumentOrDie();
        c.prototype = {
            setUseInnerHtml: function(a) {
                this.Ga = !0 === a
            },
            setNextOnTop: function(a) {
                this.gn = !0 === a
            },
            log: function(a, b, c, d) {
                a = this.composeLine(a, b, c, d);
                this.Ga ? this.Ec.innerHTML = this.gn ? a + "\x3cbr\x3e" +
                    this.Ec.innerHTML : this.Ec.innerHTML + (a + "\x3cbr\x3e") : this.gn ? (a = document.createTextNode(a), b = document.createElement("br"), this.Ec.insertBefore(b, this.Ec.firstChild), this.Ec.insertBefore(a, this.Ec.firstChild)) : (a = document.createTextNode(a), b = document.createElement("br"), this.Ec.appendChild(a), this.Ec.appendChild(b))
            }
        };
        c.prototype.setUseInnerHtml = c.prototype.setUseInnerHtml;
        c.prototype.setNextOnTop = c.prototype.setNextOnTop;
        c.prototype.log = c.prototype.log;
        d(c, f);
        return c
    });
    define("FunctionAppender", ["Inheritance", "SimpleLogAppender"], function(d, f) {
        function b(a, c, d, e) {
            this._callSuperConstructor(b, [a, c]);
            this.lw = d;
            this.iz = e || null
        }
        b.prototype = {
            log: function(a, b, d, e) {
                var f = this.lw;
                if (f.apply) {
                    a = this.composeLine(a, b, d, e);
                    try {
                        f.apply(this.iz, [a])
                    } catch (k) {}
                }
            }
        };
        b.prototype.log = b.prototype.log;
        d(b, f);
        return b
    });
    define("RemoteAppender", ["Inheritance", "BufferAppender", "Executor", "IllegalArgumentException", "SimpleLogLevels"], function(d, f, b, a) {
        function c(b, e, d) {
            this._callSuperConstructor(c, [b, e, 10]);
            this.waiting = !1;
            if (!d) throw new a("a LightstreamerClient instance is necessary for a RemoteAppender to work.");
            this.ep = d
        }
        c.prototype = {
            log: function(a, b, d, f) {
                this._callSuperMethod(c, "log", [a, b, d, f]);
                this.hp(!0)
            },
            hp: function(a) {
                if (!(0 >= this.getLength())) {
                    if (0 == this.ep.Rb().indexOf("CONNECTED")) {
                        var c = this.Zv();
                        if (this.ep.Nh(c)) {
                            this.reset();
                            this.waiting = !1;
                            return
                        }
                    }
                    this.waiting && a || (this.waiting = !0, b.addTimedTask(this.hp, 2E3, this))
                }
            },
            Zv: function(a, b) {
                var d = this._callSuperMethod(c, "extractLog", ["LS_log"]),
                    d = d.split("LS_log");
                b = "LS_log";
                for (var f = {}, h = 0; h < d.length; h++) 0 != d[h].length && (f[b + (h + 1)] = encodeURIComponent(d[h].replace(/[\n\r\f]/g, "||")));
                return f
            },
            extractLog: function() {
                return null
            }
        };
        c.prototype.extractLog = c.prototype.extractLog;
        c.prototype.log = c.prototype.log;
        d(c, f, !1, !0);
        return c
    });
    define("LogMessages", ["LoggerManager"], function(d) {
        function f() {}
        var b = [],
            b = "New value for setting received from API{New value for setting received from internal settings{Broadcasting setting to shared LightstreamerClient instances{Setting changed, firing notification{Unexpectedly missing session id{Bind request generated{Create request generated{Recovery request generated{Destroy request generated{Force rebind request generated{Path selected{New {Engine {Subscribing subscription{Unsubscribing subscription{Enqueueing subscription update{Resuming subscription update{Executing subscription update{sending Subscription to the engine{Overriding old promise for table {Delaying subscription completion{Resuming subscription completion{Ignored old promise triggered for table {Ignored old promise failed for table {Restoring all pending Subscriptions{Pausing active Subscription{Pausing all active Subscriptions{Delaying subscription action{Resuming subscription action{Executing subscription action{Delaying subscription action{Resuming subscription action{Subscription action had to be delayed on multiple instances{Unexpected progressive{Unexpected progressive{Received event prog higher than expected{Received event prog different than expected{Received event prog different than actual{Unexpected message outcome sequence{Changing reference session{Command phase check{Adding notification{Skipping replicated progressive{Unexpected command received, ignoring{Client or session unexpectedly disappeared while handling subscription{There is probably another web application connected to the same Lightstreamer Server within this browser instance. That could prevent the current application from connecting to the Server. Please close the other application to unblock the current one{New client attached to engine{Dismissing client{Can't find subscription anymore{Can't find page anymore{Notify back to the client that the subscription was handled{It has been detected that the JavaScript engine of this browser is not respecting the timeouts in setTimeout method calls. The Client has been disconnected from the Server in order to avoid reconnection loops. To try again, just refresh the page.{Unexpected openSocket call{Unexpected WebSocket _load call{Open path is disappeared{Error sending data over WebSocket{Unexpected send outcome while websocket is ready-to-send{Error on WebSocket connection{New WS connection oid\x3d{Closing WebSocket connection{Error closing WebSocket connection{Error opening WebSocket connection{Timeout event [currentConnectTimeoutWS]{error on closing a timed out WS{Preparing to bind on WebSocket connection{WebSocket transport sending oid\x3d{WebSocket transport receiving oid\x3d{WebSocket connection ready{WebSocket connection close event received{New sessionId ({Unexpected phase during binding of session{Unexpected creation of a session while another one is still creating{Unexpected phase during slow handling{Unexpected timeout event while session is _OFF{Unexpected error event while session is an non-active status{Unexpected loop event while session is an non-active status{Unexpected push event while session is an non-active status{Unexpected phase after create request sent{Unexpected phase after bind request sent{Unexpected phase during OK execution{Unexpected empty start time{Unexpected session id received on bind OK{Opening new session{Binding session{Closing session{Initializing session {Sending request to the server to force a rebind on the current connection{Sending request to the server to destroy the current session{New session{Copying prog {Resetting session oid\x3d{Session state change ({Mad timeouts? Avoid connection{Opening on server, send destroy{Binding session{Switch requested{Slow requested{Session shutdown{Make pause before next bind{Timeout event [{Start session recovery. Cause: no response timeLeft\x3d{Start new session. Cause: no response{Timeout: recover session{Timeout: new session{Error event{Start session recovery. Cause: socket failure while receiving{Closing broken session{Start session recovery. Cause: socket failure while recovering{Switching transport{Start new session. Cause: {Status timeout in {Synch event received{Available bandwidth event received{Error41 event received{Keepalive event received{OK event received{Sync event received{Loop event received{End event received{Error opening CORS-XHR connection oid\x3d{New CORS-XHR connection oid\x3d{CORS-XHR connection closed oid\x3d{Error non closing connection opened using CORS-XHR{CORS-XHR transport sending oid\x3d{CORS-XHR transport receiving oid\x3d{CORS-XHR connection error oid\x3d{CORS-XHR request completed oid\x3d{Error reading CORS-XHR status oid\x3d{Error opening connection using XDomainRequest{Closing connection opened using XDomainRequest{Error non closing connection opened using XDomainRequest{XDomainRequest transport sending{Error on connection opened using XDomainRequest{XDomainRequest transport receiving{Connection opened using XDomainRequest completed{Error while sending request using html form{Closing connection opened using html form; actually doing nothing{Html form transport sending{Replace on forever-frame not available{Error while sending request using  replace on forever-frame{Closing connection opened using replace on forever-frame{Replace on forever-frame transport sending{Loading XHR frame to perform non-cross-origin requests{Client is offline, will retry later to load XHR frame{XHR frame loaded{XHR frame loading timeout expired, try to reload{XHR frame loading timeout expired again, will not try again{Passing request to the XHR frame{Error passing request to the XHR frame{Error closing connection opened using XHR{XHR transport sending{Closing connection opened using XHR{Error reading XHR status{XHR response complete{Error on connection opened using XHR{Error on disposing XHR's callback{Error on disposing XHR{Streaming enabled on XHR{XHR transport receiving{XHR response complete{Error opening connection using JSONP technique{JSONP transport sending{Closing connection opened using JSONP technique{Verify connection class{This class is not available on the current environment{Cross-origin request is needed, this class is not able to make cross-origin requests{Cookies on request are required, this class can't guarantee that cookies will be actually sent{Cross-protocol request is needed, this class is not able to make cross-protocol requests{Extra headers are given, this class is not able to send requests containing extra headers{This class can't be used in the current context{Connection class is good{Searching for an appropriate connection class{Restart connection selector{Unable to use available connections to connect to server{Unable to use available connections to connect to server{Client is offline, delaying connection to server{Connection request generated{Connection currently unavailable, delaying connection{Connection open to the server{Unexpected ws phase while opening connection{Unexpected ws phase during binding{Unexpected phase for an clean end of a WS{Unexpected connection error on a connection that was not yet open{can't be unable-to-open since the connection is already open{A control link was received while earlyWSOpenEnabled is set to true, a WebSocket was wasted.{Unexpected WebSocket failure{Open WebSocket to server{WebSockets currently unavailable, delaying connection{Connection to server bound upon WebSocket{Connection to server open upon WebSocket{WebSocket was broken before it was used{WebSocket was broken while we were waiting the first bind{WebSocket was broken while we were waiting{Sync message received while session wasn't in receiving status{Huge delay detected by sync signals. Restored from standby/hibernation?{Delay detected by sync signals{First sync message, check not performed{No delay detected by sync signals{No delay detected by sync signals{Duplicated message{Unexpected request type was given to this batch{Unexpected request type was given to this batch; expecting ADD REMOVE DESTROY or CONSTRAIN{ADD after REMOVE?{Trying to remove by index non-existent request{Trying to remove by key non-existent request{Storing request{Substituting CONSTRAINT or FORCE_REBIND request{Replacing 'second' ADD request with a REMOVE request for the same subscription{REMOVE request already stored, skipping{ADD request for the involved subscription was not yet sent; there is no need to send the related REMOVE request or the original ADD one, removing both{Same session id on different servers, store two different DESTROY requests{Verified duplicated DESTROY request, skipping{Duplicated ADD or CHANGE_SUB request, substitute the old one with the new one{Storing confirmed{Batch handler unexpectedly idle; a batch was waiting{Batch handler unexpectedly not idle; nothing ready to be sent was found{Batch object not null{Duplicated message{Unexpected sending outcome{Can't find an appropriate connection to send control batch{Unable to find a connection for control requests, will try again later{A single request size exceeds the \x3crequest_limit\x3e configuration setting for the Server. Trying to send it anyway although it will be refused{Start sending reverse heartbeat to the server{Start sending reverse heartbeat to the server{Keep sending reverse heartbeat to the server{Stop sending reverse heartbeat to the server{Stop sending reverse heartbeat to the server{Keep sending reverse heartbeat to the server{New request to be sent to server{Some controls don't need to be sent anymore, keep on dequeing{Delaying control requests; waiting for a connection to become available{Control request sent through HTTP connection{Control request sent through WebSocket, keep on dequeuing{Control requests queue is now empty{Control request got answer{Error from network{Batch length limit changed{Preparing reverse heartbeat{Close current connection if any and applicable{ControlConnectionHandler state change {Reset Controls handler status{Enabling control requests over WebSocket now{Disabling control requests over WebSocket now{Still waiting previous control request batch to return{Ready to dequeue control requests to be sent to server{starting dequeuing{Send previously composed batch{Generate and send new batch{Empty batch, exit{Ready to send batch on net, choosing connection{WebSocket should be available, try to send through it{Empty request was generated, exit{Connection for control batch chosen{Empty request for HTTP was generated, exit{Connection failed, will try a different connection{Connection temporarily unavailable, will try later{Forward prepared message to control handler{Ack received for message{OK outcome received{DISCARDED outcome received{DENIED outcome received{ERROR outcome received{Closing message handler{Activating message handler{Preparing message request{No ack was received for a message; forwarding it again to the control handler{Ack received, stopping automatic retransmissions{Ack received, no outcome expected, clean structures{Not waiting for ack, purging{Message handled, clean structures{Message on the net notification{Unexpected error occurred while executing server-sent commands!{Enqueuing received data{Dequeuing received data{Data can't be handled{Unexpected error occurred while executing server-sent commands!{Enqueuing received data{Dequeuing received data{Unexpected fallback type; switching because the current session type cannot be established{Unexpected fallback type; switching because of a slow connection was detected{Unexpected fallback type switching with new session{Unexpected fallback type switching with a force rebind{Unexpected fallback type switching because of a failed force rebind{Can't initiate session, giving up, disabling automatic reconnections{Unable to establish session of the current type. Switching session type{Slow session detected. Switching session type{Setting up new session type{Switching current session type{Slow session switching{Failed to switch session type. Starting new session{Session started{New session handler oid\x3d{SessionManager state change:{Session recovery{Session recovery: cancelled{Session bound{Session closed{Discarding update for dismissed page{Received new update{Discarding lost updates notification for dismissed page{Received lost updates event{Discarding end of snapshot notification for dismissed page{Received end of snapshot event{Discarding snapshot clearing notification for dismissed page{Received snapshot clearing event{Received server error event{Received subscription error event{Discarding subscription error notification for dismissed page{Received unsubscription event{Discarding unsubscription notification for dismissed page{Received reconfiguration OK event{Discarding subscription notification for dismissed page{Received subscription event{Received message ack{Received message-ok notification{Received message-deny notification{Received message-discarded notification{Received message-error notification{New control link received{Dismissing current session and stopping automatic reconnections.{Transport change requested{Opening a new session and starting automatic reconnections.{Shared worker is broken{RUNNING EXECUTOR AT {RESUMED TO {DELAYED TO {Unexpected sharing error{Unexpected dispatching error{Unexpected error on dispatching{Removing wrong address?{Address already removed?{SharedStatus remote sharing is ready{SharedStatus local sharing is ready{Started refresh thread{There is a concurrent engine. Close engine {Stopped refresh thread{Engine is probably dying, skip one cookie refresh{Checking status{No engines{Checking shared status to verify if there are similar engines alive{Engine found, no values though{Engine found, not compatible though{Write engine shared status{Found engine {Remote engine {You have Norton Internet Security or Norton\nPersonal Firewall installed on this computer.\nIf no real-time data show up, then you need\nto disable Ad Blocking in Norton Internet\nSecurity and then refresh this page{Trying to attach to a cross-page engine{Exception while trying to attach to a cross-page engine{Cross-page engine not found{Probably blocked popup detected: firefox-safari case{Cross-page engine attached{Verify if the found cross-page engine can be used{can't use found cross-page engine: page is now closed{can't use found cross-page engine: uneffective popup detected, chrome case{problem closing the generated popup{Probably blocked popup detected: opera common case{can't use found cross-page engine: Lightstreamer singleton not available{can't use found cross-page engine: Lightstreamer singleton content unavailable{Ready to use found cross-page engine: looks ok{can't use found cross-page engine: exception throw while accessing it{Skipping already-used cookie{Stop search for an engine{No sharing was found, a new sharing will be created{No sharing was found, will keep on searching after a pause{No sharing was found, no sharing will be created, this client will fail{A sharing was found but attaching is disabled, this client will fail{A sharing was found, this will attach to {Engine {A sharing was found, but accordingly with the configuration it will be ignored{Valid engine found: {invalid values{Found a likely dead engine{Searching for available sharing{Local engine found{Local engine not found. Can't search on other pages because of the current sharing configuration{Search remote engine in other page{RemoteEngine \x3d {Can't access reference {Search remote engine in shared storage{Storage inspection complete{No valid engine found{Engine {Engine {Unexpected missing values in sharing cookie{Skipping not compatible engine{Valid engine values found. Wait for popup-protection timeout{No compatible sharing detected{No valid engine values found. Check again in {Forcing preventCrossWindowShare because page is on file:///{A new sharing will be immediately created{No way to obtain a sharing, this client will fail immediately{A sharing will now be searched{New connection sharing{no sharing on mourning room?{Sharing is not available on UCBrowser{Connection sharing is not available{Page is closing, won't search a new engine{Sharing lost, trying to obtain a new one{Connect requested{Disconnect requested{Executing connect{Executing disconnect{An exception was thrown while executing the Function passed to the forEachChangedField method{An exception was thrown while executing the Function passed to the forEachField method{key and/or command position not correctly configured{Subscription entered the active state{Subscription is now subscribed to{Subscription is not subscribed to anymore{Subscription reset{Subscription waiting to be sent to server{Subscription queued to be sent to server{Subscription is now on hold{Subscription exits the active status; it can now be modified{Subscription request generated{Received position of COMMAND and KEY fields from server{Adapter Set assigned{Selector assigned{Requested Max Frequency assigned{Requested Buffer Size assigned{Snapshot Required assigned{Second level Data Adapter Set assigned{Problem calling event on Flash object{Problem calling event on Flash object{Problem calling event on Flash object{Problem calling event on Flash object{Problem calling event on Flash object{Unable to get the Flash movie object reference{The flash object is unexpectedly disappeared{Notification from the flash object received, the object is still incomplete though; will check again later{Ready to make the bridge{Problem calling event on Flash object{Problem calling event on Flash object{Flash object is ready{Waiting a LightstreamerClient instance to create bridge{Waiting the flash object instance to create bridge{Waiting notification from the flash object to create bridge{Flash object disappeared or not yet found{Flash object disappeared or not yet ready{Flash object disappeared or not yet ready{Preparing subscription for flash{Subscribing subscription for flash{The LightstreamerClient is unexpectedly disappeared{The referenced Subscription does not exist{Unsubscribing subscription for flash{The LightstreamerClient is unexpectedly disappeared{The referenced Subscription does not exist{The referenced Subscription does not exist{The referenced Subscription does not exist{The referenced Subscription does not exist{The referenced Subscription does not exist{Wong length!{Missing from first array{Missing from second array{Wrong  element{Not expecting a NULL{Expecting a different value{Expecting 2 different values{Expecting a valid value{Expecting a not valid value{ASSERT failed{Unexpected{An error occurred while executing an event on a listener{Dispatching event on listeners{Can't remove row that does not exist{Cleaning the model{Removing row{Postpone new update until the current update/remove is completed{Postpone new remove until the current update/remove is completed{Inserting new row{Updating row{Scroll direction is ignored if sort is enabled{Merging this update values with the values of the current update{Filling formatted values in cell{New ChartLine{Clearing ChartLine{Repainting ChartLine{ChartLine re-painted{Calculated Y unit{Y labels generated{Y labels cleared{Y labels now configured{Line style configured{Y axis is now positioned{A DOM element must be provided as an anchor for the chart{Cannot create line. Please declare the Y axis{Chart is now ready to be used{Got double nulls, clear line{Parse html for Chart{Painter configured{Creating a new label for the chart{Drawing line on the chart{New line coordinates{New line was drawn{Repaint All{Calculated X unit{X labels generated{X labels cleared{Got a null, ignore point{Line removed{Cleaned all{X axis is now configured on field{Configuring multiple Y axis{Y axis is now configured on field{removing multiple Y axis{Y axis is now removed{X axis is now positioned{X labels now configured{Exception thrown while executing the iterator Function{Cannot find the scroll element{Can't find value for sort key field{Perform auto-scroll{Calculate number of pages{Unexpected position of row to be wiped".split("{");
        d.resolve =
            function(a) {
                return a + "] " + b[a]
            };
        f.Xw = function(a) {
            return d.resolve(a)
        };
        d.resolve = d.resolve;
        f.getMessage = f.Xw;
        return f
    });
}());